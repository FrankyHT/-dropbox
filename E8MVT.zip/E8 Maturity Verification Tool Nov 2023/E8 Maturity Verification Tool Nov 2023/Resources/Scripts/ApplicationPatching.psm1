#application patching functions

<#
.SYNOPSIS
Provides information about when a particular version was released.

.DESCRIPTION
This function compares a provided application version, with a data collection containing an array of version numbers and release dates.

.PARAMETER VersionToCheck
A string containing the version to be checked.

.PARAMETER AppVersionDataLocation
A string containing the path where the application version data is stored.
#>
function Get-AppVersionDetail {
    Param
    (
        [Parameter(Position = 0)] # Positional parameter
        [string]$VersionToCheck,
        [Parameter(Position = 1)] # Positional parameter
        [string]$AppVersionDataLocation
    )

    $version = [system.version]$VersionToCheck

    #Load patch data
    try {
        #Exception will occur if file does not exist
        $patchdata = (Get-ChildItem $AppVersionDataLocation -ErrorAction Stop)
        $GoodData = $true
    }
    #Patch data is not present
    catch {
        #throw "Application patch data is not present. Please run the ""update-e8mvt-data.ps1"" script."
        $GoodData = $false
    }

    #is patch data too old?
    if ($GoodData -and $patchdata.LastWriteTime -gt (Get-Date).AddDays(-14)) { $GoodData = $true }
    #Patch data is too old
    else {
        throw "Application patch data is present, and more than two weeks old. Please run the ""update-e8mvt-data.ps1"" script."
        $GoodData = $false
    }

    #Data is present, attempt to extract
    if ($GoodData) {
        #grab the patch data
        try {
            $cachefile = Import-CSV $AppVersionDataLocation -ErrorAction Stop | Sort-Object Date,Version -unique    
            $GoodData = $true
        }
        catch {
            #throw "An error occurred extracting the application patch data. Please run the ""update-e8mvt-data.ps1"" script."
            $GoodData = $false
        }
    }

    #load version cache
    $versioncache = @{}
    if ($GoodData) {
        foreach ($row in $cachefile) {
            if ($row -notmatch "^#") {
                #skip commented lines
                $key = $row.Version
                if ($key -notmatch "\.") { $key = "$key.0" } #if it's a single number, add a .0 so it parses as a version properly.
                $key = [System.Version]$key
                $value = [system.datetime]::parseexact(($row.Date.Trim()), 'dd/MM/yyyy', $null)
                #Version    Release Date
                if ( -not $versioncache.ContainsKey($key)) { $versioncache.Add($key, $value) }
            }
        }
    }

    #get the latest version by date
    $latestversion = ($versioncache.GetEnumerator() | Sort-Object -Descending -Property Name,Value | select-object -first 1) #name, value

    #only look for known versions
    $lookup = $versioncache[$version]

    #if you couldn't find it in the list, do some approximation
    if (-not $lookup) {
        #check upper and lower version release dates, get an approximate release date halfway between them
        $nextversionrelease = ($versioncache.GetEnumerator() | where-object name -gt $version | sort-object -property name | select-object -First 1).Value
        $previousversionrelease = ($versioncache.GetEnumerator() | where-object name -lt $version | sort-object -property name -descending | select-object -First 1).Value
        #between two known versions, can approximate the release date
        if ($nextversionrelease -and $previousversionrelease) {
            $lookup = [datetime]$previousversionrelease.AddDays((NEW-TIMESPAN -Start $previousversionrelease -End $nextversionrelease).TotalDays)
            #calculate approximate age of patch
            $dayssincerelease = (NEW-TIMESPAN -Start $lookup -End $(get-date)).TotalDays
            #indicate it is approximate
            $approximaterelease = $true
        }
        #no releases above this one, but there are below it, probably a new version that isn't in the list
        elseif ($previousversionrelease) {
            #don't set lookup
            $unknownnewversion = $true
            $dayssincerelease = 0
        }
        #couldnt find a newer OR an older version, shouldn't hit this
        elseif ($versioncache.Count -eq 0) {
            $dayssincerelease = 0
        }
        else {
            throw "Unknown version state, older than the oldest known release"
        }
    }
    else {
        $dayssincerelease = (NEW-TIMESPAN -Start $lookup -End $(get-date)).TotalDays
    }


    [hashtable]$objectProperty = @{}
    $objectProperty.Add('Version', $version)
    $objectProperty.Add('ReleaseDate', $lookup)
    $objectProperty.Add('DaysSinceRelease', $dayssincerelease)
    $objectProperty.Add('LatestVersion', $latestversion.Name)
    $objectProperty.Add('LatestVersionReleaseDate', $latestversion.Value)
    $objectProperty.Add('ApproximateReleaseDate', $approximaterelease)
    $objectProperty.Add('UnknownNewVersion', $unknownnewversion)

    return New-Object -TypeName psobject -Property $objectProperty
}

<#
.SYNOPSIS
Gets information about any CVEs associated with a particular version number.

.DESCRIPTION
Extracts a compressed file containing CVE data associated with a particular application.

.PARAMETER VersionToCheck
A string containing the version number to search for.

.PARAMETER AppCriticalDataLocation
A string containing the path where the compressed application CVE data is stored.

.PARAMETER Strict
A boolean flag identifying whether the check should be strict or not. 
If the flag is set, it will require a full 1.2.3.4 match. 
If not, 1.2.3.X will match, such as 1.2.3.5, 1.2.3.7 and 1.2.3.1.

.OUTPUTS
Returns an array of CVE numbers that affect that version.
#>
function Get-AppVersionCritical {
    Param
    (
        [Parameter(Position = 0)] # Positional parameter
        [string]$VersionToCheck,
        [Parameter(Position = 1)] # Positional parameter
        [string]$AppCriticalDataLocation,
        [Parameter(Position = 2)] # Positional parameter
        [switch]$Strict #if this is set, don't make the last element of the version optional, e.g. MUST be 1.2.3.4 rather than 1.2.3.X
    )

    if (Test-Path $AppCriticalDataLocation) {
        $archive_filename = Get-Item $AppCriticalDataLocation

        #Get the raw file
        $raw_filename = $archive_filename.Name.Substring(0, $archive_filename.Name.Length - 4)
        #expand the archive
        #Expand-archive available
        if (Get-Command "Expand-Archive" -erroraction silentlycontinue) {
            Expand-Archive -Path $archive_filename.FullName -DestinationPath . -force
        }
        #not available (uses .NET 4.5, hopefully not required)
        else {
            try {
                #decompress file
                Add-Type -AssemblyName System.IO.Compression.FileSystem
                [System.IO.Compression.ZipFile]::ExtractToDirectory($archive_filename.FullName, ".")
            }
            catch {
                throw "Error decompressing vulnerability data file: $_"
            }
        }

        #autoconstruct regular expression
        $versiontocheckarray = $VersionToCheck.Split(".")
        $versionregex = ""

        $major = $versiontocheckarray[0]
        $minor = $versiontocheckarray[1]
        $build = $versiontocheckarray[2]
        $revision = $versiontocheckarray[3]

        #optionally, add strict to
        $versionregex = "0{0,$(6-$major.Length)}${major}\.0{0,$(6-$minor.Length)}${minor}\.0{0,$(6-$build.Length)}${build}(?:\.0{0,$(6-$revision.Length)}${revision})"
        if (-not $Strict) { $versionregex += "?" }

        #get the vuln count
        $count = get-content .\$raw_filename | select-String $versionregex | ForEach-Object { $_.ToString().Split("|")[0] }

        #remove the vuln data file, since it's big
        remove-item -force $raw_filename

    }
    return $count
}

<#
.SYNOPSIS
Gets various information about a particular file or files.

.DESCRIPTION
Extracts the Version, last write and access time, and an approximate install and create time.

.PARAMETER Path
A string containing the path to look for the file/s.

.PARAMETER MatchCheck
A string containing a regex to match the particular file/s.

.OUTPUTS
An object an array of hashtables, one for each identified file containing the path, version, last write and access times, and days since it was created and installed.
#>
function Get-Detail {
    Param
    (
        [Parameter(Position = 0)] # Positional parameter
        [string]$Path,
        [Parameter(Position = 1)] # Positional parameter
        [string]$MatchCheck
    )

    $result = [System.Collections.ArrayList]@()

    $filelist = (get-childitem -path $Path -recurse -ErrorAction SilentlyContinue).Where( { $_.FullName -match $MatchCheck -and $_.Length -gt 1 });

    foreach ($file in $filelist) {
        #establish variables
        $itempath = $file.FullName
        $filedetails = (Get-ChildItem $file.FullName)

        #get file version
        try { $ver = Get-VersionInfo($file) } catch { $ver = "" } #catch is for files without versions

        #create result object
        [hashtable]$objectProperty = @{}
        $objectProperty.Add('Path', $itempath)
        $objectProperty.Add('Version', $ver)
        $objectProperty.Add('LastWriteTime', $filedetails.LastWriteTime)
        $objectProperty.Add('LastAccessTime', $filedetails.LastAccessTime)
        $objectProperty.Add('DaysSinceInstall', (NEW-TIMESPAN -Start $filedetails.LastAccessTime -End $(get-date)).TotalDays)
        $objectProperty.Add('DaysSinceCreated', (NEW-TIMESPAN -Start $filedetails.LastWriteTime -End $(get-date)).TotalDays)
        $resultEntry = New-Object -TypeName psobject -Property $objectProperty

        #add the entry to our result
        $result.Add($resultEntry) | Out-Null
    };

    return $result
}

function Get-VersionInfo($file){
    $ver = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($file.FullName).ProductVersion.ToString().Replace(",", ".")
    return $ver
}

<#
.SYNOPSIS
Identifies the patch status of an application.

.DESCRIPTION
This function determines whether an application was installed with the Essential Eight Application Patching maturity window, and whether the installed version has any critical vulnerabilities.

.PARAMETER results
An array of files to check, generated by Get-Detail.

.PARAMETER AppName
The application to examine.

.PARAMETER AppPath
A string containing the path where the application is installed.

.PARAMETER AppVersionDataLocation
A string containing the path where the application version data is stored.

.PARAMETER AppCriticalDataLocation
A string containing the path where the compressed application CVE data is stored.

.PARAMETER Strict
Whether tests should be strict (see Get-AppVersionCritical)
#>
function Resolve-PatchStatus {
    Param
    (
        [Parameter(Position = 0)] # Positional parameter
        [System.Collections.ArrayList]$results,
        [Parameter(Position = 1)] # Positional parameter
        [string]$AppName,
        [Parameter(Position = 2)] # Positional parameter
        [string]$AppPath,
        [Parameter(Position = 3)] # Positional parameter
        [string]$AppVersionDataLocation,
        [Parameter(Position = 4)] # Positional parameter
        [string]$AppCriticalDataLocation,
        [Parameter(Position = 5)] # Positional parameter
        [switch]$Strict #if this is set, don't make the last element of the version optional, e.g. MUST be 1.2.3.4 rather than 1.2.3.X
    )
    #internal variables
    $failedsteps = 0 #defaults to zero, so if you don't indicate anything failed, the test will be regarded as successful
    $messages = [System.Collections.ArrayList]@()
    #get the last updated time of the FOLDER install, as this will likely have at least one file modified on the date it was updated
    $LastUpdateDate = (Get-Item $AppPath | Select-Object -First 1).LastWriteTime
    $DaysSinceLastUpdate = (NEW-TIMESPAN -Start $LastUpdateDate -End $(get-date)).TotalDays
    foreach ($result in $results) {
        #collect information
        $ver = $result.Version
        try {
            $over = Get-AppVersionDetail -VersionToCheck $ver -AppVersionDataLocation $AppVersionDataLocation    
        }
        catch {
            $failedsteps++
            $messages.Add(@{"MessageType" = "FAILED_ERROR"; "Message" = "Some kind of exception occurred: $_" }) | Out-Null
            return $failedsteps, $messages
        }
        $criticals = Get-AppVersionCritical -VersionToCheck $ver -AppCriticalDataLocation $AppCriticalDataLocation -Strict:$Strict

        #don't know about this version, approximate based on file creation time
        if ($over.UnknownNewVersion) {
            $UpdateDelay = $result.DaysSinceCreated - $DaysSinceLastUpdate
            $DaysSinceRelease = $result.DaysSinceCreated
            $approximate = "approximately (based on file creation) "
        }
        #know the version, but it's approximate
        elseif ($over.ReleaseDate -and $over.ApproximateReleaseDate) {
            $UpdateDelay = $over.DaysSinceRelease - $DaysSinceLastUpdate
            $DaysSinceRelease = $over.DaysSinceRelease
            $approximate = "approximately (based on other version information) "
        }
        #know the version
        elseif ($over.ReleaseDate -and -not $over.ApproximateReleaseDate) {
            $UpdateDelay = $over.DaysSinceRelease - $DaysSinceLastUpdate
            $DaysSinceRelease = $over.DaysSinceRelease
        }
        #same as above, cover edge cases using file info
        else {
            $UpdateDelay = $result.DaysSinceCreated - $DaysSinceLastUpdate
            $DaysSinceRelease = $result.DaysSinceCreated
            $approximate = "approximately (based on file creation) "
        }

        #determine maturity
        $levels = (14, 2)
        if ($UpdateDelay -gt $levels[0]) { $lvl = 0 }
        if ($UpdateDelay -le $levels[0]) { $lvl = 2 }
        if ($UpdateDelay -le $levels[1]) { $lvl = 3 }

        #max maturity can't be higher than the maturity level
        $minmaturitytopass = ((Get-Item ..) | where-object { $_.Name -match "^Maturity" }); if ($minmaturitytopass) { $minmaturitytopass = [int]($minmaturitytopass.Name[-1].ToString()) } else { $minmaturitytopass = 1 }
        if ($lvl -gt $minmaturitytopass) { $lvl = $minmaturitytopass }

        #calculate information messages
        $delayinfo = "{0} ({1}), version {2} was released {3}{4:n0} days ago, and installed {5:n0} days ago, a delay of {6:n0} days, with a resultant maturity of {7}." -f $AppName, $result.Path, $result.Version, $approximate, $DaysSinceRelease, $DaysSinceLastUpdate, $updateDelay, $lvl
        $criticalinfo = "{0} ({1}), version {2} has {3} identified critical vulnerabilities." -f $AppName, $result.Path, $result.Version, $criticals.Count

        if ($criticals -gt 0) {
            $messages.Add(@{"MessageType" = "FAILED"; "Message" = $criticalinfo }) | Out-Null #out-null suppresses count of items
            $messages.Add(@{"MessageType" = "REMEDIATION"; "Message" = "This version of $AppName has critical vulnerabilities. Install the latest update." }) | Out-Null #out-null suppresses count of items
            $messages.Add(@{"MessageType" = "DEBUG"; "Message" = "This version has the following associated CVEs: $($criticals.GetEnumerator() -join ",")" }) | Out-Null
            $failedsteps++;
        }
        else {
            $messages.Add(@{"MessageType" = "SUCCESS"; "Message" = $criticalinfo }) | Out-Null #out-null suppresses count of items
        }
        if ($lvl -lt $minmaturitytopass) {
            $messages.Add(@{"MessageType" = "FAILED"; "Message" = $delayinfo }) | Out-Null #out-null suppresses count of items
            $messages.Add(@{"MessageType" = "REMEDIATION"; "Message" = "This version of $AppName was installed more than $($levels[$lvl+1]) days after the update was released. Consider methods to improve timeliness of user application patching." }) | Out-Null #out-null suppresses count of items
            $failedsteps++;
        }
        else {
            $messages.Add(@{"MessageType" = "SUCCESS"; "Message" = $delayinfo }) | Out-Null #out-null suppresses count of items
        }
    }
    return $failedsteps, $messages
}

#Package date: 2024-10-16; Build Version: d215424
#Requires -Version 3.0


# SIG # Begin signature block
# MIIoeAYJKoZIhvcNAQcCoIIoaTCCKGUCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDtfzRoW6u8Zwg9
# 2xB1ja3v0ydwpqhxfb/L0l0uGD5k96CCDeowggawMIIEmKADAgECAhAIrUCyYNKc
# TJ9ezam9k67ZMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0z
# NjA0MjgyMzU5NTlaMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQDVtC9C0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0
# JAfhS0/TeEP0F9ce2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJr
# Q5qZ8sU7H/Lvy0daE6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhF
# LqGfLOEYwhrMxe6TSXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+F
# LEikVoQ11vkunKoAFdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh
# 3K3kGKDYwSNHR7OhD26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJ
# wZPt4bRc4G/rJvmM1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQay
# g9Rc9hUZTO1i4F4z8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbI
# YViY9XwCFjyDKK05huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchAp
# QfDVxW0mdmgRQRNYmtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRro
# OBl8ZhzNeDhFMJlP/2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IB
# WTCCAVUwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+
# YXsIiGX0TkIwHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0P
# AQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAC
# hjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9v
# dEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAED
# MAgGBmeBDAEEATANBgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql
# +Eg08yy25nRm95RysQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFF
# UP2cvbaF4HZ+N3HLIvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1h
# mYFW9snjdufE5BtfQ/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3Ryw
# YFzzDaju4ImhvTnhOE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5Ubdld
# AhQfQDN8A+KVssIhdXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw
# 8MzK7/0pNVwfiThV9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnP
# LqR0kq3bPKSchh/jwVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatE
# QOON8BUozu3xGFYHKi8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bn
# KD+sEq6lLyJsQfmCXBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQji
# WQ1tygVQK+pKHJ6l/aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbq
# yK+p/pQd52MbOoZWeE4wggcyMIIFGqADAgECAhAP3GnppLmrUp/TG1q4uFF+MA0G
# CSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwHhcNMjQwOTE2MDAwMDAwWhcNMjcxMDEx
# MjM1OTU5WjCBuTELMAkGA1UEBhMCQVUxGjAYBgNVBAgTEVdlc3Rlcm4gQXVzdHJh
# bGlhMREwDwYDVQQHEwhLb2phcmVuYTEnMCUGA1UEChMeQXVzdHJhbGlhbiBTaWdu
# YWxzIERpcmVjdG9yYXRlMSkwJwYDVQQLEyBBdXN0cmFsaWFuIEN5YmVyIFNlY3Vy
# aXR5IENlbnRyZTEnMCUGA1UEAxMeQXVzdHJhbGlhbiBTaWduYWxzIERpcmVjdG9y
# YXRlMIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAw0cTiNUzc3vbheXu
# Z741I3JRxbhU5iLiP1IBSZP3amEIPPdR5JEbgh1OrMUSXOzBBo8JKTYwCLztOiyv
# jUEdeRGFXvWPq04aNoiSeU8/mCWjcQ+Jb0TYsrpLFsCgdRLjCIJrzbss4lTgK1Tm
# UIHMJarlrJwLurhp58BAIwEhQpr2eUUzjw2jGGwm85suDNRq9pJb5cHDYSDLGumL
# 6br5QuHClb3pIcZBY7Qh/Hw5WYALHqWO5EuSAfWVAtieBy5qLUi2Xi3/9WTh1sAg
# 8XEeUXwE0DjbL4UlgNtL4OUYNcABGvolOsT/tFPGwch/LrQZCKN8P/pDfOAon+qy
# AW9sqU+mSVPT7oPzEirFgnVyXaP2oVAAM8WQLm9VNHcetkunAyREvT/wzgx8/Lbj
# NJV+ZvDr2bNTuEfQn7OVe2ndR6tXJqeuRfDjyj0z9GGpcsfVButoYM3lRJz7X58D
# 2oRUT/aQn4MTWGWjEmbrbDQtV2IJxVXzwRRVsy1rnWjCJzJVAgMBAAGjggIDMIIB
# /zAfBgNVHSMEGDAWgBRoN+Drtjv4XxGG+/5hewiIZfROQjAdBgNVHQ4EFgQUHzn7
# SCjwpCIAZVQj8S3DVGL/mtcwPgYDVR0gBDcwNTAzBgZngQwBBAEwKTAnBggrBgEF
# BQcCARYbaHR0cDovL3d3dy5kaWdpY2VydC5jb20vQ1BTMA4GA1UdDwEB/wQEAwIH
# gDATBgNVHSUEDDAKBggrBgEFBQcDAzCBtQYDVR0fBIGtMIGqMFOgUaBPhk1odHRw
# Oi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmlu
# Z1JTQTQwOTZTSEEzODQyMDIxQ0ExLmNybDBToFGgT4ZNaHR0cDovL2NybDQuZGln
# aWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hB
# Mzg0MjAyMUNBMS5jcmwwgZQGCCsGAQUFBwEBBIGHMIGEMCQGCCsGAQUFBzABhhho
# dHRwOi8vb2NzcC5kaWdpY2VydC5jb20wXAYIKwYBBQUHMAKGUGh0dHA6Ly9jYWNl
# cnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNB
# NDA5NlNIQTM4NDIwMjFDQTEuY3J0MAkGA1UdEwQCMAAwDQYJKoZIhvcNAQELBQAD
# ggIBAJQ6toTdsoB0xPBqLd9tjHbN1vFAnjiqwHMsONbgVz5nqkqxdfFdcJbC+u9i
# b0sKaLl3lTzgUsvvleVu4tKK1hl0FWfwlAInypuC1a1UnKzGjRLMoNyz2AOVGSl7
# Y5PrVClnEuG8O5zxqNYkiN2IZHlVj2xZP10kLNL2sSRGaoiZqoEIW8z0G68gjrou
# Jgdgw14lt7QsGpUAcPMI9/l/hbyZIOPWPJus+Ock4hHPWiApVLlARki/2fE1IWXE
# b6KNgNYpcup3JvX/XzCHEM+cXZ2qcBwOdCukiroqxR0ku/yn59HMT3MG6o3GJGth
# sBLS9K5Vzg+YMSkV6iMnTi8sQknZA564Gk3gdv0SzF2MGT5Pc7p/IH4o4wPjn9Md
# fi3IDe1SRZeDa2I2qfjmLJ1VJWyug1NmbnXJTz7NeLODXNTDcLgFWNeokB71fhnn
# 6PQhCF2l7xITwrAbsY2lHiykV9b0QFhWKemNUKY3PW3no43fUci+ttxBrMpIHejC
# +1/rZcImMKgZVsMqRJJTAh/TW0aYZSRgz4sngv9HY/LYcmEQpgYpzGAIBKArgzBR
# A6riFJ+azKkOCK1trgO7k0giQ3xN2asmcDRzBjtrVY6vutNSPPXHL98WwHh46KLg
# m+tyhiPaG++Z/v1Pq2CWcKIvuzS3RyjOSQl77j5cjrbTxOmeMYIZ5DCCGeACAQEw
# fTBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNV
# BAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgQ29kZSBTaWduaW5nIFJTQTQwOTYgU0hB
# Mzg0IDIwMjEgQ0ExAhAP3GnppLmrUp/TG1q4uFF+MA0GCWCGSAFlAwQCAQUAoHww
# EAYKKwYBBAGCNwIBDDECMAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIMAKc1Sl
# 3kdFiVW6ojbxOKMDnf1R/qEJ5jY8EF7kluRqMA0GCSqGSIb3DQEBAQUABIIBgDzk
# OR/vUfqqfve8PmV2d0ZPOlo4/3BkfYk3bGvuRlppJrsC67viY2hn6SxruSeEa7ZQ
# sRzSt7nYIybNtpX6PAD986ypt2m09I/+krOYQUMEJwWLClcoXonX3m1ubgT8nnfO
# yLzI+H9eFlxBCfJTS7gphIkQYq571PBfNZx8maDqbrJXLb1AmvNFXZQqsk3zCEWa
# pL5N4I8yfeD4hfs+aaH1PyYUm+iRylfQpNvQkcEKO1yEH7CGFwBUprTlcZ1trn8i
# JDmU2a4zXNSvRk94eSyK9Kf0zpuiLq/lEiz18JhTEXMaf98okop2HUiDf3sWfawm
# KlIeYPJzcoLXE9hV69LcDcKcJKgMz5ngp9UJEsCCMr3rUF23fnZ1eqmg0e2nnGJM
# QSfJYm3KaSpYlNELsTuL7ecpSnqv5z8x5ixRybLTjaoW890H60kNUWeCkOIKfQza
# N++9wE9bzi6AiUVJBGquh5gCgI4+xiaXMGEA1jz5uaD89KFzfqAvYBgdog3RtqGC
# Fzowghc2BgorBgEEAYI3AwMBMYIXJjCCFyIGCSqGSIb3DQEHAqCCFxMwghcPAgED
# MQ8wDQYJYIZIAWUDBAIBBQAweAYLKoZIhvcNAQkQAQSgaQRnMGUCAQEGCWCGSAGG
# /WwHATAxMA0GCWCGSAFlAwQCAQUABCA4pKnUYi1jLwM9qFbiPPy/6FlgGoqEkewh
# 8F8FqCZQ4QIRAKL/V7sydNnlzD9EiSk6V+UYDzIwMjQxMDE2MDYxNTE2WqCCEwMw
# gga8MIIEpKADAgECAhALrma8Wrp/lYfG+ekE4zMEMA0GCSqGSIb3DQEBCwUAMGMx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMy
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcg
# Q0EwHhcNMjQwOTI2MDAwMDAwWhcNMzUxMTI1MjM1OTU5WjBCMQswCQYDVQQGEwJV
# UzERMA8GA1UEChMIRGlnaUNlcnQxIDAeBgNVBAMTF0RpZ2lDZXJ0IFRpbWVzdGFt
# cCAyMDI0MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAvmpzn/aVIauW
# MLpbbeZZo7Xo/ZEfGMSIO2qZ46XB/QowIEMSvgjEdEZ3v4vrrTHleW1JWGErrjOL
# 0J4L0HqVR1czSzvUQ5xF7z4IQmn7dHY7yijvoQ7ujm0u6yXF2v1CrzZopykD07/9
# fpAT4BxpT9vJoJqAsP8YuhRvflJ9YeHjes4fduksTHulntq9WelRWY++TFPxzZrb
# ILRYynyEy7rS1lHQKFpXvo2GePfsMRhNf1F41nyEg5h7iOXv+vjX0K8RhUisfqw3
# TTLHj1uhS66YX2LZPxS4oaf33rp9HlfqSBePejlYeEdU740GKQM7SaVSH3TbBL8R
# 6HwX9QVpGnXPlKdE4fBIn5BBFnV+KwPxRNUNK6lYk2y1WSKour4hJN0SMkoaNV8h
# yyADiX1xuTxKaXN12HgR+8WulU2d6zhzXomJ2PleI9V2yfmfXSPGYanGgxzqI+Sh
# oOGLomMd3mJt92nm7Mheng/TBeSA2z4I78JpwGpTRHiT7yHqBiV2ngUIyCtd0pZ8
# zg3S7bk4QC4RrcnKJ3FbjyPAGogmoiZ33c1HG93Vp6lJ415ERcC7bFQMRbxqrMVA
# Niav1k425zYyFMyLNyE1QulQSgDpW9rtvVcIH7WvG9sqYup9j8z9J1XqbBZPJ5XL
# ln8mS8wWmdDLnBHXgYly/p1DhoQo5fkCAwEAAaOCAYswggGHMA4GA1UdDwEB/wQE
# AwIHgDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMCAGA1Ud
# IAQZMBcwCAYGZ4EMAQQCMAsGCWCGSAGG/WwHATAfBgNVHSMEGDAWgBS6FtltTYUv
# cyl2mi91jGogj57IbzAdBgNVHQ4EFgQUn1csA3cOKBWQZqVjXu5Pkh92oFswWgYD
# VR0fBFMwUTBPoE2gS4ZJaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# VHJ1c3RlZEc0UlNBNDA5NlNIQTI1NlRpbWVTdGFtcGluZ0NBLmNybDCBkAYIKwYB
# BQUHAQEEgYMwgYAwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNv
# bTBYBggrBgEFBQcwAoZMaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lD
# ZXJ0VHJ1c3RlZEc0UlNBNDA5NlNIQTI1NlRpbWVTdGFtcGluZ0NBLmNydDANBgkq
# hkiG9w0BAQsFAAOCAgEAPa0eH3aZW+M4hBJH2UOR9hHbm04IHdEoT8/T3HuBSyZe
# q3jSi5GXeWP7xCKhVireKCnCs+8GZl2uVYFvQe+pPTScVJeCZSsMo1JCoZN2mMew
# /L4tpqVNbSpWO9QGFwfMEy60HofN6V51sMLMXNTLfhVqs+e8haupWiArSozyAmGH
# /6oMQAh078qRh6wvJNU6gnh5OruCP1QUAvVSu4kqVOcJVozZR5RRb/zPd++PGE3q
# F1P3xWvYViUJLsxtvge/mzA75oBfFZSbdakHJe2BVDGIGVNVjOp8sNt70+kEoMF+
# T6tptMUNlehSR7vM+C13v9+9ZOUKzfRUAYSyyEmYtsnpltD/GWX8eM70ls1V6QG/
# ZOB6b6Yum1HvIiulqJ1Elesj5TMHq8CWT/xrW7twipXTJ5/i5pkU5E16RSBAdOp1
# 2aw8IQhhA/vEbFkEiF2abhuFixUDobZaA0VhqAsMHOmaT3XThZDNi5U2zHKhUs5u
# HHdG6BoQau75KiNbh0c+hatSF+02kULkftARjsyEpHKsF7u5zKRbt5oK5YGwFvgc
# 4pEVUNytmB3BpIiowOIIuDgP5M9WArHYSAR16gc0dP2XdkMEP5eBsX7bf/MGN4K3
# HP50v/01ZHo/Z5lGLvNwQ7XHBx1yomzLP8lx4Q1zZKDyHcp4VQJLu2kWTsKsOqQw
# ggauMIIElqADAgECAhAHNje3JFR82Ees/ShmKl5bMA0GCSqGSIb3DQEBCwUAMGIx
# CzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3
# dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBH
# NDAeFw0yMjAzMjMwMDAwMDBaFw0zNzAzMjIyMzU5NTlaMGMxCzAJBgNVBAYTAlVT
# MRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMyRGlnaUNlcnQgVHJ1
# c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcgQ0EwggIiMA0GCSqG
# SIb3DQEBAQUAA4ICDwAwggIKAoICAQDGhjUGSbPBPXJJUVXHJQPE8pE3qZdRodbS
# g9GeTKJtoLDMg/la9hGhRBVCX6SI82j6ffOciQt/nR+eDzMfUBMLJnOWbfhXqAJ9
# /UO0hNoR8XOxs+4rgISKIhjf69o9xBd/qxkrPkLcZ47qUT3w1lbU5ygt69OxtXXn
# HwZljZQp09nsad/ZkIdGAHvbREGJ3HxqV3rwN3mfXazL6IRktFLydkf3YYMZ3V+0
# VAshaG43IbtArF+y3kp9zvU5EmfvDqVjbOSmxR3NNg1c1eYbqMFkdECnwHLFuk4f
# sbVYTXn+149zk6wsOeKlSNbwsDETqVcplicu9Yemj052FVUmcJgmf6AaRyBD40Nj
# gHt1biclkJg6OBGz9vae5jtb7IHeIhTZgirHkr+g3uM+onP65x9abJTyUpURK1h0
# QCirc0PO30qhHGs4xSnzyqqWc0Jon7ZGs506o9UD4L/wojzKQtwYSH8UNM/STKvv
# mz3+DrhkKvp1KCRB7UK/BZxmSVJQ9FHzNklNiyDSLFc1eSuo80VgvCONWPfcYd6T
# /jnA+bIwpUzX6ZhKWD7TA4j+s4/TXkt2ElGTyYwMO1uKIqjBJgj5FBASA31fI7tk
# 42PgpuE+9sJ0sj8eCXbsq11GdeJgo1gJASgADoRU7s7pXcheMBK9Rp6103a50g5r
# mQzSM7TNsQIDAQABo4IBXTCCAVkwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4E
# FgQUuhbZbU2FL3MpdpovdYxqII+eyG8wHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5n
# P+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMIMHcG
# CCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQu
# Y29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGln
# aUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8v
# Y3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAgBgNV
# HSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEwDQYJKoZIhvcNAQELBQADggIB
# AH1ZjsCTtm+YqUQiAX5m1tghQuGwGC4QTRPPMFPOvxj7x1Bd4ksp+3CKDaopafxp
# wc8dB+k+YMjYC+VcW9dth/qEICU0MWfNthKWb8RQTGIdDAiCqBa9qVbPFXONASIl
# zpVpP0d3+3J0FNf/q0+KLHqrhc1DX+1gtqpPkWaeLJ7giqzl/Yy8ZCaHbJK9nXzQ
# cAp876i8dU+6WvepELJd6f8oVInw1YpxdmXazPByoyP6wCeCRK6ZJxurJB4mwbfe
# Kuv2nrF5mYGjVoarCkXJ38SNoOeY+/umnXKvxMfBwWpx2cYTgAnEtp/Nh4cku0+j
# Sbl3ZpHxcpzpSwJSpzd+k1OsOx0ISQ+UzTl63f8lY5knLD0/a6fxZsNBzU+2QJsh
# IUDQtxMkzdwdeDrknq3lNHGS1yZr5Dhzq6YBT70/O3itTK37xJV77QpfMzmHQXh6
# OOmc4d0j/R0o08f56PGYX/sr2H7yRp11LB4nLCbbbxV7HhmLNriT1ObyF5lZynDw
# N7+YAN8gFk8n+2BnFqFmut1VwDophrCYoCvtlUG3OtUVmDG0YgkPCr2B2RP+v6TR
# 81fZvAT6gt4y3wSJ8ADNXcL50CN/AAvkdgIm2fBldkKmKYcJRyvmfxqkhQ/8mJb2
# VVQrH4D6wPIOK+XW+6kvRBVK5xMOHds3OBqhK/bt1nz8MIIFjTCCBHWgAwIBAgIQ
# DpsYjvnQLefv21DiCEAYWjANBgkqhkiG9w0BAQwFADBlMQswCQYDVQQGEwJVUzEV
# MBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29t
# MSQwIgYDVQQDExtEaWdpQ2VydCBBc3N1cmVkIElEIFJvb3QgQ0EwHhcNMjIwODAx
# MDAwMDAwWhcNMzExMTA5MjM1OTU5WjBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMM
# RGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQD
# ExhEaWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwggIiMA0GCSqGSIb3DQEBAQUAA4IC
# DwAwggIKAoICAQC/5pBzaN675F1KPDAiMGkz7MKnJS7JIT3yithZwuEppz1Yq3aa
# za57G4QNxDAf8xukOBbrVsaXbR2rsnnyyhHS5F/WBTxSD1Ifxp4VpX6+n6lXFllV
# cq9ok3DCsrp1mWpzMpTREEQQLt+C8weE5nQ7bXHiLQwb7iDVySAdYyktzuxeTsiT
# +CFhmzTrBcZe7FsavOvJz82sNEBfsXpm7nfISKhmV1efVFiODCu3T6cw2Vbuyntd
# 463JT17lNecxy9qTXtyOj4DatpGYQJB5w3jHtrHEtWoYOAMQjdjUN6QuBX2I9YI+
# EJFwq1WCQTLX2wRzKm6RAXwhTNS8rhsDdV14Ztk6MUSaM0C/CNdaSaTC5qmgZ92k
# J7yhTzm1EVgX9yRcRo9k98FpiHaYdj1ZXUJ2h4mXaXpI8OCiEhtmmnTK3kse5w5j
# rubU75KSOp493ADkRSWJtppEGSt+wJS00mFt6zPZxd9LBADMfRyVw4/3IbKyEbe7
# f/LVjHAsQWCqsWMYRJUadmJ+9oCw++hkpjPRiQfhvbfmQ6QYuKZ3AeEPlAwhHbJU
# KSWJbOUOUlFHdL4mrLZBdd56rF+NP8m800ERElvlEFDrMcXKchYiCd98THU/Y+wh
# X8QgUWtvsauGi0/C1kVfnSD8oR7FwI+isX4KJpn15GkvmB0t9dmpsh3lGwIDAQAB
# o4IBOjCCATYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQU7NfjgtJxXWRM3y5n
# P+e6mK4cD08wHwYDVR0jBBgwFoAUReuir/SSy4IxLVGLp6chnfNtyA8wDgYDVR0P
# AQH/BAQDAgGGMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29j
# c3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3J0MEUGA1UdHwQ+MDww
# OqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RFJvb3RDQS5jcmwwEQYDVR0gBAowCDAGBgRVHSAAMA0GCSqGSIb3DQEBDAUAA4IB
# AQBwoL9DXFXnOF+go3QbPbYW1/e/Vwe9mqyhhyzshV6pGrsi+IcaaVQi7aSId229
# GhT0E0p6Ly23OO/0/4C5+KH38nLeJLxSA8hO0Cre+i1Wz/n096wwepqLsl7Uz9FD
# RJtDIeuWcqFItJnLnU+nBgMTdydE1Od/6Fmo8L8vC6bp8jQ87PcDx4eo0kxAGTVG
# amlUsLihVo7spNU96LHc/RzY9HdaXFSMb++hUD38dglohJ9vytsgjTVgHAIDyyCw
# rFigDkBjxZgiwbJZ9VVrzyerbHbObyMt9H5xaiNrIv8SuFQtJ37YOtnwtoeW/VvR
# XKwYw02fc7cBqZ9Xql4o4rmUMYIDdjCCA3ICAQEwdzBjMQswCQYDVQQGEwJVUzEX
# MBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNVBAMTMkRpZ2lDZXJ0IFRydXN0
# ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1waW5nIENBAhALrma8Wrp/lYfG
# +ekE4zMEMA0GCWCGSAFlAwQCAQUAoIHRMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0B
# CRABBDAcBgkqhkiG9w0BCQUxDxcNMjQxMDE2MDYxNTE2WjArBgsqhkiG9w0BCRAC
# DDEcMBowGDAWBBTb04XuYtvSPnvk9nFIUIck1YZbRTAvBgkqhkiG9w0BCQQxIgQg
# WPjAqp+8hFxZoNmhN4crXak3RzgTfaxIKAlt0cjYZpUwNwYLKoZIhvcNAQkQAi8x
# KDAmMCQwIgQgdnafqPJjLx9DCzojMK7WVnX+13PbBdZluQWTmEOPmtswDQYJKoZI
# hvcNAQEBBQAEggIAESCLjbUCHw9ctn5tvyUXo4j/iMH++0s6Rw6AxHDyTG+R3uD0
# krBhjiEx8/S/bH0Tc1II9XbtoYVrAKEXTuRNYwThZnq/MwpnQWhAaIK2MgDNdTn0
# UFtQHB3eVB/wCTj3rbpmyIZWw+EppwmYCXrjMZLLthoh7bHD42QqJl5VWkU1HapH
# oO7e6Io8WNBoRLtUiWIzQAb/eVhjrOalBqB5NB6cy2mxqujaSQBLHQwUiYde6aKP
# zJcv0XEY39/SbbND0o06OVKXPxdDvWBJP376q05K7fNIzYy9HEodaJuK+EwRoDYP
# cGZy41cmhYhIeKrrZlL/1p6/7pWe1c5p1SJNihx96EzYhJBgOmtftqI2iOWTBxZW
# M+xvzwsYvCiUovZ+oSq28lCcl8c8dMH0+25LcaCra4sfS/D67H4rS/cuno15DsZx
# 8kGjZWN5jZVC6xErwO0yJWyfTdbKCKsXnSAIWpTT+K+hLT8oDS+NDAjBuFKeuFeG
# 8oYpvYZtuIczVgT/xg257trmuMqA43zDZ6mGOPC5ZoNOC5v3VOUpNnhoILSPVku+
# zEpQqyMgO1nwnMwLggV2LFACKd3DbdSIu/8/lMUcjPcjgAILa+7+hdacq7sCwK8M
# TUxn9tK4tgrILsxbFWT8gX7POMpmVUf0venUrc8XTXsasBrXYvz2h6R+JO4=
# SIG # End signature block
