<#
.SYNOPSIS
This script automatically assesses the Essential 8 Maturity of the system it is executed on.

.DESCRIPTION
The Essential Eight Maturity Verification Tool (E8MVT) is designed to give a single-system snapshot of Essential Eight maturity.
E8MVT consists of several modules, stored in the 'modules' folder, associated with the Essential Eight.
There is an additional model focused on system hardening, which is not reported on in the E8 report.
Each module assesses one or more maturity levels, via a collection of tests.
There are some additional "non-maturity" tests, which are not sufficiently reliable to include in the primary report.
Tests can return success or failure, and to achieve a maturity level all tests must succeed.
On completion, all outputs can be viewed in the "Reports" folder, or an alternative output path specified by the user.

.EXAMPLE
.\essential8-maturity-verification-tool-november-2023.ps1

.PARAMETER OutputPath
Where to put output files, defaults to .\Reports
.PARAMETER DontPauseOnCompletion
Don't pause the script when complete, off by default (intended for scripting)
.PARAMETER AcceptWarning
Accept the startup warning, off by default
.PARAMETER DoNotOpenReport
Do not open the report on completion, off by default.
.PARAMETER MaturityTestsOnly
Only perform Maturity Level tests, off by default
.PARAMETER TrustedLocation
A Trusted Location that can be used by Office for macro tests

.INPUTS
None. You cannot pipe objects to this tool.

.LINK 
https://www.cyber.gov.au/acsc/view-all-content/publications/essential-eight-maturity-model
#>


#handle arguments
param (
    #[Parameter(Mandatory = $false)][switch]$Progress, #Progress = Show script progress, off by default (currently not implemented)
    [Parameter(Mandatory = $false)][switch]$DontPauseOnCompletion,
    [Parameter(Mandatory = $false)][switch]$AcceptWarning,
    [Parameter(Mandatory = $false)][switch]$DoNotOpenReport,
    [Parameter(Mandatory = $false)][string]$OutputPath = ".\Reports",
    [Parameter(Mandatory = $false)][switch]$MaturityTestsOnly,
    [Parameter(Mandatory = $false)][string]$TrustedLocation,
    [Parameter(Mandatory = $false)][switch]$DisableASRTests = $false
)

#Set the product version to include in output
$productversion = "2.1.0"

#Identify use of constrained language mode prior to it causing errors
$pslangmode = $ExecutionContext.SessionState.LanguageMode
if ($pslangmode -notmatch "FullLanguage") {
    Write-Verbose -Verbose -Message "This system is configured with some kind of PowerShell restricted language mode. You should disable this restriction while running this tool, then re-enable it once complete."
    exit
}
else {
    Write-Verbose -Verbose -Message "This system is running in PowerShell full language mode."
}

#enable transcription, store data
$runtime = $((get-date).ToString("yyyy-MM-dd_HH-mm"))

#Attach the git commit version to the product version for troubleshooting
$global:e8mvtversion = "$productversion-d215424"
#get hostname...
$hostname = $env:COMPUTERNAME
if ($env:USERDNSDOMAIN) { $hostname = "$hostname.${env:USERDNSDOMAIN}" }
elseif (-not $env:USERDOMAIN -eq $env:COMPUTERNAME) { $hostname = "$hostname.${env:USERDOMAIN}" }
else { $hostname = "$hostname" }
$debugfolderpath = "${OutputPath}\Debug Data (${hostname}_${runtime}_v${global:e8mvtversion})"
New-item -Path $OutputPath -ItemType "directory" -Force | out-null #suppress output
New-Item -Path ${debugfolderpath} -ItemType "directory" -Force | out-null #suppress output
Start-Transcript -path "${debugfolderpath}\e8mvt_transcript_${hostname}_${runtime}_v${global:e8mvtversion}.log" -append

#show warning prompt prior to execution, unless option flag set
if (-not $AcceptWarning) {
    #check acceptance message
    Add-Type -AssemblyName PresentationFramework
    $msgBoxInput = [System.Windows.MessageBox]::Show("By clicking 'Yes', you are accepting responsiblity for any consequences of running this tool, and confirming you have read and understood the E8MVT User Guide. Press 'Yes' if you wish to continue.", 'Run E8MVT', 'YesNo', 'Error')
    switch ($msgBoxInput) {
        'Yes' {
            Write-Verbose -Verbose -Message "User has accepted responsibility for executing this tool."
        }
        'No' {
            Write-Verbose -Verbose -Message "User decided to exit without running the tool."
            Read-Host -Prompt "Press Enter to exit"
            exit
        }
        Default {
            exit
        }
    }
}

#set globals
$global:signerthumbprint = "92720e633ca75ab4c5b97fc3d5ea34cb2f1130b5"
$global:E8MVTPath = (Get-Item ".").FullName
$global:ScriptsPath = (Get-Item ".\Resources\Scripts").FullName
$global:DataPath = (Get-Item ".\Resources\Data").FullName
$global:DisableASRTests = $DisableASRTests
if(!$TrustedLocation){
    $global:TrustedLocation = ($env:TEMP).FullName
}
else{
    $global:TrustedLocation = $TrustedLocation
}
#verify and import core powershell modules
$ImportPath = (Get-Item $global:ScriptsPath).FullName
$Imports = (Get-ChildItem "$ImportPath\*.psm1").FullName
foreach($import in $Imports)
{
    $signingstatus = Get-AuthenticodeSignature $import
    if ($signingstatus.SignerCertificate.Thumbprint -eq $signerthumbprint -and $signingstatus.Status.ToString() -eq "Valid") {
        Import-Module $import.Substring(0,$import.Length-5) -Force        
    }
    else {
        Write-Error "Core component is not validly signed: $import"
        Read-Host -Prompt "Press Enter to exit"
        exit
    }
}

#maturity folder names
$maturitypattern = "^Maturity "

#unblock all the files from webdownload (remove "mark of the web")
Write-Verbose -Verbose -Message "Unblocking Cyber Toolbox files..."
Get-ChildItem -Path . -recurse -include *.ps1, *.psm1 | Unblock-file
Write-Verbose -Verbose -Message "Unblocked Cyber Toolbox files."
#get modules
$modulelist = Get-ChildItem -Path ./modules

#process each module
foreach ($module in $modulelist) {
    $module_elements = Get-ChildItem -Path $module.FullName -Directory

    #Maturity Level Tests, starts with "Maturity_", then the level
    $maturitylevels = $module_elements | Where-Object { $_.Name -match $maturitypattern } | Sort-Object #ensure maturity levels performed in order
    if ($maturitylevels.Length -gt 0) {

        $maxmaturity = ($maturitylevels.BaseName[-1]) -replace '[^0-9]',''

        foreach ($element in $maturitylevels) {
            #run the test cases
            Write-Verbose -Verbose -Message ("{0} - {1}" -f $module, $element)
            $resultset = Invoke-TestCaseFolder($element)

            #process the results
            $failed_tests = Get-FailedTest($resultset)

            #save maturity success/failure
            if ($failed_tests -gt 0) {
                #Threshold would be checked here to allow for ticking X out of Y boxes gives a pass, but is not currently, as for all tests the threshold is zero.
                Add-Log -hostname $hostname -runtime $runtime -debugfolderpath $debugfolderpath -module $module.Name -element $element.Name -test "[Maturity Assessment, Maximum Assessable Maturity is $maxmaturity]" -status "FAILED" -message "Failed at this maturity level."
            }
            else {
                Add-Log -hostname $hostname -runtime $runtime -debugfolderpath $debugfolderpath -module $module.Name -element $element.Name -test "[Maturity Assessment, Maximum Assessable Maturity is $maxmaturity]" -status "SUCCESS" -message "Achieved this maturity level."
            }

            #print data
            foreach ($result in $resultset) {
                foreach ($msg in $result.testdata.details) {
                    Add-Log -hostname $hostname -runtime $runtime -debugfolderpath $debugfolderpath -module $module.Name -element $element.Name -test $result.testname -status $msg.MessageType -message $msg.Message
                }
            }

        }
    }

    #non-maturity level tests
    if (-not $MaturityTestsOnly) {
        $othertests = $module_elements | Where-Object { $_.Name -notmatch $maturitypattern }
        if ($othertests.Length -gt 0) {
            foreach ($element in $othertests) {
                #run the test cases
                $resultset = Invoke-TestCaseFolder($element)

                #don't care about fails here, apparently

                #process the results
                foreach ($result in $resultset) {
                    foreach ($msg in $result.testdata.details) {
                        Add-Log -hostname $hostname -runtime $runtime -debugfolderpath $debugfolderpath -module $module.Name -element $element.Name -test $result.testname -status $msg.MessageType -message $msg.Message
                    }
                }
            }
        }
    }
}

#close out transcription
Stop-Transcript

#rename the fields
#Hostname,Timestamp,Module = Mitigation Strategy,Element = Tested Maturity Level,Test,Status = Result,Message = Details
$header = 'Tested System', 'Test Timestamp', 'Mitigation Strategy', 'Tested Maturity Level', 'Test', 'Result', 'Details'

#prepare the maturity output (SUCCESS items, FAILED items, REQUIREDINFO items, maturity assessments etc)
$debugpath = "${debugfolderpath}\e8mvt_debug_output_${hostname}_${runtime}_v${global:e8mvtversion}.csv"

$assessmentData = (Import-Csv -header $header -Path $debugpath `
    | Where-Object {`
            $_.Test -eq "[Maturity Assessment]" -or `
        ($_.Result -match "^SUCCESS" -and $_."Tested Maturity Level" -match $maturitypattern) -or `
        ($_.Result -match "^FAILED" -and $_."Tested Maturity Level" -match $maturitypattern) -or `
        ($_.Result -match "^REMEDIATION" -and $_."Tested Maturity Level" -match $maturitypattern) -or `
        ($_.Result -match "^REQUIREDINFO" -and $_."Tested Maturity Level" -match $maturitypattern) } `
    | Sort-Object -Property "Mitigation Strategy", Test, Result `
    | Select-Object -Property "Tested System", "Test Timestamp", "Mitigation Strategy", "Tested Maturity Level", Test, Result, Details)

#generate the report using HTML generator, then open it
$htmlreportpath = "${OutputPath}\E8MVT Assessment Report (${hostname}_${runtime}_v${global:e8mvtversion}).html"
New-E8MVTReport -Path $debugpath -OutputFile $htmlreportpath -DetailedReport

#export the data
$csvreportpath = "${OutputPath}\E8MVT Assessment Report (${hostname}_${runtime}_v${global:e8mvtversion}).csv"
try {
    $assessmentData | Export-CSV -Path $csvreportpath -NoTypeInformation    
}
catch {
    Write-Error "Error exporting report: $_"
}


#compress a copy of the results
$Compress = @{
    Path             = $htmlreportpath, $csvreportpath, ${debugfolderpath}
    CompressionLevel = "Optimal"
    DestinationPath  = "${OutputPath}\E8MVT Report (${hostname}_${runtime}_v${global:e8mvtversion}).zip"
}
#compress-archive available
if (Get-Command "Compress-Archive" -erroraction silentlycontinue) {
    Compress-Archive @compress
}
#not available (uses .NET 4.5)
else {
    try {
        #create temp folder
        $tempCompression = "${OutputPath}\temp_compression"
        New-Item -Path $tempCompression -ItemType "directory" -Force | out-null #suppress output

        #move files into it
        Copy-Item -Path $Compress.Path -Destination $tempCompression -recurse

        #compress temp folder
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $CompressionLevel = [System.IO.Compression.CompressionLevel]::Optimal
        [System.IO.Compression.ZipFile]::CreateFromDirectory($tempCompression,
            $Compress.DestinationPath, $CompressionLevel, $false)

        #remove temp folder
        Remove-Item $tempCompression -recurse
    }
    catch {
        Write-Error "Error compressing results file: $_"
    }
}

#show the result table (if you can, not available in PowerShell Core)
if (-not $DoNotOpenReport) {
    if (Test-Path $htmlreportpath) {
        #open it in the browser
        & $htmlreportpath
    }
    elseif (Get-Command "Out-GridView" -erroraction silentlycontinue) {
        #show it with outgridview if the html report didn't generate for whatever reason
        $assessmentData | Select-Object -Property "Mitigation Strategy", "Tested Maturity Level", Test, Result, Details | Out-GridView -Title "Essential 8 Maturity Verification Tool Results ($hostname)"
    }
    else {
        $resultfile = Resolve-Path "${OutputPath}\E8MVT Assessment Report (${hostname}_${runtime}_v${global:e8mvtversion}).csv"
        Write-Verbose -Verbose -Message "Execution completed. Results can be viewed here: $resultfile"
    }
}



#pause on completion
if (-not $DontPauseOnCompletion) {
    Read-Host -Prompt "Press Enter to exit"
}



#Package date: 2024-10-16; Build Version: d215424
#Requires -Version 3.0


# SIG # Begin signature block
# MIIoeAYJKoZIhvcNAQcCoIIoaTCCKGUCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB9mzVKqH6AkWVh
# XE1+T3iNqxXvthBKaG5iqJ2s54L556CCDeowggawMIIEmKADAgECAhAIrUCyYNKc
# TJ9ezam9k67ZMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0z
# NjA0MjgyMzU5NTlaMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQDVtC9C0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0
# JAfhS0/TeEP0F9ce2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJr
# Q5qZ8sU7H/Lvy0daE6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhF
# LqGfLOEYwhrMxe6TSXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+F
# LEikVoQ11vkunKoAFdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh
# 3K3kGKDYwSNHR7OhD26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJ
# wZPt4bRc4G/rJvmM1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQay
# g9Rc9hUZTO1i4F4z8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbI
# YViY9XwCFjyDKK05huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchAp
# QfDVxW0mdmgRQRNYmtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRro
# OBl8ZhzNeDhFMJlP/2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IB
# WTCCAVUwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+
# YXsIiGX0TkIwHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0P
# AQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAC
# hjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9v
# dEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAED
# MAgGBmeBDAEEATANBgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql
# +Eg08yy25nRm95RysQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFF
# UP2cvbaF4HZ+N3HLIvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1h
# mYFW9snjdufE5BtfQ/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3Ryw
# YFzzDaju4ImhvTnhOE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5Ubdld
# AhQfQDN8A+KVssIhdXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw
# 8MzK7/0pNVwfiThV9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnP
# LqR0kq3bPKSchh/jwVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatE
# QOON8BUozu3xGFYHKi8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bn
# KD+sEq6lLyJsQfmCXBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQji
# WQ1tygVQK+pKHJ6l/aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbq
# yK+p/pQd52MbOoZWeE4wggcyMIIFGqADAgECAhAP3GnppLmrUp/TG1q4uFF+MA0G
# CSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwHhcNMjQwOTE2MDAwMDAwWhcNMjcxMDEx
# MjM1OTU5WjCBuTELMAkGA1UEBhMCQVUxGjAYBgNVBAgTEVdlc3Rlcm4gQXVzdHJh
# bGlhMREwDwYDVQQHEwhLb2phcmVuYTEnMCUGA1UEChMeQXVzdHJhbGlhbiBTaWdu
# YWxzIERpcmVjdG9yYXRlMSkwJwYDVQQLEyBBdXN0cmFsaWFuIEN5YmVyIFNlY3Vy
# aXR5IENlbnRyZTEnMCUGA1UEAxMeQXVzdHJhbGlhbiBTaWduYWxzIERpcmVjdG9y
# YXRlMIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAw0cTiNUzc3vbheXu
# Z741I3JRxbhU5iLiP1IBSZP3amEIPPdR5JEbgh1OrMUSXOzBBo8JKTYwCLztOiyv
# jUEdeRGFXvWPq04aNoiSeU8/mCWjcQ+Jb0TYsrpLFsCgdRLjCIJrzbss4lTgK1Tm
# UIHMJarlrJwLurhp58BAIwEhQpr2eUUzjw2jGGwm85suDNRq9pJb5cHDYSDLGumL
# 6br5QuHClb3pIcZBY7Qh/Hw5WYALHqWO5EuSAfWVAtieBy5qLUi2Xi3/9WTh1sAg
# 8XEeUXwE0DjbL4UlgNtL4OUYNcABGvolOsT/tFPGwch/LrQZCKN8P/pDfOAon+qy
# AW9sqU+mSVPT7oPzEirFgnVyXaP2oVAAM8WQLm9VNHcetkunAyREvT/wzgx8/Lbj
# NJV+ZvDr2bNTuEfQn7OVe2ndR6tXJqeuRfDjyj0z9GGpcsfVButoYM3lRJz7X58D
# 2oRUT/aQn4MTWGWjEmbrbDQtV2IJxVXzwRRVsy1rnWjCJzJVAgMBAAGjggIDMIIB
# /zAfBgNVHSMEGDAWgBRoN+Drtjv4XxGG+/5hewiIZfROQjAdBgNVHQ4EFgQUHzn7
# SCjwpCIAZVQj8S3DVGL/mtcwPgYDVR0gBDcwNTAzBgZngQwBBAEwKTAnBggrBgEF
# BQcCARYbaHR0cDovL3d3dy5kaWdpY2VydC5jb20vQ1BTMA4GA1UdDwEB/wQEAwIH
# gDATBgNVHSUEDDAKBggrBgEFBQcDAzCBtQYDVR0fBIGtMIGqMFOgUaBPhk1odHRw
# Oi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmlu
# Z1JTQTQwOTZTSEEzODQyMDIxQ0ExLmNybDBToFGgT4ZNaHR0cDovL2NybDQuZGln
# aWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hB
# Mzg0MjAyMUNBMS5jcmwwgZQGCCsGAQUFBwEBBIGHMIGEMCQGCCsGAQUFBzABhhho
# dHRwOi8vb2NzcC5kaWdpY2VydC5jb20wXAYIKwYBBQUHMAKGUGh0dHA6Ly9jYWNl
# cnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNB
# NDA5NlNIQTM4NDIwMjFDQTEuY3J0MAkGA1UdEwQCMAAwDQYJKoZIhvcNAQELBQAD
# ggIBAJQ6toTdsoB0xPBqLd9tjHbN1vFAnjiqwHMsONbgVz5nqkqxdfFdcJbC+u9i
# b0sKaLl3lTzgUsvvleVu4tKK1hl0FWfwlAInypuC1a1UnKzGjRLMoNyz2AOVGSl7
# Y5PrVClnEuG8O5zxqNYkiN2IZHlVj2xZP10kLNL2sSRGaoiZqoEIW8z0G68gjrou
# Jgdgw14lt7QsGpUAcPMI9/l/hbyZIOPWPJus+Ock4hHPWiApVLlARki/2fE1IWXE
# b6KNgNYpcup3JvX/XzCHEM+cXZ2qcBwOdCukiroqxR0ku/yn59HMT3MG6o3GJGth
# sBLS9K5Vzg+YMSkV6iMnTi8sQknZA564Gk3gdv0SzF2MGT5Pc7p/IH4o4wPjn9Md
# fi3IDe1SRZeDa2I2qfjmLJ1VJWyug1NmbnXJTz7NeLODXNTDcLgFWNeokB71fhnn
# 6PQhCF2l7xITwrAbsY2lHiykV9b0QFhWKemNUKY3PW3no43fUci+ttxBrMpIHejC
# +1/rZcImMKgZVsMqRJJTAh/TW0aYZSRgz4sngv9HY/LYcmEQpgYpzGAIBKArgzBR
# A6riFJ+azKkOCK1trgO7k0giQ3xN2asmcDRzBjtrVY6vutNSPPXHL98WwHh46KLg
# m+tyhiPaG++Z/v1Pq2CWcKIvuzS3RyjOSQl77j5cjrbTxOmeMYIZ5DCCGeACAQEw
# fTBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNV
# BAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgQ29kZSBTaWduaW5nIFJTQTQwOTYgU0hB
# Mzg0IDIwMjEgQ0ExAhAP3GnppLmrUp/TG1q4uFF+MA0GCWCGSAFlAwQCAQUAoHww
# EAYKKwYBBAGCNwIBDDECMAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIOEalGYJ
# dTibXKZgimUL3MMSrWaIHiAyddZmQfCEbbXaMA0GCSqGSIb3DQEBAQUABIIBgJqU
# tA2/jTCz7zF9qc76XPUfzmZ/Ibg3qtH2+Lmcp+lxnnPOwbUbPuYLUbpH1fzeQngi
# +wjxphSNube3K3QN/afuIBfsRo5enDRsUF4yc+tBcS/+bOqsp2o0CvGxqRaGFqTK
# 5iq22MIl1tKpGRh5LfHEErOF+hNJ8HV59i/7tHxs2UV7hGz75wDhDKiTfQSRkuMT
# 9EP7BY4qsn+VjY+OBy7wSHVILy89VYmJKFC8uRM0QhWI04ne9FcrqAjQxZ7X6L20
# uYqt7wiGrX7AQklltW0ZZIvp09x1foNAU/jLWpdqe2rALCyxRqnOma4INI/BlcoF
# e078REizBfbk8ETu+27kaCoHkqNDygmaOGovQLo5EX5PiK+QjNRr64eryjnneG0O
# 2wTk0jjbY1Vzfltj8poOjtIUDRL/6VruVx1+0bSwzufrwQpLpo8WB4aQRb+/6NxU
# wT7VBy+5IBq3Y0VHgdNhvwFbDuODTzTkdTs18oA8g2wIhGhe9m/duSpXKq2a76GC
# Fzowghc2BgorBgEEAYI3AwMBMYIXJjCCFyIGCSqGSIb3DQEHAqCCFxMwghcPAgED
# MQ8wDQYJYIZIAWUDBAIBBQAweAYLKoZIhvcNAQkQAQSgaQRnMGUCAQEGCWCGSAGG
# /WwHATAxMA0GCWCGSAFlAwQCAQUABCBhz8Z0i4S245HSeFHrqBzIBTJtCMDlmu6E
# ckbsEelU2wIRAOtGf31o9SLqlUb5gJGK0Y4YDzIwMjQxMDE2MDYxNjA0WqCCEwMw
# gga8MIIEpKADAgECAhALrma8Wrp/lYfG+ekE4zMEMA0GCSqGSIb3DQEBCwUAMGMx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMy
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcg
# Q0EwHhcNMjQwOTI2MDAwMDAwWhcNMzUxMTI1MjM1OTU5WjBCMQswCQYDVQQGEwJV
# UzERMA8GA1UEChMIRGlnaUNlcnQxIDAeBgNVBAMTF0RpZ2lDZXJ0IFRpbWVzdGFt
# cCAyMDI0MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAvmpzn/aVIauW
# MLpbbeZZo7Xo/ZEfGMSIO2qZ46XB/QowIEMSvgjEdEZ3v4vrrTHleW1JWGErrjOL
# 0J4L0HqVR1czSzvUQ5xF7z4IQmn7dHY7yijvoQ7ujm0u6yXF2v1CrzZopykD07/9
# fpAT4BxpT9vJoJqAsP8YuhRvflJ9YeHjes4fduksTHulntq9WelRWY++TFPxzZrb
# ILRYynyEy7rS1lHQKFpXvo2GePfsMRhNf1F41nyEg5h7iOXv+vjX0K8RhUisfqw3
# TTLHj1uhS66YX2LZPxS4oaf33rp9HlfqSBePejlYeEdU740GKQM7SaVSH3TbBL8R
# 6HwX9QVpGnXPlKdE4fBIn5BBFnV+KwPxRNUNK6lYk2y1WSKour4hJN0SMkoaNV8h
# yyADiX1xuTxKaXN12HgR+8WulU2d6zhzXomJ2PleI9V2yfmfXSPGYanGgxzqI+Sh
# oOGLomMd3mJt92nm7Mheng/TBeSA2z4I78JpwGpTRHiT7yHqBiV2ngUIyCtd0pZ8
# zg3S7bk4QC4RrcnKJ3FbjyPAGogmoiZ33c1HG93Vp6lJ415ERcC7bFQMRbxqrMVA
# Niav1k425zYyFMyLNyE1QulQSgDpW9rtvVcIH7WvG9sqYup9j8z9J1XqbBZPJ5XL
# ln8mS8wWmdDLnBHXgYly/p1DhoQo5fkCAwEAAaOCAYswggGHMA4GA1UdDwEB/wQE
# AwIHgDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMCAGA1Ud
# IAQZMBcwCAYGZ4EMAQQCMAsGCWCGSAGG/WwHATAfBgNVHSMEGDAWgBS6FtltTYUv
# cyl2mi91jGogj57IbzAdBgNVHQ4EFgQUn1csA3cOKBWQZqVjXu5Pkh92oFswWgYD
# VR0fBFMwUTBPoE2gS4ZJaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# VHJ1c3RlZEc0UlNBNDA5NlNIQTI1NlRpbWVTdGFtcGluZ0NBLmNybDCBkAYIKwYB
# BQUHAQEEgYMwgYAwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNv
# bTBYBggrBgEFBQcwAoZMaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lD
# ZXJ0VHJ1c3RlZEc0UlNBNDA5NlNIQTI1NlRpbWVTdGFtcGluZ0NBLmNydDANBgkq
# hkiG9w0BAQsFAAOCAgEAPa0eH3aZW+M4hBJH2UOR9hHbm04IHdEoT8/T3HuBSyZe
# q3jSi5GXeWP7xCKhVireKCnCs+8GZl2uVYFvQe+pPTScVJeCZSsMo1JCoZN2mMew
# /L4tpqVNbSpWO9QGFwfMEy60HofN6V51sMLMXNTLfhVqs+e8haupWiArSozyAmGH
# /6oMQAh078qRh6wvJNU6gnh5OruCP1QUAvVSu4kqVOcJVozZR5RRb/zPd++PGE3q
# F1P3xWvYViUJLsxtvge/mzA75oBfFZSbdakHJe2BVDGIGVNVjOp8sNt70+kEoMF+
# T6tptMUNlehSR7vM+C13v9+9ZOUKzfRUAYSyyEmYtsnpltD/GWX8eM70ls1V6QG/
# ZOB6b6Yum1HvIiulqJ1Elesj5TMHq8CWT/xrW7twipXTJ5/i5pkU5E16RSBAdOp1
# 2aw8IQhhA/vEbFkEiF2abhuFixUDobZaA0VhqAsMHOmaT3XThZDNi5U2zHKhUs5u
# HHdG6BoQau75KiNbh0c+hatSF+02kULkftARjsyEpHKsF7u5zKRbt5oK5YGwFvgc
# 4pEVUNytmB3BpIiowOIIuDgP5M9WArHYSAR16gc0dP2XdkMEP5eBsX7bf/MGN4K3
# HP50v/01ZHo/Z5lGLvNwQ7XHBx1yomzLP8lx4Q1zZKDyHcp4VQJLu2kWTsKsOqQw
# ggauMIIElqADAgECAhAHNje3JFR82Ees/ShmKl5bMA0GCSqGSIb3DQEBCwUAMGIx
# CzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3
# dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBH
# NDAeFw0yMjAzMjMwMDAwMDBaFw0zNzAzMjIyMzU5NTlaMGMxCzAJBgNVBAYTAlVT
# MRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMyRGlnaUNlcnQgVHJ1
# c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcgQ0EwggIiMA0GCSqG
# SIb3DQEBAQUAA4ICDwAwggIKAoICAQDGhjUGSbPBPXJJUVXHJQPE8pE3qZdRodbS
# g9GeTKJtoLDMg/la9hGhRBVCX6SI82j6ffOciQt/nR+eDzMfUBMLJnOWbfhXqAJ9
# /UO0hNoR8XOxs+4rgISKIhjf69o9xBd/qxkrPkLcZ47qUT3w1lbU5ygt69OxtXXn
# HwZljZQp09nsad/ZkIdGAHvbREGJ3HxqV3rwN3mfXazL6IRktFLydkf3YYMZ3V+0
# VAshaG43IbtArF+y3kp9zvU5EmfvDqVjbOSmxR3NNg1c1eYbqMFkdECnwHLFuk4f
# sbVYTXn+149zk6wsOeKlSNbwsDETqVcplicu9Yemj052FVUmcJgmf6AaRyBD40Nj
# gHt1biclkJg6OBGz9vae5jtb7IHeIhTZgirHkr+g3uM+onP65x9abJTyUpURK1h0
# QCirc0PO30qhHGs4xSnzyqqWc0Jon7ZGs506o9UD4L/wojzKQtwYSH8UNM/STKvv
# mz3+DrhkKvp1KCRB7UK/BZxmSVJQ9FHzNklNiyDSLFc1eSuo80VgvCONWPfcYd6T
# /jnA+bIwpUzX6ZhKWD7TA4j+s4/TXkt2ElGTyYwMO1uKIqjBJgj5FBASA31fI7tk
# 42PgpuE+9sJ0sj8eCXbsq11GdeJgo1gJASgADoRU7s7pXcheMBK9Rp6103a50g5r
# mQzSM7TNsQIDAQABo4IBXTCCAVkwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4E
# FgQUuhbZbU2FL3MpdpovdYxqII+eyG8wHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5n
# P+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMIMHcG
# CCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQu
# Y29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGln
# aUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8v
# Y3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAgBgNV
# HSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEwDQYJKoZIhvcNAQELBQADggIB
# AH1ZjsCTtm+YqUQiAX5m1tghQuGwGC4QTRPPMFPOvxj7x1Bd4ksp+3CKDaopafxp
# wc8dB+k+YMjYC+VcW9dth/qEICU0MWfNthKWb8RQTGIdDAiCqBa9qVbPFXONASIl
# zpVpP0d3+3J0FNf/q0+KLHqrhc1DX+1gtqpPkWaeLJ7giqzl/Yy8ZCaHbJK9nXzQ
# cAp876i8dU+6WvepELJd6f8oVInw1YpxdmXazPByoyP6wCeCRK6ZJxurJB4mwbfe
# Kuv2nrF5mYGjVoarCkXJ38SNoOeY+/umnXKvxMfBwWpx2cYTgAnEtp/Nh4cku0+j
# Sbl3ZpHxcpzpSwJSpzd+k1OsOx0ISQ+UzTl63f8lY5knLD0/a6fxZsNBzU+2QJsh
# IUDQtxMkzdwdeDrknq3lNHGS1yZr5Dhzq6YBT70/O3itTK37xJV77QpfMzmHQXh6
# OOmc4d0j/R0o08f56PGYX/sr2H7yRp11LB4nLCbbbxV7HhmLNriT1ObyF5lZynDw
# N7+YAN8gFk8n+2BnFqFmut1VwDophrCYoCvtlUG3OtUVmDG0YgkPCr2B2RP+v6TR
# 81fZvAT6gt4y3wSJ8ADNXcL50CN/AAvkdgIm2fBldkKmKYcJRyvmfxqkhQ/8mJb2
# VVQrH4D6wPIOK+XW+6kvRBVK5xMOHds3OBqhK/bt1nz8MIIFjTCCBHWgAwIBAgIQ
# DpsYjvnQLefv21DiCEAYWjANBgkqhkiG9w0BAQwFADBlMQswCQYDVQQGEwJVUzEV
# MBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29t
# MSQwIgYDVQQDExtEaWdpQ2VydCBBc3N1cmVkIElEIFJvb3QgQ0EwHhcNMjIwODAx
# MDAwMDAwWhcNMzExMTA5MjM1OTU5WjBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMM
# RGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQD
# ExhEaWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwggIiMA0GCSqGSIb3DQEBAQUAA4IC
# DwAwggIKAoICAQC/5pBzaN675F1KPDAiMGkz7MKnJS7JIT3yithZwuEppz1Yq3aa
# za57G4QNxDAf8xukOBbrVsaXbR2rsnnyyhHS5F/WBTxSD1Ifxp4VpX6+n6lXFllV
# cq9ok3DCsrp1mWpzMpTREEQQLt+C8weE5nQ7bXHiLQwb7iDVySAdYyktzuxeTsiT
# +CFhmzTrBcZe7FsavOvJz82sNEBfsXpm7nfISKhmV1efVFiODCu3T6cw2Vbuyntd
# 463JT17lNecxy9qTXtyOj4DatpGYQJB5w3jHtrHEtWoYOAMQjdjUN6QuBX2I9YI+
# EJFwq1WCQTLX2wRzKm6RAXwhTNS8rhsDdV14Ztk6MUSaM0C/CNdaSaTC5qmgZ92k
# J7yhTzm1EVgX9yRcRo9k98FpiHaYdj1ZXUJ2h4mXaXpI8OCiEhtmmnTK3kse5w5j
# rubU75KSOp493ADkRSWJtppEGSt+wJS00mFt6zPZxd9LBADMfRyVw4/3IbKyEbe7
# f/LVjHAsQWCqsWMYRJUadmJ+9oCw++hkpjPRiQfhvbfmQ6QYuKZ3AeEPlAwhHbJU
# KSWJbOUOUlFHdL4mrLZBdd56rF+NP8m800ERElvlEFDrMcXKchYiCd98THU/Y+wh
# X8QgUWtvsauGi0/C1kVfnSD8oR7FwI+isX4KJpn15GkvmB0t9dmpsh3lGwIDAQAB
# o4IBOjCCATYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQU7NfjgtJxXWRM3y5n
# P+e6mK4cD08wHwYDVR0jBBgwFoAUReuir/SSy4IxLVGLp6chnfNtyA8wDgYDVR0P
# AQH/BAQDAgGGMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29j
# c3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3J0MEUGA1UdHwQ+MDww
# OqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RFJvb3RDQS5jcmwwEQYDVR0gBAowCDAGBgRVHSAAMA0GCSqGSIb3DQEBDAUAA4IB
# AQBwoL9DXFXnOF+go3QbPbYW1/e/Vwe9mqyhhyzshV6pGrsi+IcaaVQi7aSId229
# GhT0E0p6Ly23OO/0/4C5+KH38nLeJLxSA8hO0Cre+i1Wz/n096wwepqLsl7Uz9FD
# RJtDIeuWcqFItJnLnU+nBgMTdydE1Od/6Fmo8L8vC6bp8jQ87PcDx4eo0kxAGTVG
# amlUsLihVo7spNU96LHc/RzY9HdaXFSMb++hUD38dglohJ9vytsgjTVgHAIDyyCw
# rFigDkBjxZgiwbJZ9VVrzyerbHbObyMt9H5xaiNrIv8SuFQtJ37YOtnwtoeW/VvR
# XKwYw02fc7cBqZ9Xql4o4rmUMYIDdjCCA3ICAQEwdzBjMQswCQYDVQQGEwJVUzEX
# MBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNVBAMTMkRpZ2lDZXJ0IFRydXN0
# ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1waW5nIENBAhALrma8Wrp/lYfG
# +ekE4zMEMA0GCWCGSAFlAwQCAQUAoIHRMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0B
# CRABBDAcBgkqhkiG9w0BCQUxDxcNMjQxMDE2MDYxNjA0WjArBgsqhkiG9w0BCRAC
# DDEcMBowGDAWBBTb04XuYtvSPnvk9nFIUIck1YZbRTAvBgkqhkiG9w0BCQQxIgQg
# 38kRzesQi2cVvvwhh5Yl0VAn65bP885Rk+Bkk7cupaEwNwYLKoZIhvcNAQkQAi8x
# KDAmMCQwIgQgdnafqPJjLx9DCzojMK7WVnX+13PbBdZluQWTmEOPmtswDQYJKoZI
# hvcNAQEBBQAEggIAnuK/xhmiTbm3aZwN77zUFqyizw9l4E9nrB+8xB8zRzQ2oLVV
# j32Kabvr40D5UGHYQCFqWEgmsZ75leWI7PKGGt9dazy3m1zy552tFQKfW6qu9oDG
# d/gsYRT70g2UqbBnZp4VoWAl8o3wootLKbGpgDnrRtlIGUt0+T99jLia3UGRsGEw
# DVDVfHQ/GWsBTGSTrh5rm2/wnSTEtJhoJ6BOB1YwXLjraYZVo/6xpQmFM15qr5Wa
# RsLsWJFJnw21jpknQksJPWcYKJVay9XmT/qUHIbMd35vU9/TUP7hRIMfM199tsVi
# 0Is0dJYUJDpACABOdlFo9uTy2EMTCGyuOCn5ghFTUpYULBd2dz5EUpVzwpQP3ExX
# vLoU1jOtWBf4HHwpDwDArVbQMX+Ys9mit1pBc0IwJGFCdj4YVwlsnm/wKtF1ykZA
# 2BsMAZ/l/7ubiJlnSShHbtjO9lmAyK6JXn0LobxvHWi+hsqxuEPoYpAPtNZbI5Dn
# hLwOjIdTzjS/jwbyd9YuQk3GiOhp52O80QSNHZuABY9sEzXXB/00gFDF297LjZbu
# 85565tCt8zkiUKuAnF5Kb7IuZM1+6uZM17EaUREcCR3cfaJ2dSW+TfDaP27zubPs
# meEHA7ivksdYtwvY3FcQYF3sXONWa2OczaPlWoZkNky1mt+xeonzCZGseoY=
# SIG # End signature block
