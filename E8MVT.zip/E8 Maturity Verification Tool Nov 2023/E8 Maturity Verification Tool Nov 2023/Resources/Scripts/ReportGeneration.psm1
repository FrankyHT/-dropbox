<#
.SYNOPSIS
Generates an E8MVT report, using the debug output from E8MVT.

.DESCRIPTION
Using the powershell HTML generation capabilities, this converts debug data into a focused report around the Essential Eight.

.PARAMETER Path
The path of an input debug CSV to generate the report from.

.PARAMETER OutputFile
The path to write the output report to.

.PARAMETER DetailedReport
A flag indicating whether full debug information should be included in the report. Off by default.

#>
function New-E8MVTReport {
    #handle arguments
    param (
        [Parameter(Mandatory)][string]$Path,
        [string]$OutputFile = ".\Reports\E8MVT Report.html",
        [switch]$DetailedReport = $false
    )

    $maturitypattern = "^Maturity "
    $maturityassessmentpattern = "\[Maturity Assessment, Maximum Assessable Maturity is (\d)\]"
    $inputData = Import-Csv $Path -Header 'Host', 'Timestamp', 'Module', 'Element', 'Test', 'Status', 'Message' | Select-Object -skip 1

    #Table CSS
    $Header = @"
<style>
TABLE {border-width: 1px; border-style: solid; border-color: black; border-collapse: collapse;}
TH {border-width: 1px; padding: 3px; border-style: solid; border-color: black; background-color: #6495ED;}
TD {border-width: 1px; padding: 3px; border-style: solid; border-color: black;}
</style>
"@

    #get system age
    try {
        $os = get-ciminstance win32_operatingsystem -ErrorAction SilentlyContinue
        $systemage = ", system age: {0} days" -f (New-Timespan -Start $os.InstallDate -end $(get-date) -ErrorAction SilentlyContinue).Days
        $reportdate = ", report date: {0}" -f $((get-date).ToString("yyyy-MM-dd HH:mm"))
    }
    catch {
        $systemage = ""
    }

    #Top banner CSS
    $precontent = @"
<div style='margin:  0px auto; BACKGROUND-COLOR:Black;Color:White;font-weight:bold;FONT-SIZE:  14pt;TEXT-ALIGN: center;'>

Essential 8 Maturity Verification Tool Report (Model: November 2023)<br>
Produced for system: $($inputData[0].Host)${systemage}${reportdate} (v${global:e8mvtversion})
<br>
<br>
E8MVT can be used to assist with the assessment of your Essential Eight posture, but it is not an audit tool. Please note that E8MVT does not comprehensively assess all Essential Eight controls, see the user guide for further information.
</div><br>
"@

    #grab individual modules
    $modules = $inputData | Group-Object -Property Module

    $outputTable = @()
    #go through the modules
    foreach ($module in $modules) {
        #Skip reporting in HTML on System Hardening module
        if ($module.Name -eq "System Hardening") { continue }

        #create the row
        $row = "" | Select-Object "Mitigation Strategy", "Maturity Level (Maximum Assessable)", Description

        #set the row to the module name
        $row."Mitigation Strategy" = $module.Name

        #flag whether the module succeeded or failed, as this determines output
        $success = ($module.Group).Where( { $_.Test -match $maturityassessmentpattern -and $_.Status -eq "SUCCESS" })
        $failure = ($module.Group).Where( { $_.Test -match $maturityassessmentpattern -and $_.Status -like "FAIL*" })
        $tempmat = ($module.Group).Where( { $_.Test -match $maturityassessmentpattern }); $maxassessedmaturity = $Matches[1] #should grab the maximum maturity
        if ($failure -and $success){
            $lowestfailure = [int](($failure[0].Element).Split(' ')[1]) - 1
            $highestsuccess = [int]($success[-1].Element).Split(' ')[1]
            if ($highestsuccess -gt $lowestfailure){
                $highestsuccess = $lowestfailure
            }
            $assessedmaturity = $highestsuccess
        }
        elseif ($success) {
            $assessedmaturity = ($success[-1].Element).Split(' ')[1]
        }
        else {
            $assessedmaturity = 0
        }
        $row."Maturity Level (Maximum Assessable)" = ";ml;$assessedmaturity/$maxassessedmaturity;ml;"
        #Construct description
        #break down based on elements (Maturity 1, Non-Maturity etc)
        $elements = $module.Group | Where-object { $_.Element -match $maturitypattern } | Group-Object -Property Element
        foreach ($element in $elements) {
            #break down based on tests   
            $tests = $element.Group | Group-Object -Property Test
            foreach ($test in $tests) {
                #determine status criteria here...
                if ($test.Name -match $maturityassessmentpattern) {
                    #success
                    if ($test.Group.Status -eq "SUCCESS") { $statuscriteria = "^SUCCESS|^REQUIREDINFO" }
                    #failure
                    else { $statuscriteria = "^FAILED|^REMEDIATION|^REQUIREDINFO" }
                }

                #break down based on statuses, to make sure there are actually items to print, before doing so
                $statuses = $test.Group | Group-Object -Property Status
                if (-not $DetailedReport){
                    $statuses = $test.Group | Where-object { $_.Status -match $statuscriteria } | Group-Object -Property Status
                }
                if ($statuses) {
                    #handle the maturity assessment seperately to save having multiple lines for the same info (success or fail)
                    if ($test.Name -match $maturityassessmentpattern) {
                        $formattedstatus = ""
                        if($statuses[0].Name -match "FAILED") { $formattedstatus += ";strong1;" }
                        $formattedstatus += $statuses[0].Name
                        if($statuses[0].Name -match "FAILED") { $formattedstatus += ";strong2;" }

                        #print the element name, and its bullet
                        $row.Description += ';ul1;'
                        $row.Description += ("::{0} [{1}]" -f $element.Name, $formattedstatus)
                        
                        #if this is maturity zero, bypass so it prints at least the failed elements
                        if (-not $DetailedReport -and $assessedmaturity -eq 0) { continue }
                        #if this is one of the fully successful maturity levels, don't print out the full details unless verbose is selected
                        elseif (-not $DetailedReport -and $element.Name.Split(' ')[1] -lt $assessedmaturity) { break }
                        #go to the next one, you're done
                        else { continue };
                    }
                    else {
                        #print the test name
                        $row.Description += ';ul1;'
                        $row.Description += "::" + $test.name
                        #cycle through and print the status type
                        foreach ($status in $statuses) {
                            $row.Description += ';ul1;'
                            if($status.Name -match "FAILED") { $row.Description += ";strong1;" }
                            $row.Description += "::" + $status.Name
                            $row.Description += ';ul1;'
                            #break down for messages under this status
                            $messages = $status.Group | Group-Object -Property Message
                            foreach ($message in $messages) {
                                $row.Description += "::" + $Message.Name
                            }
                            if($status.Name -match "FAILED") { $row.Description += ";strong2;" }
                            $row.Description += ';ul2;'
                            $row.Description += ';ul2;'
                        }
                        $row.Description += ';ul2;'
                    }
                }
            }
            $row.Description += ';ul2;'
        }

        #Add the row to the table
        $outputTable += $row
    }

    $output = $outputTable | ConvertTo-Html -Head $Header -PreContent $precontent `
    | ForEach-Object { $PSItem `
            -replace "<td>;ml;0/(\d);ml;</td>", '<td style=''background-color:#ff6868;TEXT-ALIGN:center;font-weight:bold;FONT-SIZE:20pt''>0 ($1)</td>' `
            -replace "<td>;ml;1/(\d);ml;</td>", '<td style=''background-color:#f58046;TEXT-ALIGN:center;font-weight:bold;FONT-SIZE:20pt''>1 ($1)</td>' `
            -replace "<td>;ml;2/(\d);ml;</td>", '<td style=''background-color:#80c58c;TEXT-ALIGN:center;font-weight:bold;FONT-SIZE:20pt''>2 ($1)</td>' `
            -replace "<td>;ml;3/(\d);ml;</td>", '<td style=''background-color:#001e45;TEXT-ALIGN:center;font-weight:bold;FONT-SIZE:20pt;Color:White''>3 ($1)</td>' }
    #this is the only way I could find to get HTML tags inside each table cell (For bullet points)
    $output -replace '::', '<li>' -replace ';ul1;', '<ul>' -replace ';ul2;', '</ul>' -replace ';strong1;', '<strong>' -replace ';strong2;', '</strong>' | Out-File -FilePath $OutputFile
    Write-Verbose -Verbose -Message "Created Report here: $OutputFile"

}


#Package date: 2024-10-16; Build Version: d215424
#Requires -Version 3.0


# SIG # Begin signature block
# MIIoeAYJKoZIhvcNAQcCoIIoaTCCKGUCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCA8+c/0iITEU2Yp
# P+XCw/HkAHxwPJQUOenOqryuuGNdZqCCDeowggawMIIEmKADAgECAhAIrUCyYNKc
# TJ9ezam9k67ZMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0z
# NjA0MjgyMzU5NTlaMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQDVtC9C0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0
# JAfhS0/TeEP0F9ce2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJr
# Q5qZ8sU7H/Lvy0daE6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhF
# LqGfLOEYwhrMxe6TSXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+F
# LEikVoQ11vkunKoAFdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh
# 3K3kGKDYwSNHR7OhD26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJ
# wZPt4bRc4G/rJvmM1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQay
# g9Rc9hUZTO1i4F4z8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbI
# YViY9XwCFjyDKK05huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchAp
# QfDVxW0mdmgRQRNYmtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRro
# OBl8ZhzNeDhFMJlP/2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IB
# WTCCAVUwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+
# YXsIiGX0TkIwHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0P
# AQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAC
# hjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9v
# dEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAED
# MAgGBmeBDAEEATANBgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql
# +Eg08yy25nRm95RysQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFF
# UP2cvbaF4HZ+N3HLIvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1h
# mYFW9snjdufE5BtfQ/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3Ryw
# YFzzDaju4ImhvTnhOE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5Ubdld
# AhQfQDN8A+KVssIhdXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw
# 8MzK7/0pNVwfiThV9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnP
# LqR0kq3bPKSchh/jwVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatE
# QOON8BUozu3xGFYHKi8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bn
# KD+sEq6lLyJsQfmCXBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQji
# WQ1tygVQK+pKHJ6l/aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbq
# yK+p/pQd52MbOoZWeE4wggcyMIIFGqADAgECAhAP3GnppLmrUp/TG1q4uFF+MA0G
# CSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwHhcNMjQwOTE2MDAwMDAwWhcNMjcxMDEx
# MjM1OTU5WjCBuTELMAkGA1UEBhMCQVUxGjAYBgNVBAgTEVdlc3Rlcm4gQXVzdHJh
# bGlhMREwDwYDVQQHEwhLb2phcmVuYTEnMCUGA1UEChMeQXVzdHJhbGlhbiBTaWdu
# YWxzIERpcmVjdG9yYXRlMSkwJwYDVQQLEyBBdXN0cmFsaWFuIEN5YmVyIFNlY3Vy
# aXR5IENlbnRyZTEnMCUGA1UEAxMeQXVzdHJhbGlhbiBTaWduYWxzIERpcmVjdG9y
# YXRlMIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAw0cTiNUzc3vbheXu
# Z741I3JRxbhU5iLiP1IBSZP3amEIPPdR5JEbgh1OrMUSXOzBBo8JKTYwCLztOiyv
# jUEdeRGFXvWPq04aNoiSeU8/mCWjcQ+Jb0TYsrpLFsCgdRLjCIJrzbss4lTgK1Tm
# UIHMJarlrJwLurhp58BAIwEhQpr2eUUzjw2jGGwm85suDNRq9pJb5cHDYSDLGumL
# 6br5QuHClb3pIcZBY7Qh/Hw5WYALHqWO5EuSAfWVAtieBy5qLUi2Xi3/9WTh1sAg
# 8XEeUXwE0DjbL4UlgNtL4OUYNcABGvolOsT/tFPGwch/LrQZCKN8P/pDfOAon+qy
# AW9sqU+mSVPT7oPzEirFgnVyXaP2oVAAM8WQLm9VNHcetkunAyREvT/wzgx8/Lbj
# NJV+ZvDr2bNTuEfQn7OVe2ndR6tXJqeuRfDjyj0z9GGpcsfVButoYM3lRJz7X58D
# 2oRUT/aQn4MTWGWjEmbrbDQtV2IJxVXzwRRVsy1rnWjCJzJVAgMBAAGjggIDMIIB
# /zAfBgNVHSMEGDAWgBRoN+Drtjv4XxGG+/5hewiIZfROQjAdBgNVHQ4EFgQUHzn7
# SCjwpCIAZVQj8S3DVGL/mtcwPgYDVR0gBDcwNTAzBgZngQwBBAEwKTAnBggrBgEF
# BQcCARYbaHR0cDovL3d3dy5kaWdpY2VydC5jb20vQ1BTMA4GA1UdDwEB/wQEAwIH
# gDATBgNVHSUEDDAKBggrBgEFBQcDAzCBtQYDVR0fBIGtMIGqMFOgUaBPhk1odHRw
# Oi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmlu
# Z1JTQTQwOTZTSEEzODQyMDIxQ0ExLmNybDBToFGgT4ZNaHR0cDovL2NybDQuZGln
# aWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hB
# Mzg0MjAyMUNBMS5jcmwwgZQGCCsGAQUFBwEBBIGHMIGEMCQGCCsGAQUFBzABhhho
# dHRwOi8vb2NzcC5kaWdpY2VydC5jb20wXAYIKwYBBQUHMAKGUGh0dHA6Ly9jYWNl
# cnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNB
# NDA5NlNIQTM4NDIwMjFDQTEuY3J0MAkGA1UdEwQCMAAwDQYJKoZIhvcNAQELBQAD
# ggIBAJQ6toTdsoB0xPBqLd9tjHbN1vFAnjiqwHMsONbgVz5nqkqxdfFdcJbC+u9i
# b0sKaLl3lTzgUsvvleVu4tKK1hl0FWfwlAInypuC1a1UnKzGjRLMoNyz2AOVGSl7
# Y5PrVClnEuG8O5zxqNYkiN2IZHlVj2xZP10kLNL2sSRGaoiZqoEIW8z0G68gjrou
# Jgdgw14lt7QsGpUAcPMI9/l/hbyZIOPWPJus+Ock4hHPWiApVLlARki/2fE1IWXE
# b6KNgNYpcup3JvX/XzCHEM+cXZ2qcBwOdCukiroqxR0ku/yn59HMT3MG6o3GJGth
# sBLS9K5Vzg+YMSkV6iMnTi8sQknZA564Gk3gdv0SzF2MGT5Pc7p/IH4o4wPjn9Md
# fi3IDe1SRZeDa2I2qfjmLJ1VJWyug1NmbnXJTz7NeLODXNTDcLgFWNeokB71fhnn
# 6PQhCF2l7xITwrAbsY2lHiykV9b0QFhWKemNUKY3PW3no43fUci+ttxBrMpIHejC
# +1/rZcImMKgZVsMqRJJTAh/TW0aYZSRgz4sngv9HY/LYcmEQpgYpzGAIBKArgzBR
# A6riFJ+azKkOCK1trgO7k0giQ3xN2asmcDRzBjtrVY6vutNSPPXHL98WwHh46KLg
# m+tyhiPaG++Z/v1Pq2CWcKIvuzS3RyjOSQl77j5cjrbTxOmeMYIZ5DCCGeACAQEw
# fTBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNV
# BAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgQ29kZSBTaWduaW5nIFJTQTQwOTYgU0hB
# Mzg0IDIwMjEgQ0ExAhAP3GnppLmrUp/TG1q4uFF+MA0GCWCGSAFlAwQCAQUAoHww
# EAYKKwYBBAGCNwIBDDECMAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIP0l+roS
# 9Yc/5Om9CSBumvK+1wymojglpzEI5mK4VtvEMA0GCSqGSIb3DQEBAQUABIIBgAMg
# QiEV/YM1SgnppErZtgQIAIE9stHQFEENsK2WZ5OIeq9r1LKBIkUv2oNrZsD9h7hz
# MrwOAewgHCGSw7pjAWKFpq0kx32RE2TDOJstFjLnefIn1/x5b0B8/gfPJe14eqxJ
# t9mfsiSb0O1WXAT7SR69I1d13eCol3XHDGujPGv4I4tQLrsMoLJJTS+OqC0/z4Gw
# xl+FQKsNIQ6ql+LPtYEGoiEiA9xekYee0DgyzeDc1d0Ojr8C1FVEnvJwI9YlbhKy
# pCY5dkUxZbOgrE4k42lfR7kdEyeimCXVJbxXKOyIVCWvFL3RRIMH/HRMFt2dlg2U
# 6TUTCP/c2WcJBfKguj/eOfQqSyp7KpdM0IpTx7H5TiTZ6gvbikTXbCuQFR5a5HI6
# +rSn50isfp5lxKHQuJXsmGmzbhKsU9/CzsN3tzp2TwUNuoiaIP30xX6QX51Xf6oH
# Kz7jJeai5mE0rWCq85O+c+NmjGWKMX+2WQawvyVGo0xLRoUXX0lhLqBN1S5ywaGC
# Fzowghc2BgorBgEEAYI3AwMBMYIXJjCCFyIGCSqGSIb3DQEHAqCCFxMwghcPAgED
# MQ8wDQYJYIZIAWUDBAIBBQAweAYLKoZIhvcNAQkQAQSgaQRnMGUCAQEGCWCGSAGG
# /WwHATAxMA0GCWCGSAFlAwQCAQUABCA52qYmF6e+9GU9cOlGJ1PREVnfMUPSYBOu
# iC3WSMu4AwIRAKk1Svd9cLQXBNE+9yu8WK0YDzIwMjQxMDE2MDYxNTQwWqCCEwMw
# gga8MIIEpKADAgECAhALrma8Wrp/lYfG+ekE4zMEMA0GCSqGSIb3DQEBCwUAMGMx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMy
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcg
# Q0EwHhcNMjQwOTI2MDAwMDAwWhcNMzUxMTI1MjM1OTU5WjBCMQswCQYDVQQGEwJV
# UzERMA8GA1UEChMIRGlnaUNlcnQxIDAeBgNVBAMTF0RpZ2lDZXJ0IFRpbWVzdGFt
# cCAyMDI0MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAvmpzn/aVIauW
# MLpbbeZZo7Xo/ZEfGMSIO2qZ46XB/QowIEMSvgjEdEZ3v4vrrTHleW1JWGErrjOL
# 0J4L0HqVR1czSzvUQ5xF7z4IQmn7dHY7yijvoQ7ujm0u6yXF2v1CrzZopykD07/9
# fpAT4BxpT9vJoJqAsP8YuhRvflJ9YeHjes4fduksTHulntq9WelRWY++TFPxzZrb
# ILRYynyEy7rS1lHQKFpXvo2GePfsMRhNf1F41nyEg5h7iOXv+vjX0K8RhUisfqw3
# TTLHj1uhS66YX2LZPxS4oaf33rp9HlfqSBePejlYeEdU740GKQM7SaVSH3TbBL8R
# 6HwX9QVpGnXPlKdE4fBIn5BBFnV+KwPxRNUNK6lYk2y1WSKour4hJN0SMkoaNV8h
# yyADiX1xuTxKaXN12HgR+8WulU2d6zhzXomJ2PleI9V2yfmfXSPGYanGgxzqI+Sh
# oOGLomMd3mJt92nm7Mheng/TBeSA2z4I78JpwGpTRHiT7yHqBiV2ngUIyCtd0pZ8
# zg3S7bk4QC4RrcnKJ3FbjyPAGogmoiZ33c1HG93Vp6lJ415ERcC7bFQMRbxqrMVA
# Niav1k425zYyFMyLNyE1QulQSgDpW9rtvVcIH7WvG9sqYup9j8z9J1XqbBZPJ5XL
# ln8mS8wWmdDLnBHXgYly/p1DhoQo5fkCAwEAAaOCAYswggGHMA4GA1UdDwEB/wQE
# AwIHgDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMCAGA1Ud
# IAQZMBcwCAYGZ4EMAQQCMAsGCWCGSAGG/WwHATAfBgNVHSMEGDAWgBS6FtltTYUv
# cyl2mi91jGogj57IbzAdBgNVHQ4EFgQUn1csA3cOKBWQZqVjXu5Pkh92oFswWgYD
# VR0fBFMwUTBPoE2gS4ZJaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# VHJ1c3RlZEc0UlNBNDA5NlNIQTI1NlRpbWVTdGFtcGluZ0NBLmNybDCBkAYIKwYB
# BQUHAQEEgYMwgYAwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNv
# bTBYBggrBgEFBQcwAoZMaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lD
# ZXJ0VHJ1c3RlZEc0UlNBNDA5NlNIQTI1NlRpbWVTdGFtcGluZ0NBLmNydDANBgkq
# hkiG9w0BAQsFAAOCAgEAPa0eH3aZW+M4hBJH2UOR9hHbm04IHdEoT8/T3HuBSyZe
# q3jSi5GXeWP7xCKhVireKCnCs+8GZl2uVYFvQe+pPTScVJeCZSsMo1JCoZN2mMew
# /L4tpqVNbSpWO9QGFwfMEy60HofN6V51sMLMXNTLfhVqs+e8haupWiArSozyAmGH
# /6oMQAh078qRh6wvJNU6gnh5OruCP1QUAvVSu4kqVOcJVozZR5RRb/zPd++PGE3q
# F1P3xWvYViUJLsxtvge/mzA75oBfFZSbdakHJe2BVDGIGVNVjOp8sNt70+kEoMF+
# T6tptMUNlehSR7vM+C13v9+9ZOUKzfRUAYSyyEmYtsnpltD/GWX8eM70ls1V6QG/
# ZOB6b6Yum1HvIiulqJ1Elesj5TMHq8CWT/xrW7twipXTJ5/i5pkU5E16RSBAdOp1
# 2aw8IQhhA/vEbFkEiF2abhuFixUDobZaA0VhqAsMHOmaT3XThZDNi5U2zHKhUs5u
# HHdG6BoQau75KiNbh0c+hatSF+02kULkftARjsyEpHKsF7u5zKRbt5oK5YGwFvgc
# 4pEVUNytmB3BpIiowOIIuDgP5M9WArHYSAR16gc0dP2XdkMEP5eBsX7bf/MGN4K3
# HP50v/01ZHo/Z5lGLvNwQ7XHBx1yomzLP8lx4Q1zZKDyHcp4VQJLu2kWTsKsOqQw
# ggauMIIElqADAgECAhAHNje3JFR82Ees/ShmKl5bMA0GCSqGSIb3DQEBCwUAMGIx
# CzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3
# dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBH
# NDAeFw0yMjAzMjMwMDAwMDBaFw0zNzAzMjIyMzU5NTlaMGMxCzAJBgNVBAYTAlVT
# MRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMyRGlnaUNlcnQgVHJ1
# c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcgQ0EwggIiMA0GCSqG
# SIb3DQEBAQUAA4ICDwAwggIKAoICAQDGhjUGSbPBPXJJUVXHJQPE8pE3qZdRodbS
# g9GeTKJtoLDMg/la9hGhRBVCX6SI82j6ffOciQt/nR+eDzMfUBMLJnOWbfhXqAJ9
# /UO0hNoR8XOxs+4rgISKIhjf69o9xBd/qxkrPkLcZ47qUT3w1lbU5ygt69OxtXXn
# HwZljZQp09nsad/ZkIdGAHvbREGJ3HxqV3rwN3mfXazL6IRktFLydkf3YYMZ3V+0
# VAshaG43IbtArF+y3kp9zvU5EmfvDqVjbOSmxR3NNg1c1eYbqMFkdECnwHLFuk4f
# sbVYTXn+149zk6wsOeKlSNbwsDETqVcplicu9Yemj052FVUmcJgmf6AaRyBD40Nj
# gHt1biclkJg6OBGz9vae5jtb7IHeIhTZgirHkr+g3uM+onP65x9abJTyUpURK1h0
# QCirc0PO30qhHGs4xSnzyqqWc0Jon7ZGs506o9UD4L/wojzKQtwYSH8UNM/STKvv
# mz3+DrhkKvp1KCRB7UK/BZxmSVJQ9FHzNklNiyDSLFc1eSuo80VgvCONWPfcYd6T
# /jnA+bIwpUzX6ZhKWD7TA4j+s4/TXkt2ElGTyYwMO1uKIqjBJgj5FBASA31fI7tk
# 42PgpuE+9sJ0sj8eCXbsq11GdeJgo1gJASgADoRU7s7pXcheMBK9Rp6103a50g5r
# mQzSM7TNsQIDAQABo4IBXTCCAVkwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4E
# FgQUuhbZbU2FL3MpdpovdYxqII+eyG8wHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5n
# P+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMIMHcG
# CCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQu
# Y29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGln
# aUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8v
# Y3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAgBgNV
# HSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEwDQYJKoZIhvcNAQELBQADggIB
# AH1ZjsCTtm+YqUQiAX5m1tghQuGwGC4QTRPPMFPOvxj7x1Bd4ksp+3CKDaopafxp
# wc8dB+k+YMjYC+VcW9dth/qEICU0MWfNthKWb8RQTGIdDAiCqBa9qVbPFXONASIl
# zpVpP0d3+3J0FNf/q0+KLHqrhc1DX+1gtqpPkWaeLJ7giqzl/Yy8ZCaHbJK9nXzQ
# cAp876i8dU+6WvepELJd6f8oVInw1YpxdmXazPByoyP6wCeCRK6ZJxurJB4mwbfe
# Kuv2nrF5mYGjVoarCkXJ38SNoOeY+/umnXKvxMfBwWpx2cYTgAnEtp/Nh4cku0+j
# Sbl3ZpHxcpzpSwJSpzd+k1OsOx0ISQ+UzTl63f8lY5knLD0/a6fxZsNBzU+2QJsh
# IUDQtxMkzdwdeDrknq3lNHGS1yZr5Dhzq6YBT70/O3itTK37xJV77QpfMzmHQXh6
# OOmc4d0j/R0o08f56PGYX/sr2H7yRp11LB4nLCbbbxV7HhmLNriT1ObyF5lZynDw
# N7+YAN8gFk8n+2BnFqFmut1VwDophrCYoCvtlUG3OtUVmDG0YgkPCr2B2RP+v6TR
# 81fZvAT6gt4y3wSJ8ADNXcL50CN/AAvkdgIm2fBldkKmKYcJRyvmfxqkhQ/8mJb2
# VVQrH4D6wPIOK+XW+6kvRBVK5xMOHds3OBqhK/bt1nz8MIIFjTCCBHWgAwIBAgIQ
# DpsYjvnQLefv21DiCEAYWjANBgkqhkiG9w0BAQwFADBlMQswCQYDVQQGEwJVUzEV
# MBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29t
# MSQwIgYDVQQDExtEaWdpQ2VydCBBc3N1cmVkIElEIFJvb3QgQ0EwHhcNMjIwODAx
# MDAwMDAwWhcNMzExMTA5MjM1OTU5WjBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMM
# RGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQD
# ExhEaWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwggIiMA0GCSqGSIb3DQEBAQUAA4IC
# DwAwggIKAoICAQC/5pBzaN675F1KPDAiMGkz7MKnJS7JIT3yithZwuEppz1Yq3aa
# za57G4QNxDAf8xukOBbrVsaXbR2rsnnyyhHS5F/WBTxSD1Ifxp4VpX6+n6lXFllV
# cq9ok3DCsrp1mWpzMpTREEQQLt+C8weE5nQ7bXHiLQwb7iDVySAdYyktzuxeTsiT
# +CFhmzTrBcZe7FsavOvJz82sNEBfsXpm7nfISKhmV1efVFiODCu3T6cw2Vbuyntd
# 463JT17lNecxy9qTXtyOj4DatpGYQJB5w3jHtrHEtWoYOAMQjdjUN6QuBX2I9YI+
# EJFwq1WCQTLX2wRzKm6RAXwhTNS8rhsDdV14Ztk6MUSaM0C/CNdaSaTC5qmgZ92k
# J7yhTzm1EVgX9yRcRo9k98FpiHaYdj1ZXUJ2h4mXaXpI8OCiEhtmmnTK3kse5w5j
# rubU75KSOp493ADkRSWJtppEGSt+wJS00mFt6zPZxd9LBADMfRyVw4/3IbKyEbe7
# f/LVjHAsQWCqsWMYRJUadmJ+9oCw++hkpjPRiQfhvbfmQ6QYuKZ3AeEPlAwhHbJU
# KSWJbOUOUlFHdL4mrLZBdd56rF+NP8m800ERElvlEFDrMcXKchYiCd98THU/Y+wh
# X8QgUWtvsauGi0/C1kVfnSD8oR7FwI+isX4KJpn15GkvmB0t9dmpsh3lGwIDAQAB
# o4IBOjCCATYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQU7NfjgtJxXWRM3y5n
# P+e6mK4cD08wHwYDVR0jBBgwFoAUReuir/SSy4IxLVGLp6chnfNtyA8wDgYDVR0P
# AQH/BAQDAgGGMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29j
# c3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3J0MEUGA1UdHwQ+MDww
# OqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RFJvb3RDQS5jcmwwEQYDVR0gBAowCDAGBgRVHSAAMA0GCSqGSIb3DQEBDAUAA4IB
# AQBwoL9DXFXnOF+go3QbPbYW1/e/Vwe9mqyhhyzshV6pGrsi+IcaaVQi7aSId229
# GhT0E0p6Ly23OO/0/4C5+KH38nLeJLxSA8hO0Cre+i1Wz/n096wwepqLsl7Uz9FD
# RJtDIeuWcqFItJnLnU+nBgMTdydE1Od/6Fmo8L8vC6bp8jQ87PcDx4eo0kxAGTVG
# amlUsLihVo7spNU96LHc/RzY9HdaXFSMb++hUD38dglohJ9vytsgjTVgHAIDyyCw
# rFigDkBjxZgiwbJZ9VVrzyerbHbObyMt9H5xaiNrIv8SuFQtJ37YOtnwtoeW/VvR
# XKwYw02fc7cBqZ9Xql4o4rmUMYIDdjCCA3ICAQEwdzBjMQswCQYDVQQGEwJVUzEX
# MBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNVBAMTMkRpZ2lDZXJ0IFRydXN0
# ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1waW5nIENBAhALrma8Wrp/lYfG
# +ekE4zMEMA0GCWCGSAFlAwQCAQUAoIHRMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0B
# CRABBDAcBgkqhkiG9w0BCQUxDxcNMjQxMDE2MDYxNTQwWjArBgsqhkiG9w0BCRAC
# DDEcMBowGDAWBBTb04XuYtvSPnvk9nFIUIck1YZbRTAvBgkqhkiG9w0BCQQxIgQg
# 91t+/yGFJCUE5NsbBOG0Hw/E7Vdzjudzti+/nbLZdckwNwYLKoZIhvcNAQkQAi8x
# KDAmMCQwIgQgdnafqPJjLx9DCzojMK7WVnX+13PbBdZluQWTmEOPmtswDQYJKoZI
# hvcNAQEBBQAEggIADUsmhNkqwPHyduE/LMLH6IUAPEO3dsclEweOlzpBdKZBu9fQ
# tCGimK+caYqgpVJQptKA5MTx1D5gIbp56QcynUfUv3f0IMQgP0wo/s5RJrLQ5J5I
# D31Jo7yc6lFzyP7i6qgLdLWLCx0RnWc8fv5i+QTZ4nfD8E7U4qsj/WTnMu6twN8m
# u2dGXC3A0RqP33lw0/EcDfvN2GuAKrR4iTOegoVVvAQMPC9H2MQqa/iVksGB1zsl
# vJ80V2dekLKqwGAG4CZW5v8Ck8ouK/ccURm4j+KNJEdqCZj/d4l9cKzqZ5Urb1rd
# xJadR4ASBc9gtuocxzIQoft/QrI2PA1ziO/PZuwN0obJfzNanUkylzmCUZVpmjNp
# DqjIJBIAoOdeSJwdGVSW7YksED6F/ZoCGzcX+Fl7w5X0AglNzLOwbdg5Koysemb7
# 1f5dQucDnQX1tZjw/VjuzSO4RD+VeAP7ZRI51LzON8tNux3LBXV9QFFpOcNv7rRU
# sWejXmdwVF0luUmNoXFLmcZ20+5PBZTrCF8GwkJzDCz3gI0RGfwZu9RSRuDprqlQ
# 5SRD6GhcDIkrTCDu8YrpWbo4FrCTRR+s5Rr80mQFU7LB5yfTqAyO1nuZnGD78q8a
# 19gdCB5mJ8pZZJwXxU27B++c1wB8TcoK9SMKgFgtbG5fbTpBm5ku5y4TPQ0=
# SIG # End signature block
