<#
.SYNOPSIS
Gets the current OS patch status for a system, and scores based on the Essential Eight Maturity Model.

.DESCRIPTION
This function obtains the previously stored MSRC critical patch information.
Once obtained, it compares this information with the most recently installed critical patch to determine a maturity score.

.OUTPUTS
The number of failed steps, and the message entries for the function.
#>
function Get-OSPatchingStatus {
    $failedsteps = 0 #defaults to zero, so if you don't indicate anything failed, the test will be regarded as successful
    $messages = [System.Collections.ArrayList]@()
    #Load patch data
    try {
        #Exception will occur if file does not exist
        $msrcdata = (Get-ChildItem $global:DataPath\msrc_data.txt -ErrorAction Stop)
        if ($msrcdata.LastWriteTime -gt (Get-Date).AddDays(-14)) { $GoodMSRC = $true }
        #MSRC data is too old
        else {
            $messages.Add(@{"MessageType" = "FAILED_ERROR"; "Message" = "OS patch data is more than two weeks old. Please run the ""update-e8mvt-data.ps1"" script." }) | out-null
            $GoodMSRC = $false
        }
    }
    #MSRC data is not present
    catch {
        $messages.Add(@{"MessageType" = "FAILED_ERROR"; "Message" = "OS patch data is not present. Please run the ""update-e8mvt-data.ps1"" script." }) | out-null
        $GoodMSRC = $false
    }

    #Data is present, attempt to extract
    if($GoodMSRC){
        #grab the msrc data
        try {
            $data = get-content $global:DataPath\msrc_data.txt -ErrorAction Stop
            $converted = ConvertFrom-Json $data
            $GoodMSRC = $true
        }
        catch {
            $messages.Add(@{"MessageType" = "FAILED_ERROR"; "Message" = "An error occurred extracting the OS patch data. Please run the ""update-e8mvt-data.ps1"" script." }) | out-null
            $GoodMSRC = $false
        }
    }

    #Perform the analysis
    if ($GoodMSRC) {
        #get installed patches
        try {
            $installedPatches = @()

            #get patches from QFE
            $qfepatches = (Get-CimInstance win32_quickfixengineering | Sort-Object [date]InstalledOn -Descending -ErrorAction stop)
            foreach ($update in $qfepatches)
            {
                #remove install date
                Remove-Variable InstallDate -ErrorAction SilentlyContinue
                try {
                    $InstallDate = [datetime]$update.InstalledOn
                }
                catch {
                    #no date, or couldn't parse
                    continue;
                }

                $KB = New-Object -TypeName PSObject
                $KB | Add-Member -MemberType NoteProperty -Name HotFixID -Value $update.HotFixID
                $KB | Add-Member -MemberType NoteProperty -Name InstalledOn -Value $InstallDate
                $KB | Add-Member -MemberType NoteProperty -Name Type -Value "QFE"
                $installedPatches += $KB
            }
            
            #Get patches from windows update history
            $Session = New-Object -ComObject "Microsoft.Update.Session"
            $Searcher = $Session.CreateUpdateSearcher()
            $historyCount = $Searcher.GetTotalHistoryCount()
            $UpdateHistory = $Searcher.QueryHistory(0, $historyCount)

            $trimmedHistory = $UpdateHistory | Where-Object {$_.title -match "KB[0-9]"} | Sort-Object date -descending
            
            foreach ($update in $trimmedHistory)
            {
                #remove install date
                Remove-Variable InstallDate -ErrorAction SilentlyContinue
                try {
                    $InstallDate = ([datetime]$update.Date)
                }
                catch {
                    #no date, or couldn't parse
                    continue;
                }

                $KB = New-Object -TypeName PSObject
                $KB | Add-Member -MemberType NoteProperty -Name HotFixID -Value ([regex]::match($update.Title,'(KB[0-9]{6,7})').value)
                $KB | Add-Member -MemberType NoteProperty -Name InstalledOn -Value $InstallDate
                $KB | Add-Member -MemberType NoteProperty -Name Type -Value "WUH"
                $installedPatches += $KB
            }

            $installedPatches = $installedPatches | Sort-Object InstalledOn -Descending
        }
        catch {
            $messages.Add(@{"MessageType" = "FAILED_ERROR"; "Message" = "Could not extract patch details from Win QFE: $_" }) | out-null
            $failedsteps++;
            $installedPatches = ""
        }

        #get windows details
        try {
            $ProductNamePattern = (Get-CimInstance Win32_OperatingSystem).Caption
        }
        catch {
            $messages.Add(@{"MessageType" = "FAILED_ERROR"; "Message" = "Could not extract product name: $_" }) | out-null
            $failedsteps++;
            $ProductNamePattern = ""
        }

        #OS type
        try {
            $osarch = (Get-CimInstance Win32_OperatingSystem).OSArchitecture
        }
        catch {
            $messages.Add(@{"MessageType" = "FAILED_ERROR"; "Message" = "Could not determine architecture: $_" }) | out-null
            $failedsteps++;
            $osarch = ""
        }

        if ($osarch -match "64") { $osarch = "x64" }
        elseif ($osarch -match "32") { $osarch = "32-" }
        else { $osarch = "" }

        if ($ProductNamePattern -match "Windows 10") {
            #get first three digits, to account for version changes
            $win10_version = ((Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -Name ReleaseID -ErrorAction Stop).ReleaseID)
            if ($win10_version -ge 2009){
                $win10_version = ((Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -Name DisplayVersion -ErrorAction Stop).DisplayVersion)
            }
            $win10_version = $win10_version.Substring(0,3)
            $ProductNamePattern = "Windows 10.*$win10_version.*$osarch" #try to grab windows version
        }
        elseif ($ProductNamePattern -match "Windows 11") {
            #get first three digits, to account for version changes
            $win11_version = ((Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -Name ReleaseID -ErrorAction Stop).ReleaseID)
            if ($win11_version -ge 2009){
                $win11_version = ((Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -Name DisplayVersion -ErrorAction Stop).DisplayVersion)
            }
            $win11_version = $win11_version.Substring(0,3)
            $ProductNamePattern = "Windows 11.*$win11_version.*$osarch" #try to grab windows version
        }
        elseif($ProductNamePattern -match "Windows Server") {
            $winserver_version = ((Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -Name ProductName -ErrorAction Stop).ProductName)
            $winserver_version = $winserver_version.Substring(0,$winserver_version.LastIndexOf(' '))
            $ProductNamePattern = "$winserver_version" #try to grab windows version
        }

        else { $ProductNamePattern = "$ProductNamePattern.*$osarch" } #try to grab windows version

        #configure found flag
        $found = $false
        $latestPatchReleaseDate = $null
       
        #look at patches til you find one
        foreach ($patch in $installedPatches) {

            $patchDate = ($converted.where( { $($patch.HotFixID -replace "KB","") -in $_.kbArticles -and $_.product -match $ProductNamePattern }) | select-object initialReleaseDate -Unique -Last 1)
            if ($patchDate) {
                #found a result
                #get the time the patch was installed versus the release time for the KB
                $installtime = NEW-TIMESPAN -Start $patchDate.initialReleaseDate -End $patch.InstalledOn
                $days = [math]::round($installtime.totaldays, 2)

                #determine maturity of this patch (one level)
                Remove-Variable lvl -ErrorAction ignore #remove the lvl variable
                if ($days -gt 30) { $lvl = 0 }
                if ($days -le 30) { $lvl = 2 }
                #if ($days -le 14) { $lvl = 2 } #not required for non-IFS
                if ($days -le 2) { $lvl = 3 }

                #max maturity can't be higher than the maturity level
                $minmaturitytopass = ((get-item ..) | where-object { $_.Name -match "^Maturity" }); if ($minmaturitytopass) { $minmaturitytopass = [int]($minmaturitytopass.Name[-1].ToString()) } else { $minmaturitytopass = 1 }
                if ($lvl -gt $minmaturitytopass) { $lvl = $minmaturitytopass }

                if ($lvl -lt $minmaturitytopass) {
                    $failedsteps++;
                    $messages.Add(@{"MessageType" = "FAILED"; "Message" = "Most recently installed critical patch, $($patch.HotFixID), installed at $(($patch.InstalledOn).ToString('dd/MM/yyyy HH:MM:ss')), patch was released: $(([DateTime]$patchDate.initialReleaseDate).ToString('dd/MM/yyyy')), a lag of $days days, resultant maturity for this patch is $lvl" }) | out-null;
                    $messages.Add(@{"MessageType" = "REMEDIATION"; "Message" = "Examine your patching strategy to improve timeliness of patch installation, and check your patch management solution to ensure it is applying patches to all associated systems. Advice for assessing and installing security patches can be found here: https://www.cyber.gov.au/publications/assessing-security-vulnerabilities-and-applying-patches" }) | out-null;
                }
                else {
                    $messages.Add(@{"MessageType" = "SUCCESS"; "Message" = "Most recently installed critical patch, $($patch.HotFixID), installed at $(($patch.InstalledOn).ToString('dd/MM/yyyy HH:MM:ss')), patch was released: $(([DateTime]$patchDate.initialReleaseDate).ToString('dd/MM/yyyy')), a lag of $days days, resultant maturity for this patch is $lvl" }) | out-null;
                }

                $found = $true
                $latestPatchReleaseDate = [DateTime]$patchDate.initialReleaseDate
                #only looking at most recently matched patch, so break here
                break;
            }
            #remove it
            Remove-Variable patchDate
        }
        if (-not $found) {
            $messages.Add(@{"MessageType" = "FAILED"; "Message" = "No critical patches were detected as having been installed from the last 180 days of patches. Either this system has not received any critical patches in that time, or is so newly installed that patch rollups have covered all criticals. Run this script on a more representative system." }) | out-null
            $failedsteps++;
        }
        #Check for patches released after the latest installed patch and older than the acceptable maturity time frame
        if($latestPatchReleaseDate){
            $latestPatches = ($converted.where( {[DateTime]($_.initialReleaseDate) -gt $latestPatchReleaseDate -and [DateTime]($_.initialReleaseDate) -lt (Get-Date).AddDays(-14) -and $_.product -match $ProductNamePattern  }) )
            if($latestPatches.Count -gt 0){
                $messages.Add(@{"MessageType" = "FAILED"; "Message" = "A critical patch has been released since the latest installed patch, that has not been installed within two weeks of release." }) | out-null;
                $failedsteps++;
            }
        }
        #operating system caveat
        $messages.Add(@{"MessageType" = "REQUIREDINFO"; "Message" = "Some inconsistencies have been observed with extracting patch install dates of installed patches from individual Windows systems. The ASD's ACSC recommends the performing a credentialed vulnerability scan against a representative sample of your environment for more consistent results." }) | out-null
    }
    #MSRC data is not present, or too old, or did not extract properly
    else {
        $failedsteps++;
    }

    return $failedsteps, $messages
}

<#
.SYNOPSIS
This function determines whether the installed operating system version is still supported by Microsoft.

.DESCRIPTION
This function obtains the system version details and build information, then compares it against data sourced from the Microsoft lifecycle information.

.LINK
https://support.microsoft.com/en-au/help/13853/windows-lifecycle-fact-sheet
#>
function Get-OSSupportStatus {
    $failedsteps = 0 #defaults to zero, so if you don't indicate anything failed, the test will be regarded as successful
    $messages = [System.Collections.ArrayList]@()

    #default setting
    $supported = $false

    #win 10 flag
    $is_windows10 = $false

    #Vuln scanner message
    $vuln_scanner_message = "There are significant limitations to checking support periods for operating systems. The ASD's ACSC recommends using a credentialed vulnerability scan to accurately assess patching and support levels for operating systems."

    #Get operating system details (courtesty script by SMSAgentSoftware https://gist.github.com/SMSAgentSoftware/78659181ccbe0f59677209f3487d7030#file-get-windowsversion-ps1)
    $ProductName = (Get-CimInstance Win32_OperatingSystem).Caption
    #set win 10 version default
    $win10_version = "N/A"

    $today = (Get-Date)

    $build = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -Name CurrentBuild).CurrentBuild

    #Determine support level of OS, based on:
    #https://support.microsoft.com/en-au/help/13853/windows-lifecycle-fact-sheet
    #https://en.wikipedia.org/wiki/List_of_Microsoft_Windows_versions#cite_ref-4
    if ($ProductName -match "Windows Server (\d\d\d\d)") {
        $year = $matches[1]
        #"It's a windows server box, year is $year"
        #Not counting ESU
        if ($year -gt 2012) {
            $supported = $true
        }
    }
    elseif ($ProductName -match "Windows 10" ) {
        #"It's a windows 10 box!"
        $is_windows10 = 10
        #grab the release version
        Try {
            $win10_version = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -Name DisplayVersion -ErrorAction Stop).DisplayVersion
        }
        Catch {
            $win10_version = "N/A"
            throw "error grabbing win 10 release ID"
        }
        $win10_21h2_endsupport = (Get-Date -Date "2024-06-11")
        $win10_22h2_endsupport = (Get-Date -Date "2025-10-14")

        #enterprise/education has longer support for 22H1
        if ($ProductName -match "Enterprise|Education" -and $win10_version -eq "21H2" -and ($today -lt $win10_21h2_endsupport)) {
            $supported = $true
        }
        #All Win10 support sunsets on Oct 14 2025
        elseif ($win10_version -eq "22H2" -and ($today -lt $win10_22h2_endsupport)) {
            $supported = $true
        }
    }
    elseif ($ProductName -match "Windows 11" ) {
        #"It's a windows 11 box!"
        $is_windows10 = 11
        #grab the release version
        Try {
            $win10_version = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -Name DisplayVersion -ErrorAction Stop).DisplayVersion
        }
        Catch {
            $win10_version = "N/A"
            throw "error grabbing win 11 release ID"
        }

        #check if it's enterprise or regular
        if ($ProductName -match "Enterprise|Education") {
            #"Enterprise or education, doesn't really matter which"
            if ($win10_version -eq "21H2" -and ($today -lt (Get-Date -Date "2024-10-08"))) {
                $supported = $true
            }
            elseif ($win10_version -eq "22H2" -and ($today -lt (Get-Date -Date "2025-10-14"))) {
                $supported = $true
            }
            elseif ($win10_version -eq "23H2" -and ($today -lt (Get-Date -Date "2026-11-10"))) {
                $supported = $true
            }
        }
        else {
            #"Some other version"
            if ($win10_version -eq "22H2" -and ($today -lt (Get-Date -Date "2024-10-08"))) {
                $supported = $true
            }
            elseif ($win10_version -eq "23H2" -and ($today -lt (Get-Date -Date "2025-11-11"))) {
                $supported = $true
            }
        }
    }

    #success/failure
    if ($supported) {
        if ($is_windows10) {
            $messages.Add(@{"MessageType" = "SUCCESS"; "Message" = "$ProductName is within the support period (OS Build: $build, Windows $is_windows10 Version: $win10_version)" }) | out-null
        }
        else {
            $messages.Add(@{"MessageType" = "SUCCESS"; "Message" = "$ProductName is within the support period (OS Build: $build)" }) | out-null
        }
        $messages.Add(@{"MessageType" = "SUCCESS"; "Message" = "Support timeframes can be found here: https://support.microsoft.com/en-au/help/13853/windows-lifecycle-fact-sheet" }) | out-null
        $messages.Add(@{"MessageType" = "SUCCESS"; "Message" = $vuln_scanner_message }) | out-null
    }
    else {
        if ($is_windows10) {
            $messages.Add(@{"MessageType" = "FAILED"; "Message" = "$ProductName is an unsupported version (OS Build: $build, Windows $is_windows10 Version: $win10_version)" }) | out-null
        }
        else {
            $messages.Add(@{"MessageType" = "FAILED"; "Message" = "$ProductName is an unsupported version (OS Build: $build)" }) | out-null
        }
        $messages.Add(@{"MessageType" = "REMEDIATION"; "Message" = "This operating system version is out of support. Transition this system to a version within the support timeframe." }) | out-null
        $messages.Add(@{"MessageType" = "REMEDIATION"; "Message" = "Support timeframes can be found here: https://support.microsoft.com/en-au/help/13853/windows-lifecycle-fact-sheet" }) | out-null
        $messages.Add(@{"MessageType" = "FAILED"; "Message" = $vuln_scanner_message }) | out-null
        $failedsteps++;
    }

    return $failedsteps, $messages
}

#Package date: 2024-10-16; Build Version: d215424
#Requires -Version 3.0


# SIG # Begin signature block
# MIIoeAYJKoZIhvcNAQcCoIIoaTCCKGUCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAevdmuZSpho2Ns
# s8BE+hkE8UfP0a5s8tNrevl5Ek4WgKCCDeowggawMIIEmKADAgECAhAIrUCyYNKc
# TJ9ezam9k67ZMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0z
# NjA0MjgyMzU5NTlaMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQDVtC9C0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0
# JAfhS0/TeEP0F9ce2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJr
# Q5qZ8sU7H/Lvy0daE6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhF
# LqGfLOEYwhrMxe6TSXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+F
# LEikVoQ11vkunKoAFdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh
# 3K3kGKDYwSNHR7OhD26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJ
# wZPt4bRc4G/rJvmM1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQay
# g9Rc9hUZTO1i4F4z8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbI
# YViY9XwCFjyDKK05huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchAp
# QfDVxW0mdmgRQRNYmtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRro
# OBl8ZhzNeDhFMJlP/2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IB
# WTCCAVUwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+
# YXsIiGX0TkIwHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0P
# AQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAC
# hjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9v
# dEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAED
# MAgGBmeBDAEEATANBgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql
# +Eg08yy25nRm95RysQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFF
# UP2cvbaF4HZ+N3HLIvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1h
# mYFW9snjdufE5BtfQ/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3Ryw
# YFzzDaju4ImhvTnhOE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5Ubdld
# AhQfQDN8A+KVssIhdXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw
# 8MzK7/0pNVwfiThV9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnP
# LqR0kq3bPKSchh/jwVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatE
# QOON8BUozu3xGFYHKi8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bn
# KD+sEq6lLyJsQfmCXBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQji
# WQ1tygVQK+pKHJ6l/aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbq
# yK+p/pQd52MbOoZWeE4wggcyMIIFGqADAgECAhAP3GnppLmrUp/TG1q4uFF+MA0G
# CSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwHhcNMjQwOTE2MDAwMDAwWhcNMjcxMDEx
# MjM1OTU5WjCBuTELMAkGA1UEBhMCQVUxGjAYBgNVBAgTEVdlc3Rlcm4gQXVzdHJh
# bGlhMREwDwYDVQQHEwhLb2phcmVuYTEnMCUGA1UEChMeQXVzdHJhbGlhbiBTaWdu
# YWxzIERpcmVjdG9yYXRlMSkwJwYDVQQLEyBBdXN0cmFsaWFuIEN5YmVyIFNlY3Vy
# aXR5IENlbnRyZTEnMCUGA1UEAxMeQXVzdHJhbGlhbiBTaWduYWxzIERpcmVjdG9y
# YXRlMIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAw0cTiNUzc3vbheXu
# Z741I3JRxbhU5iLiP1IBSZP3amEIPPdR5JEbgh1OrMUSXOzBBo8JKTYwCLztOiyv
# jUEdeRGFXvWPq04aNoiSeU8/mCWjcQ+Jb0TYsrpLFsCgdRLjCIJrzbss4lTgK1Tm
# UIHMJarlrJwLurhp58BAIwEhQpr2eUUzjw2jGGwm85suDNRq9pJb5cHDYSDLGumL
# 6br5QuHClb3pIcZBY7Qh/Hw5WYALHqWO5EuSAfWVAtieBy5qLUi2Xi3/9WTh1sAg
# 8XEeUXwE0DjbL4UlgNtL4OUYNcABGvolOsT/tFPGwch/LrQZCKN8P/pDfOAon+qy
# AW9sqU+mSVPT7oPzEirFgnVyXaP2oVAAM8WQLm9VNHcetkunAyREvT/wzgx8/Lbj
# NJV+ZvDr2bNTuEfQn7OVe2ndR6tXJqeuRfDjyj0z9GGpcsfVButoYM3lRJz7X58D
# 2oRUT/aQn4MTWGWjEmbrbDQtV2IJxVXzwRRVsy1rnWjCJzJVAgMBAAGjggIDMIIB
# /zAfBgNVHSMEGDAWgBRoN+Drtjv4XxGG+/5hewiIZfROQjAdBgNVHQ4EFgQUHzn7
# SCjwpCIAZVQj8S3DVGL/mtcwPgYDVR0gBDcwNTAzBgZngQwBBAEwKTAnBggrBgEF
# BQcCARYbaHR0cDovL3d3dy5kaWdpY2VydC5jb20vQ1BTMA4GA1UdDwEB/wQEAwIH
# gDATBgNVHSUEDDAKBggrBgEFBQcDAzCBtQYDVR0fBIGtMIGqMFOgUaBPhk1odHRw
# Oi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmlu
# Z1JTQTQwOTZTSEEzODQyMDIxQ0ExLmNybDBToFGgT4ZNaHR0cDovL2NybDQuZGln
# aWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hB
# Mzg0MjAyMUNBMS5jcmwwgZQGCCsGAQUFBwEBBIGHMIGEMCQGCCsGAQUFBzABhhho
# dHRwOi8vb2NzcC5kaWdpY2VydC5jb20wXAYIKwYBBQUHMAKGUGh0dHA6Ly9jYWNl
# cnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVTaWduaW5nUlNB
# NDA5NlNIQTM4NDIwMjFDQTEuY3J0MAkGA1UdEwQCMAAwDQYJKoZIhvcNAQELBQAD
# ggIBAJQ6toTdsoB0xPBqLd9tjHbN1vFAnjiqwHMsONbgVz5nqkqxdfFdcJbC+u9i
# b0sKaLl3lTzgUsvvleVu4tKK1hl0FWfwlAInypuC1a1UnKzGjRLMoNyz2AOVGSl7
# Y5PrVClnEuG8O5zxqNYkiN2IZHlVj2xZP10kLNL2sSRGaoiZqoEIW8z0G68gjrou
# Jgdgw14lt7QsGpUAcPMI9/l/hbyZIOPWPJus+Ock4hHPWiApVLlARki/2fE1IWXE
# b6KNgNYpcup3JvX/XzCHEM+cXZ2qcBwOdCukiroqxR0ku/yn59HMT3MG6o3GJGth
# sBLS9K5Vzg+YMSkV6iMnTi8sQknZA564Gk3gdv0SzF2MGT5Pc7p/IH4o4wPjn9Md
# fi3IDe1SRZeDa2I2qfjmLJ1VJWyug1NmbnXJTz7NeLODXNTDcLgFWNeokB71fhnn
# 6PQhCF2l7xITwrAbsY2lHiykV9b0QFhWKemNUKY3PW3no43fUci+ttxBrMpIHejC
# +1/rZcImMKgZVsMqRJJTAh/TW0aYZSRgz4sngv9HY/LYcmEQpgYpzGAIBKArgzBR
# A6riFJ+azKkOCK1trgO7k0giQ3xN2asmcDRzBjtrVY6vutNSPPXHL98WwHh46KLg
# m+tyhiPaG++Z/v1Pq2CWcKIvuzS3RyjOSQl77j5cjrbTxOmeMYIZ5DCCGeACAQEw
# fTBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNV
# BAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgQ29kZSBTaWduaW5nIFJTQTQwOTYgU0hB
# Mzg0IDIwMjEgQ0ExAhAP3GnppLmrUp/TG1q4uFF+MA0GCWCGSAFlAwQCAQUAoHww
# EAYKKwYBBAGCNwIBDDECMAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYK
# KwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIGu2JMhs
# KWBi494kk3j/hQgIfiVmG4+IdwPO4IRRUq5fMA0GCSqGSIb3DQEBAQUABIIBgDDf
# iGG4X+7Sw9F6xGfbg/egUj9A5Y711wbtSqcjAq7hBfrtQPEshw7akI+hA52r0niZ
# olmOIZeC/KJ0cQqCZ8Y9aPAJzW1XaTgqqSMJdZTGSD/c5Z8D8m3TPleWLGhnOjqd
# GLJBjQJ3uiqGf1rgRq9+xU9vQU4HSpL0ED0TSvMkjNXBYQY4JqqXVwNkpn8lmePK
# VjC8nBiXKdaXvUX7Km3RPjUHAkcAkSTmCgKAFbsCzmeuGfBjE5MkprZaRRZbGnc7
# Liz7eHNyUF+ShwRKUE6O77XfGTCgTRnXYeiu+1aiuIBg7KKh/fqlQEVjD7PaS50u
# hydIHeb0a2GAzycMLU7sNMk5XG9KqCMUpUWTWxWaFrP0/HZfTgGsaIcT/9mHtHXh
# jWk0wVMVirj/MVg0RuS69VAk8/zicTky25Oc4YxzOdiBy6GHWeAblP79dPa7sq2g
# GSAQEzhuTFqFHbq2fCyHU7R6BKlPuullAVhvZuBLDYHqRkABTSbbeeCnQe7DQKGC
# Fzowghc2BgorBgEEAYI3AwMBMYIXJjCCFyIGCSqGSIb3DQEHAqCCFxMwghcPAgED
# MQ8wDQYJYIZIAWUDBAIBBQAweAYLKoZIhvcNAQkQAQSgaQRnMGUCAQEGCWCGSAGG
# /WwHATAxMA0GCWCGSAFlAwQCAQUABCB4YQ3xL9TejiTKYgS2pronn4WhfXOlkg8I
# dTuolGBALQIRAL61407E2bIxXidCZRQufWYYDzIwMjQxMDE2MDYxNTM2WqCCEwMw
# gga8MIIEpKADAgECAhALrma8Wrp/lYfG+ekE4zMEMA0GCSqGSIb3DQEBCwUAMGMx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMy
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcg
# Q0EwHhcNMjQwOTI2MDAwMDAwWhcNMzUxMTI1MjM1OTU5WjBCMQswCQYDVQQGEwJV
# UzERMA8GA1UEChMIRGlnaUNlcnQxIDAeBgNVBAMTF0RpZ2lDZXJ0IFRpbWVzdGFt
# cCAyMDI0MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAvmpzn/aVIauW
# MLpbbeZZo7Xo/ZEfGMSIO2qZ46XB/QowIEMSvgjEdEZ3v4vrrTHleW1JWGErrjOL
# 0J4L0HqVR1czSzvUQ5xF7z4IQmn7dHY7yijvoQ7ujm0u6yXF2v1CrzZopykD07/9
# fpAT4BxpT9vJoJqAsP8YuhRvflJ9YeHjes4fduksTHulntq9WelRWY++TFPxzZrb
# ILRYynyEy7rS1lHQKFpXvo2GePfsMRhNf1F41nyEg5h7iOXv+vjX0K8RhUisfqw3
# TTLHj1uhS66YX2LZPxS4oaf33rp9HlfqSBePejlYeEdU740GKQM7SaVSH3TbBL8R
# 6HwX9QVpGnXPlKdE4fBIn5BBFnV+KwPxRNUNK6lYk2y1WSKour4hJN0SMkoaNV8h
# yyADiX1xuTxKaXN12HgR+8WulU2d6zhzXomJ2PleI9V2yfmfXSPGYanGgxzqI+Sh
# oOGLomMd3mJt92nm7Mheng/TBeSA2z4I78JpwGpTRHiT7yHqBiV2ngUIyCtd0pZ8
# zg3S7bk4QC4RrcnKJ3FbjyPAGogmoiZ33c1HG93Vp6lJ415ERcC7bFQMRbxqrMVA
# Niav1k425zYyFMyLNyE1QulQSgDpW9rtvVcIH7WvG9sqYup9j8z9J1XqbBZPJ5XL
# ln8mS8wWmdDLnBHXgYly/p1DhoQo5fkCAwEAAaOCAYswggGHMA4GA1UdDwEB/wQE
# AwIHgDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMCAGA1Ud
# IAQZMBcwCAYGZ4EMAQQCMAsGCWCGSAGG/WwHATAfBgNVHSMEGDAWgBS6FtltTYUv
# cyl2mi91jGogj57IbzAdBgNVHQ4EFgQUn1csA3cOKBWQZqVjXu5Pkh92oFswWgYD
# VR0fBFMwUTBPoE2gS4ZJaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0
# VHJ1c3RlZEc0UlNBNDA5NlNIQTI1NlRpbWVTdGFtcGluZ0NBLmNybDCBkAYIKwYB
# BQUHAQEEgYMwgYAwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNv
# bTBYBggrBgEFBQcwAoZMaHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lD
# ZXJ0VHJ1c3RlZEc0UlNBNDA5NlNIQTI1NlRpbWVTdGFtcGluZ0NBLmNydDANBgkq
# hkiG9w0BAQsFAAOCAgEAPa0eH3aZW+M4hBJH2UOR9hHbm04IHdEoT8/T3HuBSyZe
# q3jSi5GXeWP7xCKhVireKCnCs+8GZl2uVYFvQe+pPTScVJeCZSsMo1JCoZN2mMew
# /L4tpqVNbSpWO9QGFwfMEy60HofN6V51sMLMXNTLfhVqs+e8haupWiArSozyAmGH
# /6oMQAh078qRh6wvJNU6gnh5OruCP1QUAvVSu4kqVOcJVozZR5RRb/zPd++PGE3q
# F1P3xWvYViUJLsxtvge/mzA75oBfFZSbdakHJe2BVDGIGVNVjOp8sNt70+kEoMF+
# T6tptMUNlehSR7vM+C13v9+9ZOUKzfRUAYSyyEmYtsnpltD/GWX8eM70ls1V6QG/
# ZOB6b6Yum1HvIiulqJ1Elesj5TMHq8CWT/xrW7twipXTJ5/i5pkU5E16RSBAdOp1
# 2aw8IQhhA/vEbFkEiF2abhuFixUDobZaA0VhqAsMHOmaT3XThZDNi5U2zHKhUs5u
# HHdG6BoQau75KiNbh0c+hatSF+02kULkftARjsyEpHKsF7u5zKRbt5oK5YGwFvgc
# 4pEVUNytmB3BpIiowOIIuDgP5M9WArHYSAR16gc0dP2XdkMEP5eBsX7bf/MGN4K3
# HP50v/01ZHo/Z5lGLvNwQ7XHBx1yomzLP8lx4Q1zZKDyHcp4VQJLu2kWTsKsOqQw
# ggauMIIElqADAgECAhAHNje3JFR82Ees/ShmKl5bMA0GCSqGSIb3DQEBCwUAMGIx
# CzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3
# dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBH
# NDAeFw0yMjAzMjMwMDAwMDBaFw0zNzAzMjIyMzU5NTlaMGMxCzAJBgNVBAYTAlVT
# MRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMyRGlnaUNlcnQgVHJ1
# c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcgQ0EwggIiMA0GCSqG
# SIb3DQEBAQUAA4ICDwAwggIKAoICAQDGhjUGSbPBPXJJUVXHJQPE8pE3qZdRodbS
# g9GeTKJtoLDMg/la9hGhRBVCX6SI82j6ffOciQt/nR+eDzMfUBMLJnOWbfhXqAJ9
# /UO0hNoR8XOxs+4rgISKIhjf69o9xBd/qxkrPkLcZ47qUT3w1lbU5ygt69OxtXXn
# HwZljZQp09nsad/ZkIdGAHvbREGJ3HxqV3rwN3mfXazL6IRktFLydkf3YYMZ3V+0
# VAshaG43IbtArF+y3kp9zvU5EmfvDqVjbOSmxR3NNg1c1eYbqMFkdECnwHLFuk4f
# sbVYTXn+149zk6wsOeKlSNbwsDETqVcplicu9Yemj052FVUmcJgmf6AaRyBD40Nj
# gHt1biclkJg6OBGz9vae5jtb7IHeIhTZgirHkr+g3uM+onP65x9abJTyUpURK1h0
# QCirc0PO30qhHGs4xSnzyqqWc0Jon7ZGs506o9UD4L/wojzKQtwYSH8UNM/STKvv
# mz3+DrhkKvp1KCRB7UK/BZxmSVJQ9FHzNklNiyDSLFc1eSuo80VgvCONWPfcYd6T
# /jnA+bIwpUzX6ZhKWD7TA4j+s4/TXkt2ElGTyYwMO1uKIqjBJgj5FBASA31fI7tk
# 42PgpuE+9sJ0sj8eCXbsq11GdeJgo1gJASgADoRU7s7pXcheMBK9Rp6103a50g5r
# mQzSM7TNsQIDAQABo4IBXTCCAVkwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4E
# FgQUuhbZbU2FL3MpdpovdYxqII+eyG8wHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5n
# P+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMIMHcG
# CCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQu
# Y29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGln
# aUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8v
# Y3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAgBgNV
# HSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEwDQYJKoZIhvcNAQELBQADggIB
# AH1ZjsCTtm+YqUQiAX5m1tghQuGwGC4QTRPPMFPOvxj7x1Bd4ksp+3CKDaopafxp
# wc8dB+k+YMjYC+VcW9dth/qEICU0MWfNthKWb8RQTGIdDAiCqBa9qVbPFXONASIl
# zpVpP0d3+3J0FNf/q0+KLHqrhc1DX+1gtqpPkWaeLJ7giqzl/Yy8ZCaHbJK9nXzQ
# cAp876i8dU+6WvepELJd6f8oVInw1YpxdmXazPByoyP6wCeCRK6ZJxurJB4mwbfe
# Kuv2nrF5mYGjVoarCkXJ38SNoOeY+/umnXKvxMfBwWpx2cYTgAnEtp/Nh4cku0+j
# Sbl3ZpHxcpzpSwJSpzd+k1OsOx0ISQ+UzTl63f8lY5knLD0/a6fxZsNBzU+2QJsh
# IUDQtxMkzdwdeDrknq3lNHGS1yZr5Dhzq6YBT70/O3itTK37xJV77QpfMzmHQXh6
# OOmc4d0j/R0o08f56PGYX/sr2H7yRp11LB4nLCbbbxV7HhmLNriT1ObyF5lZynDw
# N7+YAN8gFk8n+2BnFqFmut1VwDophrCYoCvtlUG3OtUVmDG0YgkPCr2B2RP+v6TR
# 81fZvAT6gt4y3wSJ8ADNXcL50CN/AAvkdgIm2fBldkKmKYcJRyvmfxqkhQ/8mJb2
# VVQrH4D6wPIOK+XW+6kvRBVK5xMOHds3OBqhK/bt1nz8MIIFjTCCBHWgAwIBAgIQ
# DpsYjvnQLefv21DiCEAYWjANBgkqhkiG9w0BAQwFADBlMQswCQYDVQQGEwJVUzEV
# MBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29t
# MSQwIgYDVQQDExtEaWdpQ2VydCBBc3N1cmVkIElEIFJvb3QgQ0EwHhcNMjIwODAx
# MDAwMDAwWhcNMzExMTA5MjM1OTU5WjBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMM
# RGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQD
# ExhEaWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwggIiMA0GCSqGSIb3DQEBAQUAA4IC
# DwAwggIKAoICAQC/5pBzaN675F1KPDAiMGkz7MKnJS7JIT3yithZwuEppz1Yq3aa
# za57G4QNxDAf8xukOBbrVsaXbR2rsnnyyhHS5F/WBTxSD1Ifxp4VpX6+n6lXFllV
# cq9ok3DCsrp1mWpzMpTREEQQLt+C8weE5nQ7bXHiLQwb7iDVySAdYyktzuxeTsiT
# +CFhmzTrBcZe7FsavOvJz82sNEBfsXpm7nfISKhmV1efVFiODCu3T6cw2Vbuyntd
# 463JT17lNecxy9qTXtyOj4DatpGYQJB5w3jHtrHEtWoYOAMQjdjUN6QuBX2I9YI+
# EJFwq1WCQTLX2wRzKm6RAXwhTNS8rhsDdV14Ztk6MUSaM0C/CNdaSaTC5qmgZ92k
# J7yhTzm1EVgX9yRcRo9k98FpiHaYdj1ZXUJ2h4mXaXpI8OCiEhtmmnTK3kse5w5j
# rubU75KSOp493ADkRSWJtppEGSt+wJS00mFt6zPZxd9LBADMfRyVw4/3IbKyEbe7
# f/LVjHAsQWCqsWMYRJUadmJ+9oCw++hkpjPRiQfhvbfmQ6QYuKZ3AeEPlAwhHbJU
# KSWJbOUOUlFHdL4mrLZBdd56rF+NP8m800ERElvlEFDrMcXKchYiCd98THU/Y+wh
# X8QgUWtvsauGi0/C1kVfnSD8oR7FwI+isX4KJpn15GkvmB0t9dmpsh3lGwIDAQAB
# o4IBOjCCATYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQU7NfjgtJxXWRM3y5n
# P+e6mK4cD08wHwYDVR0jBBgwFoAUReuir/SSy4IxLVGLp6chnfNtyA8wDgYDVR0P
# AQH/BAQDAgGGMHkGCCsGAQUFBwEBBG0wazAkBggrBgEFBQcwAYYYaHR0cDovL29j
# c3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRwOi8vY2FjZXJ0cy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0EuY3J0MEUGA1UdHwQ+MDww
# OqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RFJvb3RDQS5jcmwwEQYDVR0gBAowCDAGBgRVHSAAMA0GCSqGSIb3DQEBDAUAA4IB
# AQBwoL9DXFXnOF+go3QbPbYW1/e/Vwe9mqyhhyzshV6pGrsi+IcaaVQi7aSId229
# GhT0E0p6Ly23OO/0/4C5+KH38nLeJLxSA8hO0Cre+i1Wz/n096wwepqLsl7Uz9FD
# RJtDIeuWcqFItJnLnU+nBgMTdydE1Od/6Fmo8L8vC6bp8jQ87PcDx4eo0kxAGTVG
# amlUsLihVo7spNU96LHc/RzY9HdaXFSMb++hUD38dglohJ9vytsgjTVgHAIDyyCw
# rFigDkBjxZgiwbJZ9VVrzyerbHbObyMt9H5xaiNrIv8SuFQtJ37YOtnwtoeW/VvR
# XKwYw02fc7cBqZ9Xql4o4rmUMYIDdjCCA3ICAQEwdzBjMQswCQYDVQQGEwJVUzEX
# MBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNVBAMTMkRpZ2lDZXJ0IFRydXN0
# ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1waW5nIENBAhALrma8Wrp/lYfG
# +ekE4zMEMA0GCWCGSAFlAwQCAQUAoIHRMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0B
# CRABBDAcBgkqhkiG9w0BCQUxDxcNMjQxMDE2MDYxNTM2WjArBgsqhkiG9w0BCRAC
# DDEcMBowGDAWBBTb04XuYtvSPnvk9nFIUIck1YZbRTAvBgkqhkiG9w0BCQQxIgQg
# Gdj7NcMEiAend+IpTYpEfg2jvnJaSoUa5yZOsBtPEGswNwYLKoZIhvcNAQkQAi8x
# KDAmMCQwIgQgdnafqPJjLx9DCzojMK7WVnX+13PbBdZluQWTmEOPmtswDQYJKoZI
# hvcNAQEBBQAEggIAtlvdtYa6/Na+BFunVqhk6uijpyl7B6yqlXaolIey6Q2jV1ER
# a0miTb3xwPPVy+asM2WAKY9BZ4YE1XLIfgmeHgFSow4Gc65rImBnmZj+9lxnFLY0
# zdNvm619fBwTrjnYvQ+erx+Y2Fq2yHqWsASjneXDBU0GolaDPZviejxwtH3HMfyz
# nlobdqOxSdB/CILXgPJerp2Vv0q6hNpiXv6/KbTuAzYZtKNzSkVEjvpNZyqeZ3UM
# SBrIAxI5bpxVQNBui+Oqfy3COVlF80b+Z6MoF9NP2NBZzScUUoetuB/x2q8RTArH
# tsUIzsVBFS4yVFOnuTE0xqat5BSBAX5SFWNacGsU2dI47OCQqtp8U8fTPzXNgvsL
# NqmN9AzOY374y8Trt/yHo+NnVxR0U4SlEsn/N8dQjvjvePzZjRyrFbVx8HxX0n0l
# f0Pn4O7B5UVa/Rf3+9dsmobEChO9jYrMUs60oe2Esj01RCSbKQ7GPLvxnTrLLlZl
# Xyv/b9FgazVrNUlO2OLDtnv6fnWL9xM4d8xRp+KcK+9hl6Ru5xH9UezlO51e61qF
# dQFtitXUrJ53qLIszRxEEbMvnHIyTCwFW5bnrBAVBPcu29ShiIuMaq571MmYIeFI
# DV92AYLm9Vngj7mPvDx1l1sQIf/1ePG6YCwIDa7WMoZMsdYQkd+QFhLPGHM=
# SIG # End signature block
