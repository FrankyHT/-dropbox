<#
.SYNOPSIS
Checks each installed copy of Office and confirms the provided registry settings matches the accepted hardened setting.

.DESCRIPTION
This function checks the provided registry key and confirms that it matches any of the provided valid values. This is performed for
each installed version of Office.

.PARAMETER SettingAppliesTo
The Office products that this setting applies to.

.PARAMETER SettingsDetail
The response message for each possible setting.

.PARAMETER RegistryKey
The registry setting containing the value to be checked.

.PARAMETER Remediation
The remediation advice to provide if the check fails.

.PARAMETER ValidSettings
The accepted settings for a correctly hardened configuration.
#>

function Get-OfficeHardeningConfiguration {
    Param
    (
        [Parameter(Mandatory = $true)]
        [hashtable]$SettingAppliesTo,
        [Parameter(Mandatory = $true)]
        [hashtable]$SettingsDetail,
        [Parameter(Mandatory = $true)]
        [string]$RegistryKey,
        [Parameter(Mandatory = $true)]
        [string]$Remediation,
        [Parameter(Mandatory = $true)]
        [int[]]$ValidSettings
    )

    #calculate match regex based on provided product values
    
    #Default configuration
    $OfficeVersions = @{12 = "2007"; 14 = "2010"; 15 = "2013"; 16 = "2016, 2019 and 365" }

    $failedsteps = 0 #defaults to zero, so if you don't indicate anything failed, the test will be regarded as successful
    $messages = [System.Collections.ArrayList]@()

    #Determine installed versions, based on actual executables in Program Files
    $installedofficeversions = Get-InstalledOfficeApplications $SettingAppliesTo
    
    #no office installed
    if ($installedofficeversions.Count -eq 0) {
        $messages.Add(@{"MessageType" = "SUCCESS"; "Message" = "There are no installed versions of Microsoft Office detected on this system." }) | out-null
    }

    foreach ($officeversion in $installedofficeversions.GetEnumerator()) {
        $keycheckvalues = @{}
        
        $versionnumber = "$($officeversion.Key).0"
        #check the associated products
        $keycheckvalues = Get-OfficeRegistryValues $versionnumber $RegistryKey $SettingAppliesTo

        #get array of the installed products
        $installedproducts = $officeversion.Value.Split(';')

        foreach ($assessedproduct in $keycheckvalues.GetEnumerator()) {
            #check if installed or not
            if ($installedproducts.Contains($assessedproduct.Key)) { $installed = "INSTALLED" } else { $installed = "NOT INSTALLED" }
            $productstatus = "{0} ({1})" -f $assessedproduct.Key, $installed
            $output = ($SettingsDetail[$assessedproduct.Value]) -f $OfficeVersions[$officeversion.Key], $productstatus
            #if setting is valid, success print
            if ($ValidSettings.Contains($assessedproduct.Value)) {
                $messages.Add(@{"MessageType" = "SUCCESS"; "Message" = ("Mature configuration: {0}" -f $output) }) | out-null
            }
            else {
                $messages.Add(@{"MessageType" = "FAILED"; "Message" = ("Invalid configuration: {0}" -f $output) }) | out-null
                $failedsteps++;
            }
        }
    }


    #add Remediation messaging
    if ($failedsteps -gt 0) {
        $messages.Add(@{"MessageType" = "REMEDIATION"; "Message" = $Remediation }) | out-null
    }

    return $failedsteps, $messages
}

Enum OfficeVersions
{
    Office_2007 = 12
    Office_2010 = 14
    Office_2013 = 15
    Office_2016 = 16
}

Enum HardeningMethod
{
    NotConfigured = 0
    EnableAllMacros = 1
    AllDisabledWithNotification = 2
    DigitallySigned = 3
    AllDisabledWithoutNotification = 4
}

<#
.SYNOPSIS
Returned the macro hardening method configured for each application

.DESCRIPTION
Checks the vbawarning registry key and matches to the HardeningMethod enum to return the hardening method chosen for each 
provided Office application.

.PARAMETER version
The Office version to check

.PARAMETER SettingAppliesTo
The Office products that this setting applies to.
#>

function Get-HardeningMethods($version, $SettingAppliesTo){
    $RegistryKey = "vbawarnings"
    $vbawarnings = Get-OfficeRegistryValues $version $RegistryKey $SettingAppliesTo
    $results = @{}
    foreach ($result in $vbawarnings.GetEnumerator()) {
        $results.Add($result.Key, [HardeningMethod]($result.Value))
    }
    return $results
}


<#
.SYNOPSIS
Returned the macro hardening method configured for a specific application

.DESCRIPTION
Checks the vbawarning registry key and matches to the HardeningMethod enum to return the hardening method chosen for the 
provided Office application.

.PARAMETER version
The Office version to check
.PARAMETER application
The specific Office product that this setting applies to.
#>

function Get-HardeningMethod($version, $application){
    $SettingAppliesTo = @{}
    $SettingAppliesTo.Add($application,$application)
    $methods = Get-HardeningMethods $version $SettingAppliesTo
    return [HardeningMethod]($methods[$application])
}
<#
.SYNOPSIS
Retrieve local or group policy configured Trusted Locations for an Office application.

.DESCRIPTION
Returns a list of Trusted Locations for a specific Office application.

.PARAMETER version
The Office version to restrict this check to.

.PARAMETER application
The Office application to check.

.PARAMETER scope
Whether this is for local or group policy configured locations.
#>

function Get-OfficeTrustedLocations($version, $application, $scope)
{
    $trustedlocations = [System.Collections.ArrayList]@()
    #alternate trusted locations check, gets application and path (may require additional paths)
    if ($scope -Eq "local"){
        $registrylocations = @(Get-ChildItem "HKCU:\software\microsoft\office\$version\$application\security\trusted locations" -recurse -ErrorAction SilentlyContinue)
    }else{
        $registrylocations = @(Get-ChildItem "HKCU:\software\Policies\microsoft\office\$version\$application\security\trusted locations" -recurse -ErrorAction SilentlyContinue)
    }
    if ($registrylocations){
        $registrylocations | ForEach-Object{$trustedlocations.Add(([OfficeVersions]$_.PSParentPath.ToString().Split("\")[-4].Split(".")[0],$_.PSParentPath.ToString().Split("\")[-3], $_.GetValue("Path"), $(If ($_.GetValue("AllowSubFolders")) {$_.GetValue("AllowSubFolders")} Else {"0"}))) | out-null}
    }
    return $trustedlocations
}

<#
.SYNOPSIS
Checks all known security related Office registry paths for settings.

.DESCRIPTION
Returns a dictionary of values for Office security registry keys

.PARAMETER versionnumber
The Office version to restrict this check to.

.PARAMETER RegistryKey
The registry key to check.

.PARAMETER SettingAppliesTo
The Office products that this setting applies to.
#>

function Get-OfficeRegistryValues($versionnumber, $RegistryKey, $SettingAppliesTo){
    $keycheckvalues = @{}
    $OfficeRegistryPaths = @("HKCU:\Software\Microsoft\office\{0}\{1}\security","HKCU:\Software\Microsoft\office\{0}\{1}\security\*\","HKCU:\Software\Policies\Microsoft\office\{0}\{1}\security\","HKCU:\Software\Policies\Microsoft\office\{0}\{1}\security\*\")
    foreach ($product in $SettingAppliesTo.Values) { 
        $propertyvalue = $null
        #Loop through possible registry paths, overwriting local settings with group policy settings where both exist
        foreach($OfficeRegistryPath in $OfficeRegistryPaths){
            $formattedpath = ($OfficeRegistryPath -f $versionnumber, $product)
            $newvalue = (Get-ItemProperty -Path $formattedpath -Name $RegistryKey -ErrorAction SilentlyContinue) | select-object -expandproperty $RegistryKey -erroraction silentlycontinue
            if (-Not ([string]::IsNullOrEmpty($newvalue))) { $propertyvalue = $newvalue }
        }
        if (([string]::IsNullOrEmpty($propertyvalue))) { $propertyvalue = 0 } #0 = not configured
        if (-not $keycheckvalues.ContainsKey($product)) { $keycheckvalues.Add($product, $propertyvalue) }
    }
    return $keycheckvalues
}

<#
.SYNOPSIS
Finds Office exe files installed in Program Files

.DESCRIPTION
Checks the Micrososft Office directory in the Program Files path for installed copies of Office. Checks both x86 and x64.

.PARAMETER SettingAppliesTo
The Office products that this check applies to.
#>

function Get-InstalledOfficeApplications($SettingAppliesTo){
    $installedofficeversions = @{}
    $OfficePath = "C:\Program Files*\Microsoft Office\*.exe" 
    $MatchCheck = ($SettingAppliesTo.Keys -join "$|") + "$"
    $filelist = (get-childitem -path $OfficePath -recurse -ErrorAction SilentlyContinue).Where( { $_.Name -match $MatchCheck -and $_.Length -gt 1 });

    foreach ($file in $filelist) {
        #get file version
        try { $ver = Get-VersionInfo($file) } catch { $ver = "" }

        #get installed office versions
        $key = ([System.Version]$ver).Major
        if (-not $installedofficeversions.ContainsKey($key)) { $installedofficeversions.Add($key, $SettingAppliesTo[$file.Name]) }
        else { $installedofficeversions[$key] += ";$($SettingAppliesTo[$file.name])" }
    }
    return $installedofficeversions
}

<#
.SYNOPSIS
Checks if Trusted Locations are allowed on the system

.DESCRIPTION
Checks if Trusted Locations are allowed on the system

.PARAMETER officeversion
The Office version to check
#>

function Get-TrustedLocationsAllowed($officeversion){
    $regkey = "HKCU:\SOFTWARE\Policies\Microsoft\Office\{0}.0\common\Security\trusted locations" -f $officeversion.Key
    
    if ((Test-Path -Path $regkey) -eq "True"){
        $result = (Get-ItemProperty -Path $regkey -Name "Allow User Locations" -ErrorAction SilentlyContinue)."Allow User Locations" 
        if ($result -eq 0){
            return $false
        }
        else{
            return $true
        }
    }
    return $true
}
<#
.SYNOPSIS
Writes a file to a specific folder and then deletes it

.DESCRIPTION
Writes a file to a specific folder and then deletes it. Used to check write permissions of Trusted Locations.

.PARAMETER Folder
The folder to write a file to.

#>

function Test-WriteFileIntoFolder{
    Param
    (
        [Parameter(Mandatory = $true)]
        [string]$Folder
    )
    $success = $true
    $outfile = "$Folder\Test-file-written-by-E8MVT.txt"
    Try { 
        [io.file]::OpenWrite($outfile).close() 
        Remove-Item $outfile
    }
    Catch { 
        $success = $false
    }
    return $success
}

<#
.SYNOPSIS
Retrieves version information of a file.

.DESCRIPTION
Retrieves version information of a file.

.PARAMETER file
The file to check.

#>

function Get-VersionInfo($file){
    $ver = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($file.FullName).ProductVersion.ToString().Replace(",", ".")
    return $ver
}

<#
.SYNOPSIS
Checks if any Office exe files are found in Program Files.

.DESCRIPTION
Checks if any Office exe files are found in Program Files.
#>

function Get-OfficeInstalled(){
    $AppPath = "C:\Program Files*\Microsoft Office"
    $AppMatches = "^((?!Updates).)*(Excel.exe$|WinWord.exe$|Msaccess.exe$|Outlook.exe$|PowerPnt.exe$|OneNote.exe$)"
    $results = (Get-Detail -Path $AppPath -MatchCheck $AppMatches)
    if ($results) {
        return $true
    }
    return $false
}

<#
.SYNOPSIS
Opens Office in the background and opens a test document.

.DESCRIPTION
This function will use COM objects to open Microsoft Office applications silenty in the background. Provided test documents
are opened and any macros are executed. The results of these macros tests will determine if the success or failure message is
returned.

.PARAMETER SettingAppliesTo
The Office applications to check for

.PARAMETER Remediation
Remediation advice to provide if the test fails.

.PARAMETER FailureMessage
The failure message to provide if the test fails.

.PARAMETER SuccessMessage
The success message to provide if the test passes.

.PARAMETER DocumentPath
The location of the document to test.
#>

function Test-SimulateOfficeDocument{
    Param
    (
        [Parameter(Mandatory = $true)]
        [hashtable]$SettingAppliesTo,
        [Parameter(Mandatory = $true)]
        [string]$Remediation,
        [Parameter(Mandatory = $true)]
        [string]$FailureMessage,
        [Parameter(Mandatory = $true)]
        [string]$SuccessMessage,
        [Parameter(Mandatory = $true)]
        [string]$DocumentPath
    )
       
    #establish core variables
    $failedsteps = 0 #defaults to zero, so if you don't indicate anything failed, the test will be regarded as successful
    $messages = [System.Collections.ArrayList]@()
    $completemessage = ""
    $customlocation = $false
    $DocumentName = Split-Path $DocumentPath -leaf

    if($DocumentPath.StartsWith($Global:TrustedLocation) -eq $false){
        if(Test-Path $Global:TrustedLocation){
            $DocumentPath = Copy-Item $DocumentPath -Destination $Global:TrustedLocation -PassThru
            $customlocation = $true
        }
        
    }
    $TestDoc = Get-ChildItem $DocumentPath -ErrorAction SilentlyContinue
    if(-not $TestDoc)
    {
        $messages.Add(@{"MessageType" = "FAILED_ERROR"; "Message" = "The provided file ($DocumentPath) was not valid for testing." }) | out-null
        return $failedsteps, $messages;
    }

    #Determine installed versions, based on actual executables in Program Files
    $installedofficeversions = Get-InstalledOfficeApplications $SettingAppliesTo

    #no office installed, return here to save time, error catching
    if ($installedofficeversions.Count -eq 0) {
        $messages.Add(@{"MessageType" = "SUCCESS"; "Message" = "There are no installed versions of Microsoft Office detected on this system." }) | out-null
        return $failedsteps, $messages
    }

    $completemessage+= "Test document: $($TestDoc.Name)" 

    #Force the file to be from the internet by setting the zone identifier for internet test files
    if($DocumentPath -match "Originates from the Internet")
    {
        set-content -Path "$($DocumentPath)" -Stream Zone.Identifier -Value "[ZoneTransfer]`r`nZoneId=3"
        $completemessage+= " (From the Internet) - " 
    } 
    else {
        $completemessage+= " - " 
    }

    #if it's the OLE files, dangerously remove all of the temp files...
    if($DocumentPath -match "OLE Object") {
        Remove-Item "$($env:LOCALAPPDATA)\Temp\notepad*.js" -Force -ErrorAction SilentlyContinue
    }

    #Check file extension
    switch ($TestDoc.Extension)
    {
        ".docm" { 
            $job = Start-Job -argumentlist ($DocumentPath) -ScriptBlock {
                $com_app = New-Object -ComObject Word.Application
                $document = $com_app.Documents.Open($args[0])
                $com_app.Run("Document_Open")
                $document.Close()
                Start-Sleep -Seconds 5
                $com_app.Quit() | out-null
                [System.Runtime.Interopservices.Marshal]::ReleaseComObject($com_app) | out-null
                Remove-Variable com_app -ErrorAction SilentlyContinue | out-null
            }
        }
        ".xlsm" { 
            $job = Start-Job -argumentlist ($DocumentPath) -ScriptBlock {
                $com_app = New-Object -ComObject Excel.Application
                $document = $com_app.Workbooks.Open($args[0])
                $com_app.Run("Auto_Open")
                $document.Close()
                Start-Sleep -Seconds 5
                $com_app.Quit() | out-null
                [System.Runtime.Interopservices.Marshal]::ReleaseComObject($com_app) | out-null
                Remove-Variable com_app -ErrorAction SilentlyContinue | out-null
            }
        }
        ".accdb" { 
            $job = Start-Job -argumentlist ($DocumentPath) -ScriptBlock {
                $com_app = New-Object -ComObject Access.Application
                $com_app.OpenCurrentDatabase($args[0])
                Start-Sleep -Seconds 3
		        $com_app.CloseCurrentDatabase()
				Start-Sleep -Seconds 5
                $com_app.Quit() | out-null
                [System.Runtime.Interopservices.Marshal]::ReleaseComObject($com_app) | out-null
                Remove-Variable com_app -ErrorAction SilentlyContinue | out-null
            }
        }
        default {
            $messages.Add(@{"MessageType" = "FAILED_ERROR"; "Message" = "The provided file ($DocumentPath) was not valid for testing." }) | out-null
            return $failedsteps, $messages;
        }
    }

    #run job to catch GUI messages
    #$completemessage+= "Starting GUI scan loop"
    [system.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") | Out-Null
    $i = 1
    do {
        $wshell = New-Object -ComObject wscript.shell;
        if ($wshell.AppActivate("Microsoft Word Security Notice")) #handle word disable macros prompt
        {
            #$completemessage+= "Detected Macro prompt, accepting..." 
            #Write-Host "Detected Macro prompt, accepting..." 
            [System.Windows.Forms.SendKeys]::SendWait("{Enter}")
        }
        elseif ($wshell.AppActivate("Open Package Contents - Security Warning")) #Handle OLE object prompt
        {
            #$completemessage+= "Detected OLE Failed Prompt..." 
            #switch from "cancel" to "open"
            [System.Windows.Forms.SendKeys]::SendWait("{Tab}")
            [System.Windows.Forms.SendKeys]::SendWait("{Tab}")
            [System.Windows.Forms.SendKeys]::SendWait("{Tab}")
            [System.Windows.Forms.SendKeys]::SendWait("{Enter}")
            Start-Sleep -milliseconds 500 #try to stop rekeying issue
        }
        elseif ($wshell.AppActivate("$($env:LOCALAPPDATA)\Temp\notepad.js")) #Handle OLE object prompt
        {
            #$completemessage+= "Detected OLE object not found prompt..." 
            [System.Windows.Forms.SendKeys]::SendWait("{Enter}")
            Write-Output "Failed..." | Out-File "$($env:TEMP)\$DocumentName.FAILEDTEST"
        }
        #no wildcard matching, so a few extras to make sure it picks it up...
        elseif ($wshell.AppActivate("$($env:LOCALAPPDATA)\Temp\notepad (1).js")) #Handle OLE object prompt
        {
            #$completemessage+= "Detected OLE object not found prompt..." 
            [System.Windows.Forms.SendKeys]::SendWait("{Enter}")
            Write-Output "Failed..." | Out-File "$($env:TEMP)\$DocumentName.FAILEDTEST"
        }
        elseif ($wshell.AppActivate("$($env:LOCALAPPDATA)\Temp\notepad (2).js")) #Handle OLE object prompt
        {
            #$completemessage+= "Detected OLE object not found prompt..." 
            [System.Windows.Forms.SendKeys]::SendWait("{Enter}")
            Write-Output "Failed..." | Out-File "$($env:TEMP)\$DocumentName.FAILEDTEST"
        }
        elseif ($wshell.AppActivate("$($env:LOCALAPPDATA)\Temp\notepad (3).js")) #Handle OLE object prompt
        {
            #$completemessage+= "Detected OLE object not found prompt..." 
            [System.Windows.Forms.SendKeys]::SendWait("{Enter}")
            Write-Output "Failed..." | Out-File "$($env:TEMP)\$DocumentName.FAILEDTEST"
        }
        elseif ($wshell.AppActivate("$($env:LOCALAPPDATA)\Temp\notepad (4).js")) #Handle OLE object prompt
        {
            #$completemessage+= "Detected OLE object not found prompt..." 
            [System.Windows.Forms.SendKeys]::SendWait("{Enter}")
            Write-Output "Failed..." | Out-File "$($env:TEMP)\$DocumentName.FAILEDTEST"
        }
        Start-Sleep -milliseconds 500
        $i+= 500
    }
    While ($i -lt 7001)

    #handle results
    try {
        if(Test-Path "$($env:TEMP)\$DocumentName.MACROTEST*")
        {
            $completemessage+= "executed."
            $failedsteps++;
            Remove-Item "$($env:TEMP)\$DocumentName.MACROTEST*" -Force
        }
        elseif (Test-Path "$($env:TEMP)\$DocumentName.FAILEDTEST*") {
            $completemessage+= "was blocked."
            Remove-Item "$($env:TEMP)\$DocumentName.FAILEDTEST*" -Force
        }
        else {
            $completemessage+= "did not execute."   
        }
    }
    catch {
        $completemessage+= "test failed with an error."
    }
    finally {
        #Clean up after finishing...
        Stop-Job -Job $job
        Remove-Job -Job $job
        Stop-Process -Name "WINWORD" -ErrorAction SilentlyContinue
        Stop-Process -Name "excel" -ErrorAction SilentlyContinue
        Stop-Process -Name "msaccess" -ErrorAction SilentlyContinue
        #construct return data
        if ($failedsteps -gt 0) {
            $messages.Add(@{"MessageType" = "FAILED"; "Message" = ("Invalid configuration: {0}" -f $completemessage) }) | out-null
            $messages.Add(@{"MessageType" = "FAILED"; "Message" = $FailureMessage }) | out-null
            $messages.Add(@{"MessageType" = "REMEDIATION"; "Message" = $Remediation }) | out-null
        }
        else {
            $messages.Add(@{"MessageType" = "SUCCESS"; "Message" = ("Mature configuration: {0}" -f $completemessage) }) | out-null
            $messages.Add(@{"MessageType" = "SUCCESS"; "Message" = $SuccessMessage }) | out-null
        }
        if($customlocation){
            Remove-Item $DocumentPath -Force
        }
    }

    return $failedsteps, $messages
}

#Package date: 2022-11-23; Build Version: 0e33c88
#Requires -Version 3.0


# SIG # Begin signature block
# MIIocQYJKoZIhvcNAQcCoIIoYjCCKF4CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCnUMObvGv7/lZn
# mNO8hj1JcZZs5yhzVO+tiQAa96JQcaCCIXQwggWNMIIEdaADAgECAhAOmxiO+dAt
# 5+/bUOIIQBhaMA0GCSqGSIb3DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNV
# BAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBa
# Fw0zMTExMDkyMzU5NTlaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lD
# ZXJ0IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoC
# ggIBAL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3E
# MB/zG6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKy
# unWZanMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsF
# xl7sWxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU1
# 5zHL2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJB
# MtfbBHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObUR
# WBf3JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6
# nj3cAORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxB
# YKqxYxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5S
# UUd0viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+x
# q4aLT8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIB
# NjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwP
# TzAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMC
# AYYweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdp
# Y2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0
# aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENB
# LmNybDARBgNVHSAECjAIMAYGBFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0Nc
# Vec4X6CjdBs9thbX979XB72arKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnov
# Lbc47/T/gLn4offyct4kvFIDyE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65Zy
# oUi0mcudT6cGAxN3J0TU53/oWajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFW
# juyk1T3osdz9HNj0d1pcVIxv76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPF
# mCLBsln1VWvPJ6tsds5vIy30fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9z
# twGpn1eqXijiuZQwggauMIIElqADAgECAhAHNje3JFR82Ees/ShmKl5bMA0GCSqG
# SIb3DQEBCwUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMx
# GTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRy
# dXN0ZWQgUm9vdCBHNDAeFw0yMjAzMjMwMDAwMDBaFw0zNzAzMjIyMzU5NTlaMGMx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMy
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcg
# Q0EwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDGhjUGSbPBPXJJUVXH
# JQPE8pE3qZdRodbSg9GeTKJtoLDMg/la9hGhRBVCX6SI82j6ffOciQt/nR+eDzMf
# UBMLJnOWbfhXqAJ9/UO0hNoR8XOxs+4rgISKIhjf69o9xBd/qxkrPkLcZ47qUT3w
# 1lbU5ygt69OxtXXnHwZljZQp09nsad/ZkIdGAHvbREGJ3HxqV3rwN3mfXazL6IRk
# tFLydkf3YYMZ3V+0VAshaG43IbtArF+y3kp9zvU5EmfvDqVjbOSmxR3NNg1c1eYb
# qMFkdECnwHLFuk4fsbVYTXn+149zk6wsOeKlSNbwsDETqVcplicu9Yemj052FVUm
# cJgmf6AaRyBD40NjgHt1biclkJg6OBGz9vae5jtb7IHeIhTZgirHkr+g3uM+onP6
# 5x9abJTyUpURK1h0QCirc0PO30qhHGs4xSnzyqqWc0Jon7ZGs506o9UD4L/wojzK
# QtwYSH8UNM/STKvvmz3+DrhkKvp1KCRB7UK/BZxmSVJQ9FHzNklNiyDSLFc1eSuo
# 80VgvCONWPfcYd6T/jnA+bIwpUzX6ZhKWD7TA4j+s4/TXkt2ElGTyYwMO1uKIqjB
# Jgj5FBASA31fI7tk42PgpuE+9sJ0sj8eCXbsq11GdeJgo1gJASgADoRU7s7pXche
# MBK9Rp6103a50g5rmQzSM7TNsQIDAQABo4IBXTCCAVkwEgYDVR0TAQH/BAgwBgEB
# /wIBADAdBgNVHQ4EFgQUuhbZbU2FL3MpdpovdYxqII+eyG8wHwYDVR0jBBgwFoAU
# 7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoG
# CCsGAQUFBwMIMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0cDovL29j
# c3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0cy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8EPDA6MDig
# NqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9v
# dEc0LmNybDAgBgNVHSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEwDQYJKoZI
# hvcNAQELBQADggIBAH1ZjsCTtm+YqUQiAX5m1tghQuGwGC4QTRPPMFPOvxj7x1Bd
# 4ksp+3CKDaopafxpwc8dB+k+YMjYC+VcW9dth/qEICU0MWfNthKWb8RQTGIdDAiC
# qBa9qVbPFXONASIlzpVpP0d3+3J0FNf/q0+KLHqrhc1DX+1gtqpPkWaeLJ7giqzl
# /Yy8ZCaHbJK9nXzQcAp876i8dU+6WvepELJd6f8oVInw1YpxdmXazPByoyP6wCeC
# RK6ZJxurJB4mwbfeKuv2nrF5mYGjVoarCkXJ38SNoOeY+/umnXKvxMfBwWpx2cYT
# gAnEtp/Nh4cku0+jSbl3ZpHxcpzpSwJSpzd+k1OsOx0ISQ+UzTl63f8lY5knLD0/
# a6fxZsNBzU+2QJshIUDQtxMkzdwdeDrknq3lNHGS1yZr5Dhzq6YBT70/O3itTK37
# xJV77QpfMzmHQXh6OOmc4d0j/R0o08f56PGYX/sr2H7yRp11LB4nLCbbbxV7HhmL
# NriT1ObyF5lZynDwN7+YAN8gFk8n+2BnFqFmut1VwDophrCYoCvtlUG3OtUVmDG0
# YgkPCr2B2RP+v6TR81fZvAT6gt4y3wSJ8ADNXcL50CN/AAvkdgIm2fBldkKmKYcJ
# RyvmfxqkhQ/8mJb2VVQrH4D6wPIOK+XW+6kvRBVK5xMOHds3OBqhK/bt1nz8MIIG
# sDCCBJigAwIBAgIQCK1AsmDSnEyfXs2pvZOu2TANBgkqhkiG9w0BAQwFADBiMQsw
# CQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cu
# ZGlnaWNlcnQuY29tMSEwHwYDVQQDExhEaWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQw
# HhcNMjEwNDI5MDAwMDAwWhcNMzYwNDI4MjM1OTU5WjBpMQswCQYDVQQGEwJVUzEX
# MBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNVBAMTOERpZ2lDZXJ0IFRydXN0
# ZWQgRzQgQ29kZSBTaWduaW5nIFJTQTQwOTYgU0hBMzg0IDIwMjEgQ0ExMIICIjAN
# BgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA1bQvQtAorXi3XdU5WRuxiEL1M4zr
# PYGXcMW7xIUmMJ+kjmjYXPXrNCQH4UtP03hD9BfXHtr50tVnGlJPDqFX/IiZwZHM
# gQM+TXAkZLON4gh9NH1MgFcSa0OamfLFOx/y78tHWhOmTLMBICXzENOLsvsI8Irg
# nQnAZaf6mIBJNYc9URnokCF4RS6hnyzhGMIazMXuk0lwQjKP+8bqHPNlaJGiTUyC
# EUhSaN4QvRRXXegYE2XFf7JPhSxIpFaENdb5LpyqABXRN/4aBpTCfMjqGzLmysL0
# p6MDDnSlrzm2q2AS4+jWufcx4dyt5Big2MEjR0ezoQ9uo6ttmAaDG7dqZy3SvUQa
# khCBj7A7CdfHmzJawv9qYFSLScGT7eG0XOBv6yb5jNWy+TgQ5urOkfW+0/tvk2E0
# XLyTRSiDNipmKF+wc86LJiUGsoPUXPYVGUztYuBeM/Lo6OwKp7ADK5GyNnm+960I
# HnWmZcy740hQ83eRGv7bUKJGyGFYmPV8AhY8gyitOYbs1LcNU9D4R+Z1MI3sMJN2
# FKZbS110YU0/EpF23r9Yy3IQKUHw1cVtJnZoEUETWJrcJisB9IlNWdt4z4FKPkBH
# X8mBUHOFECMhWWCKZFTBzCEa6DgZfGYczXg4RTCZT/9jT0y7qg0IU0F8WD1Hs/q2
# 7IwyCQLMbDwMVhECAwEAAaOCAVkwggFVMBIGA1UdEwEB/wQIMAYBAf8CAQAwHQYD
# VR0OBBYEFGg34Ou2O/hfEYb7/mF7CIhl9E5CMB8GA1UdIwQYMBaAFOzX44LScV1k
# TN8uZz/nupiuHA9PMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAKBggrBgEFBQcD
# AzB3BggrBgEFBQcBAQRrMGkwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2lj
# ZXJ0LmNvbTBBBggrBgEFBQcwAoY1aHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29t
# L0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5jcnQwQwYDVR0fBDwwOjA4oDagNIYyaHR0
# cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5jcmww
# HAYDVR0gBBUwEzAHBgVngQwBAzAIBgZngQwBBAEwDQYJKoZIhvcNAQEMBQADggIB
# ADojRD2NCHbuj7w6mdNW4AIapfhINPMstuZ0ZveUcrEAyq9sMCcTEp6QRJ9L/Z6j
# fCbVN7w6XUhtldU/SfQnuxaBRVD9nL22heB2fjdxyyL3WqqQz/WTauPrINHVUHmI
# moqKwba9oUgYftzYgBoRGRjNYZmBVvbJ43bnxOQbX0P4PpT/djk9ntSZz0rdKOtf
# JqGVWEjVGv7XJz/9kNF2ht0csGBc8w2o7uCJob054ThO2m67Np375SFTWsPK6Wrx
# oj7bQ7gzyE84FJKZ9d3OVG3ZXQIUH0AzfAPilbLCIXVzUstG2MQ0HKKlS43Nb3Y3
# LIU/Gs4m6Ri+kAewQ3+ViCCCcPDMyu/9KTVcH4k4Vfc3iosJocsL6TEa/y4ZXDlx
# 4b6cpwoG1iZnt5LmTl/eeqxJzy6kdJKt2zyknIYf48FWGysj/4+16oh7cGvmoLr9
# Oj9FpsToFpFSi0HASIRLlk2rREDjjfAVKM7t8RhWByovEMQMCGQ8M4+uKIw8y4+I
# Cw2/O/TOHnuO77Xry7fwdxPm5yg/rBKupS8ibEH5glwVZsxsDsrFhsP2JjMMB0ug
# 0wcCampAMEhLNKhRILutG4UI4lkNbcoFUCvqShyepf2gpx8GdOfy1lKQ/a+FSCH5
# Vzu0nAPthkX0tGFuv2jiJmCG6sivqf6UHedjGzqGVnhOMIIGwDCCBKigAwIBAgIQ
# DE1pckuU+jwqSj0pB4A9WjANBgkqhkiG9w0BAQsFADBjMQswCQYDVQQGEwJVUzEX
# MBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNVBAMTMkRpZ2lDZXJ0IFRydXN0
# ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1waW5nIENBMB4XDTIyMDkyMTAw
# MDAwMFoXDTMzMTEyMTIzNTk1OVowRjELMAkGA1UEBhMCVVMxETAPBgNVBAoTCERp
# Z2lDZXJ0MSQwIgYDVQQDExtEaWdpQ2VydCBUaW1lc3RhbXAgMjAyMiAtIDIwggIi
# MA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDP7KUmOsap8mu7jcENmtuh6BSF
# dDMaJqzQHFUeHjZtvJJVDGH0nQl3PRWWCC9rZKT9BoMW15GSOBwxApb7crGXOlWv
# M+xhiummKNuQY1y9iVPgOi2Mh0KuJqTku3h4uXoW4VbGwLpkU7sqFudQSLuIaQyI
# xvG+4C99O7HKU41Agx7ny3JJKB5MgB6FVueF7fJhvKo6B332q27lZt3iXPUv7Y3U
# TZWEaOOAy2p50dIQkUYp6z4m8rSMzUy5Zsi7qlA4DeWMlF0ZWr/1e0BubxaompyV
# R4aFeT4MXmaMGgokvpyq0py2909ueMQoP6McD1AGN7oI2TWmtR7aeFgdOej4TJEQ
# ln5N4d3CraV++C0bH+wrRhijGfY59/XBT3EuiQMRoku7mL/6T+R7Nu8GRORV/zbq
# 5Xwx5/PCUsTmFntafqUlc9vAapkhLWPlWfVNL5AfJ7fSqxTlOGaHUQhr+1NDOdBk
# +lbP4PQK5hRtZHi7mP2Uw3Mh8y/CLiDXgazT8QfU4b3ZXUtuMZQpi+ZBpGWUwFjl
# 5S4pkKa3YWT62SBsGFFguqaBDwklU/G/O+mrBw5qBzliGcnWhX8T2Y15z2LF7OF7
# ucxnEweawXjtxojIsG4yeccLWYONxu71LHx7jstkifGxxLjnU15fVdJ9GSlZA076
# XepFcxyEftfO4tQ6dwIDAQABo4IBizCCAYcwDgYDVR0PAQH/BAQDAgeAMAwGA1Ud
# EwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwIAYDVR0gBBkwFzAIBgZn
# gQwBBAIwCwYJYIZIAYb9bAcBMB8GA1UdIwQYMBaAFLoW2W1NhS9zKXaaL3WMaiCP
# nshvMB0GA1UdDgQWBBRiit7QYfyPMRTtlwvNPSqUFN9SnDBaBgNVHR8EUzBRME+g
# TaBLhklodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRS
# U0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0EuY3JsMIGQBggrBgEFBQcBAQSBgzCB
# gDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMFgGCCsGAQUF
# BzAChkxodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVk
# RzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0EuY3J0MA0GCSqGSIb3DQEBCwUA
# A4ICAQBVqioa80bzeFc3MPx140/WhSPx/PmVOZsl5vdyipjDd9Rk/BX7NsJJUSx4
# iGNVCUY5APxp1MqbKfujP8DJAJsTHbCYidx48s18hc1Tna9i4mFmoxQqRYdKmEIr
# UPwbtZ4IMAn65C3XCYl5+QnmiM59G7hqopvBU2AJ6KO4ndetHxy47JhB8PYOgPvk
# /9+dEKfrALpfSo8aOlK06r8JSRU1NlmaD1TSsht/fl4JrXZUinRtytIFZyt26/+Y
# siaVOBmIRBTlClmia+ciPkQh0j8cwJvtfEiy2JIMkU88ZpSvXQJT657inuTTH4YB
# ZJwAwuladHUNPeF5iL8cAZfJGSOA1zZaX5YWsWMMxkZAO85dNdRZPkOaGK7DycvD
# +5sTX2q1x+DzBcNZ3ydiK95ByVO5/zQQZ/YmMph7/lxClIGUgp2sCovGSxVK05iQ
# RWAzgOAj3vgDpPZFR+XOuANCR+hBNnF3rf2i6Jd0Ti7aHh2MWsgemtXC8MYiqE+b
# vdgcmlHEL5r2X6cnl7qWLoVXwGDneFZ/au/ClZpLEQLIgpzJGgV8unG1TnqZbPTo
# ntRamMifv427GFxD9dAq6OJi7ngE273R+1sKqHB+8JeEeOMIA11HLGOoJTiXAdI/
# Otrl5fbmm9x+LMz/F0xNAKLY1gEOuIvu5uByVYksJxlh9ncBjDCCB7UwggWdoAMC
# AQICEAcinfAkAmWmAghlZhLlTsUwDQYJKoZIhvcNAQELBQAwaTELMAkGA1UEBhMC
# VVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMUEwPwYDVQQDEzhEaWdpQ2VydCBU
# cnVzdGVkIEc0IENvZGUgU2lnbmluZyBSU0E0MDk2IFNIQTM4NCAyMDIxIENBMTAe
# Fw0yMjEwMDMwMDAwMDBaFw0yMzAzMTcyMzU5NTlaMIG5MQswCQYDVQQGEwJBVTEa
# MBgGA1UECBMRV2VzdGVybiBBdXN0cmFsaWExETAPBgNVBAcTCEtvamFyZW5hMScw
# JQYDVQQKEx5BdXN0cmFsaWFuIFNpZ25hbHMgRGlyZWN0b3JhdGUxKTAnBgNVBAsT
# IEF1c3RyYWxpYW4gQ3liZXIgU2VjdXJpdHkgQ2VudHJlMScwJQYDVQQDEx5BdXN0
# cmFsaWFuIFNpZ25hbHMgRGlyZWN0b3JhdGUwggIiMA0GCSqGSIb3DQEBAQUAA4IC
# DwAwggIKAoICAQCmlqO4LNn+srEfOuFQvPfikoRuwUjsiZ5nn4tYcjJHDWzHjtPs
# 77qyX69c9lzKI/5gQXAAbb+Ps5Q1ukd0LOHtbTo909jKoAN/0JFtTWnQiZuypmEk
# oAVKFCEAtn1o7ymCoZbajqTrlAXDRX3B04CaO6PLZKgsWgzgXfQvsjU/gsR7fKF4
# lKfICKTz5xaZdjxEch9TCqK6pdiR/F80JP7IYQRlCMGFNNmXMJ+s4cNVy/xrlIWE
# o+aj5Fbg607YnWhlcF12YX53znDh5w2oMb/an31uTl7IBF5fe6Hf+mwv/ejKFnTD
# ncbJkA1yUyG1aY9IAP5pg29TH+1hiH1Zs4Ai1qQcU57+fL4nALfw5p1twPPQQNb1
# Ge4fptfZ5yXhdPcmdx5TXWa+8mzm4mRkZX4opVVQgopZmsbzfO9VbpMG53JlsonT
# AtzcBbx7cy48ZmM8j9QE5ovvmRhRKcqYqTGrGuXrZiebldzo7RAjhSH4cOBxh7qB
# 23wGX4dhroME/beznIJArFyIn9lxwM1/8mHjE+p8MkXXm4WkeR8f2SdYbbAfaRj+
# ec+tADLrggdA5s35mCSsgV+rc12RcnrN3RhhAfZp/IkhHs/0jNyVG3TSeRqWfquY
# 8xwArn4UU6oH9N7TlwuUA7dytbhIHqfdnz8X5DSYWfM6v4KEPmXSGZ0Y2QIDAQAB
# o4ICBjCCAgIwHwYDVR0jBBgwFoAUaDfg67Y7+F8Rhvv+YXsIiGX0TkIwHQYDVR0O
# BBYEFACrXQ4MH1M2YQoT1K5ekRjuhwDCMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUE
# DDAKBggrBgEFBQcDAzCBtQYDVR0fBIGtMIGqMFOgUaBPhk1odHRwOi8vY3JsMy5k
# aWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmluZ1JTQTQwOTZT
# SEEzODQyMDIxQ0ExLmNybDBToFGgT4ZNaHR0cDovL2NybDQuZGlnaWNlcnQuY29t
# L0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hBMzg0MjAyMUNB
# MS5jcmwwPgYDVR0gBDcwNTAzBgZngQwBBAEwKTAnBggrBgEFBQcCARYbaHR0cDov
# L3d3dy5kaWdpY2VydC5jb20vQ1BTMIGUBggrBgEFBQcBAQSBhzCBhDAkBggrBgEF
# BQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMFwGCCsGAQUFBzAChlBodHRw
# Oi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRDb2RlU2ln
# bmluZ1JTQTQwOTZTSEEzODQyMDIxQ0ExLmNydDAMBgNVHRMBAf8EAjAAMA0GCSqG
# SIb3DQEBCwUAA4ICAQDFCUQKXHj1185Qfsu8hnICbW0rjDQR2HVvZmO0TiUJOKQx
# N5OD9zFN0mW+ZNQkOKFtabiabRViozMN6VciWKMHCnhnUruzVWiu3QaxlOSB1f8s
# zNQMgS/3dnQOYqzdCDPn7TxIdJBy4YI2Lby7vUy/8jVFVbpY/Qb2AKI29offJ6sY
# yuz7WSnkOw8DFw6E9j4ODObvG3dlXISxW2HjaS2DnVx7hic27eLjzWyutrD7+USE
# av8OtWiVl9tdwi8Up/DwzABQzhmZGn8uN3ILNWFINs2MTKD4N/A8kJEIWF8535nB
# 6RqKsvtbOb7uL/yaw3cuXdQ+SCGS6ObddqbpKs5DCbhDizjFymKF4043PPBPW7S/
# n9WJgClI1eOMvYcOIaqbRVEslX2G2nlT/XcQRp2tEbw96I6h2BCVEtWFECx/Azyw
# 2rTNPc8ZnopVA4UGnohIrH5hXceXLC+ub6oJdC2GjbVyI32mkgj6NrSanRvxXOad
# WsSee/gTh1DFuRsxkg+OOYQecToiOY1JcMGmr7SvTFw97GhnB6fKttYP0sPS6NrW
# bbNSrMTxK+jabI0jaQfmnQKY6mOU9SWYNkXxLmgKVJSGcz3Ec5qnqzw2rw8DiYho
# XZdKl+t+PBqzrsqYbSNpL68r9r29dOhXId8FqGIoW+L5d8UcSp/MyTRymPiQaDGC
# BlMwggZPAgEBMH0waTELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJ
# bmMuMUEwPwYDVQQDEzhEaWdpQ2VydCBUcnVzdGVkIEc0IENvZGUgU2lnbmluZyBS
# U0E0MDk2IFNIQTM4NCAyMDIxIENBMQIQByKd8CQCZaYCCGVmEuVOxTANBglghkgB
# ZQMEAgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJ
# AzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8G
# CSqGSIb3DQEJBDEiBCCyLN+bTvM3mG2lYgHY2WBQCmDpC6LQSVPsj0mgcGI+JTAN
# BgkqhkiG9w0BAQEFAASCAgBIaPHn2IbosZcY9z0V25PX2j5PaW2RjGDjholoBbLt
# u0IEiO88uy1KtDWouHoktC7ywxeM/IbV0nyiYtEpAv7bnSpOVyDLYF2k+vaKyP9e
# WT+5sjZXZ611slSfNocZ+hkA4MYixUlNzN/JyOBV8MbhqmUdaW28LgsRKVXIe88L
# aoByAo/wHJfpIYTmJfsARUXtBZbwGDj92iZGqzxI8mRMC5uWuOnXIlfTen8mkDSS
# AawMKIZxiD6u0ImJpDh27rCv4X1t5V3jidOzpiuQB6s2KxWIBOvyVa9hwBEc0s/u
# 0+9JbfUQTRleVlp72fcKxMhFb0dVRNaTMQx87gFMLZIvuTDQeWU72+pCS4WjkA7T
# Rifl1A+y9kKioIOSpKnpW6lizPdPwc+gNLnO6CcfDLKD4p7SlFIo7o827vmsgxOl
# D1BbGDkq1KXnKaeEmt3Ww7tVXWgN1gwKl3OqL/nG0MKz+C5wykHgem2Ep8GFnYHW
# HwAMb1rYHKXLPH6PNEvbVyJL0BNFLqBtieJk5+Pnh4Kn7FX+yJIoh2kW9noDi5+k
# r6Jv+ZgvlcY8wvNEzWb6RBrywH62pk/gzY17up2odzhf74xYSbNnjI6e1YK9SNRb
# HGUD3mdpUGLuiqRv8lc2HLW7RHLZKlGZfu6OUc1EAHbM1z6dNBQvoIcuHfzjASrV
# ZaGCAyAwggMcBgkqhkiG9w0BCQYxggMNMIIDCQIBATB3MGMxCzAJBgNVBAYTAlVT
# MRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMyRGlnaUNlcnQgVHJ1
# c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcgQ0ECEAxNaXJLlPo8
# Kko9KQeAPVowDQYJYIZIAWUDBAIBBQCgaTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcN
# AQcBMBwGCSqGSIb3DQEJBTEPFw0yMjExMjMwMzEwNTNaMC8GCSqGSIb3DQEJBDEi
# BCBUsqpZq4evL3MSew/1inlN75eHhiJoQCMike/ch1BDkzANBgkqhkiG9w0BAQEF
# AASCAgCHy6dikHpSNzcK+CXJtJppUkghuNlOYzZXrT5nwtdliYMkvNyxFcx32Y0u
# ZC+nMVR88B6JIqhfjVgy3o3l6MEF2tp47JDFPPC8+iRhaigNfLxAqwBZmHuwCy5q
# mpSveFBN45waDcd859FSRjZdUuJbcyhjzHwvxrELjlvZAaOZl8rhBdwrkqw12i69
# 8BoDRwpTDdJMeWeQGc645iSZvsV3d77TeI9caxKmyPyYi+gVwZGGmruvndFkY5O0
# eMZgzw594FD6tkbiIuF3iXuJB9PxTIwfkQvtNhetBYn3oGRapfbmpcsyy6rBs4ih
# 1WZB2FiNA/kCnnOEC+mEeEsGelue0NR8jFX6IvmsL9u6/LI+hNR8yZDWRg7Giblr
# dMDpG+9Zl5tjDGgvaZtQg139j2poxGpXtr+fNxiA7PtvNzni+gZxwJTx3QNmrsz2
# Otlh0x0GAGjd3v2NSGeH38atpQ43q4x3FvjVOY624dfuVnhrF8D3gCV8OyS2SjM+
# Xhc4b7M+1T1FREDBFO5FnoFEt0TZJ2FNW5hK1hmIlT9HKRu8rscIv5IVWnlOTTMK
# 1CWZngTLHL+nASMXUID/Y+vprOUh/De8ioqdu83pQ153Cr2STnDzYatJsOGdrjnk
# HhNuKeIDW2jnUzBC2B4909rFDrHTSOYhdqRDd8/T4nK+YxIOpw==
# SIG # End signature block
