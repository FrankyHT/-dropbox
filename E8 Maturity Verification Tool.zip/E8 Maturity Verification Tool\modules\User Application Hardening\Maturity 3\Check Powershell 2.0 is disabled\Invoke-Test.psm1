<#
.SYNOPSIS
This test checks whether Powershell 2.0 is disabled.

.DESCRIPTION
This is an E8MVT module, intended to assess one or more criteria of the Essential Eight Maturity Model.

.EXAMPLE
Invoke-Test -Path <location_of_this_module>

.PARAMETER path
The location of this module on disk. This is to allow the module to access any files located in its folder.

.INPUTS
None. You cannot pipe objects to this tool.

.OUTPUTS
This tool will return a PowerShell hashtable object. The hashtable contains three elements.
"failedsteps", an integer count of the number of failed steps in this test.
"failedthreshold", an integer showing the number of failed steps that indicates a failed test. Typically, this is zero.
[System.Collections.ArrayList] "messages", an array of hastables with the output messages. 
    These contain two fields:
        "MessageType", indicating the message type such as "SUCCESS" or "FAILED". "FAILED_ERROR" indicates an error occurred.
        "Message", with a detailed output message.

.LINK 
https://www.cyber.gov.au/acsc/view-all-content/publications/essential-eight-maturity-model
#>
function Invoke-Test ($path) { #$path is the actual location of this file, so you can use path relative file references
    $failedthreshold = 0 #default of 0, since that's where we are
    $failedsteps = 0 #defaults to zero, so if you don't indicate anything failed, the test will be regarded as successful
    $messages = [System.Collections.ArrayList]@()

    #perform tests
    try {
        #change to current module location, save previous location
        Push-Location $path

        #Begin Module Code#
        $regbase = "HKLM:\SOFTWARE\Microsoft"
        #windows powershell settings
        $pskey = Join-Path -Path $regbase -ChildPath PowerShell
        Get-ChildItem $PSKey -Recurse -Include PowerShellEngine | ForEach-Object {
            $version = $_.pspath | Get-ItemPropertyValue -name PowerShellVersion
            if($version -eq "2.0"){
                $messages.Add(@{"MessageType" = "FAILED"; "Message" = "PowerShell 2.0 was discovered in the registry." }) | Out-Null
                $failedsteps++;
            }
        }
        if ($failedsteps -eq 0){
            $messages.Add(@{"MessageType" = "SUCCESS"; "Message" = "Powershell 2.0 was not found." }) | Out-Null
        }
        else{
            $messages.Add(@{"MessageType" = "REMEDIATION"; "Message" = "Powershell 2.0 is deprecated and should be removed from the system." }) | Out-Null
        }
        #End Module Code#

    }
    catch {
        $messages.Add(@{"MessageType" = "FAILED_ERROR"; "Message" = "Some kind of exception occurred: $_" }) | Out-Null
        $failedsteps++;
    }

    finally {
        #"Finished"
        $testresult = @{
            failedsteps     = $failedsteps;
            failedthreshold = $failedthreshold;
            details         = $messages;
        }
        #return to previous location
        Pop-Location
    }
    #return the result
    return $testresult
}
#only export the actual test function, hide all others, in case you want to use them
Export-ModuleMember -Function Invoke-Test

#Package date: 2022-11-23; Build Version: 0e33c88
#Requires -Version 3.0


# SIG # Begin signature block
# MIIocQYJKoZIhvcNAQcCoIIoYjCCKF4CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDPDG0kQSMm9kd6
# rn6B6aGzrIuc9DTufvVlnfSCNJa7JqCCIXQwggWNMIIEdaADAgECAhAOmxiO+dAt
# 5+/bUOIIQBhaMA0GCSqGSIb3DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNV
# BAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBa
# Fw0zMTExMDkyMzU5NTlaMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2Vy
# dCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lD
# ZXJ0IFRydXN0ZWQgUm9vdCBHNDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoC
# ggIBAL/mkHNo3rvkXUo8MCIwaTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3E
# MB/zG6Q4FutWxpdtHauyefLKEdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKy
# unWZanMylNEQRBAu34LzB4TmdDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsF
# xl7sWxq868nPzaw0QF+xembud8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU1
# 5zHL2pNe3I6PgNq2kZhAkHnDeMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJB
# MtfbBHMqbpEBfCFM1LyuGwN1XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObUR
# WBf3JFxGj2T3wWmIdph2PVldQnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6
# nj3cAORFJYm2mkQZK37AlLTSYW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxB
# YKqxYxhElRp2Yn72gLD76GSmM9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5S
# UUd0viastkF13nqsX40/ybzTQRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+x
# q4aLT8LWRV+dIPyhHsXAj6KxfgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIB
# NjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwP
# TzAfBgNVHSMEGDAWgBRF66Kv9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMC
# AYYweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdp
# Y2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNv
# bS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0
# aHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENB
# LmNybDARBgNVHSAECjAIMAYGBFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0Nc
# Vec4X6CjdBs9thbX979XB72arKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnov
# Lbc47/T/gLn4offyct4kvFIDyE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65Zy
# oUi0mcudT6cGAxN3J0TU53/oWajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFW
# juyk1T3osdz9HNj0d1pcVIxv76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPF
# mCLBsln1VWvPJ6tsds5vIy30fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9z
# twGpn1eqXijiuZQwggauMIIElqADAgECAhAHNje3JFR82Ees/ShmKl5bMA0GCSqG
# SIb3DQEBCwUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMx
# GTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRy
# dXN0ZWQgUm9vdCBHNDAeFw0yMjAzMjMwMDAwMDBaFw0zNzAzMjIyMzU5NTlaMGMx
# CzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMy
# RGlnaUNlcnQgVHJ1c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcg
# Q0EwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDGhjUGSbPBPXJJUVXH
# JQPE8pE3qZdRodbSg9GeTKJtoLDMg/la9hGhRBVCX6SI82j6ffOciQt/nR+eDzMf
# UBMLJnOWbfhXqAJ9/UO0hNoR8XOxs+4rgISKIhjf69o9xBd/qxkrPkLcZ47qUT3w
# 1lbU5ygt69OxtXXnHwZljZQp09nsad/ZkIdGAHvbREGJ3HxqV3rwN3mfXazL6IRk
# tFLydkf3YYMZ3V+0VAshaG43IbtArF+y3kp9zvU5EmfvDqVjbOSmxR3NNg1c1eYb
# qMFkdECnwHLFuk4fsbVYTXn+149zk6wsOeKlSNbwsDETqVcplicu9Yemj052FVUm
# cJgmf6AaRyBD40NjgHt1biclkJg6OBGz9vae5jtb7IHeIhTZgirHkr+g3uM+onP6
# 5x9abJTyUpURK1h0QCirc0PO30qhHGs4xSnzyqqWc0Jon7ZGs506o9UD4L/wojzK
# QtwYSH8UNM/STKvvmz3+DrhkKvp1KCRB7UK/BZxmSVJQ9FHzNklNiyDSLFc1eSuo
# 80VgvCONWPfcYd6T/jnA+bIwpUzX6ZhKWD7TA4j+s4/TXkt2ElGTyYwMO1uKIqjB
# Jgj5FBASA31fI7tk42PgpuE+9sJ0sj8eCXbsq11GdeJgo1gJASgADoRU7s7pXche
# MBK9Rp6103a50g5rmQzSM7TNsQIDAQABo4IBXTCCAVkwEgYDVR0TAQH/BAgwBgEB
# /wIBADAdBgNVHQ4EFgQUuhbZbU2FL3MpdpovdYxqII+eyG8wHwYDVR0jBBgwFoAU
# 7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQMMAoG
# CCsGAQUFBwMIMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0cDovL29j
# c3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0cy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8EPDA6MDig
# NqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9v
# dEc0LmNybDAgBgNVHSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEwDQYJKoZI
# hvcNAQELBQADggIBAH1ZjsCTtm+YqUQiAX5m1tghQuGwGC4QTRPPMFPOvxj7x1Bd
# 4ksp+3CKDaopafxpwc8dB+k+YMjYC+VcW9dth/qEICU0MWfNthKWb8RQTGIdDAiC
# qBa9qVbPFXONASIlzpVpP0d3+3J0FNf/q0+KLHqrhc1DX+1gtqpPkWaeLJ7giqzl
# /Yy8ZCaHbJK9nXzQcAp876i8dU+6WvepELJd6f8oVInw1YpxdmXazPByoyP6wCeC
# RK6ZJxurJB4mwbfeKuv2nrF5mYGjVoarCkXJ38SNoOeY+/umnXKvxMfBwWpx2cYT
# gAnEtp/Nh4cku0+jSbl3ZpHxcpzpSwJSpzd+k1OsOx0ISQ+UzTl63f8lY5knLD0/
# a6fxZsNBzU+2QJshIUDQtxMkzdwdeDrknq3lNHGS1yZr5Dhzq6YBT70/O3itTK37
# xJV77QpfMzmHQXh6OOmc4d0j/R0o08f56PGYX/sr2H7yRp11LB4nLCbbbxV7HhmL
# NriT1ObyF5lZynDwN7+YAN8gFk8n+2BnFqFmut1VwDophrCYoCvtlUG3OtUVmDG0
# YgkPCr2B2RP+v6TR81fZvAT6gt4y3wSJ8ADNXcL50CN/AAvkdgIm2fBldkKmKYcJ
# RyvmfxqkhQ/8mJb2VVQrH4D6wPIOK+XW+6kvRBVK5xMOHds3OBqhK/bt1nz8MIIG
# sDCCBJigAwIBAgIQCK1AsmDSnEyfXs2pvZOu2TANBgkqhkiG9w0BAQwFADBiMQsw
# CQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cu
# ZGlnaWNlcnQuY29tMSEwHwYDVQQDExhEaWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQw
# HhcNMjEwNDI5MDAwMDAwWhcNMzYwNDI4MjM1OTU5WjBpMQswCQYDVQQGEwJVUzEX
# MBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNVBAMTOERpZ2lDZXJ0IFRydXN0
# ZWQgRzQgQ29kZSBTaWduaW5nIFJTQTQwOTYgU0hBMzg0IDIwMjEgQ0ExMIICIjAN
# BgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA1bQvQtAorXi3XdU5WRuxiEL1M4zr
# PYGXcMW7xIUmMJ+kjmjYXPXrNCQH4UtP03hD9BfXHtr50tVnGlJPDqFX/IiZwZHM
# gQM+TXAkZLON4gh9NH1MgFcSa0OamfLFOx/y78tHWhOmTLMBICXzENOLsvsI8Irg
# nQnAZaf6mIBJNYc9URnokCF4RS6hnyzhGMIazMXuk0lwQjKP+8bqHPNlaJGiTUyC
# EUhSaN4QvRRXXegYE2XFf7JPhSxIpFaENdb5LpyqABXRN/4aBpTCfMjqGzLmysL0
# p6MDDnSlrzm2q2AS4+jWufcx4dyt5Big2MEjR0ezoQ9uo6ttmAaDG7dqZy3SvUQa
# khCBj7A7CdfHmzJawv9qYFSLScGT7eG0XOBv6yb5jNWy+TgQ5urOkfW+0/tvk2E0
# XLyTRSiDNipmKF+wc86LJiUGsoPUXPYVGUztYuBeM/Lo6OwKp7ADK5GyNnm+960I
# HnWmZcy740hQ83eRGv7bUKJGyGFYmPV8AhY8gyitOYbs1LcNU9D4R+Z1MI3sMJN2
# FKZbS110YU0/EpF23r9Yy3IQKUHw1cVtJnZoEUETWJrcJisB9IlNWdt4z4FKPkBH
# X8mBUHOFECMhWWCKZFTBzCEa6DgZfGYczXg4RTCZT/9jT0y7qg0IU0F8WD1Hs/q2
# 7IwyCQLMbDwMVhECAwEAAaOCAVkwggFVMBIGA1UdEwEB/wQIMAYBAf8CAQAwHQYD
# VR0OBBYEFGg34Ou2O/hfEYb7/mF7CIhl9E5CMB8GA1UdIwQYMBaAFOzX44LScV1k
# TN8uZz/nupiuHA9PMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAKBggrBgEFBQcD
# AzB3BggrBgEFBQcBAQRrMGkwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2lj
# ZXJ0LmNvbTBBBggrBgEFBQcwAoY1aHR0cDovL2NhY2VydHMuZGlnaWNlcnQuY29t
# L0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5jcnQwQwYDVR0fBDwwOjA4oDagNIYyaHR0
# cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5jcmww
# HAYDVR0gBBUwEzAHBgVngQwBAzAIBgZngQwBBAEwDQYJKoZIhvcNAQEMBQADggIB
# ADojRD2NCHbuj7w6mdNW4AIapfhINPMstuZ0ZveUcrEAyq9sMCcTEp6QRJ9L/Z6j
# fCbVN7w6XUhtldU/SfQnuxaBRVD9nL22heB2fjdxyyL3WqqQz/WTauPrINHVUHmI
# moqKwba9oUgYftzYgBoRGRjNYZmBVvbJ43bnxOQbX0P4PpT/djk9ntSZz0rdKOtf
# JqGVWEjVGv7XJz/9kNF2ht0csGBc8w2o7uCJob054ThO2m67Np375SFTWsPK6Wrx
# oj7bQ7gzyE84FJKZ9d3OVG3ZXQIUH0AzfAPilbLCIXVzUstG2MQ0HKKlS43Nb3Y3
# LIU/Gs4m6Ri+kAewQ3+ViCCCcPDMyu/9KTVcH4k4Vfc3iosJocsL6TEa/y4ZXDlx
# 4b6cpwoG1iZnt5LmTl/eeqxJzy6kdJKt2zyknIYf48FWGysj/4+16oh7cGvmoLr9
# Oj9FpsToFpFSi0HASIRLlk2rREDjjfAVKM7t8RhWByovEMQMCGQ8M4+uKIw8y4+I
# Cw2/O/TOHnuO77Xry7fwdxPm5yg/rBKupS8ibEH5glwVZsxsDsrFhsP2JjMMB0ug
# 0wcCampAMEhLNKhRILutG4UI4lkNbcoFUCvqShyepf2gpx8GdOfy1lKQ/a+FSCH5
# Vzu0nAPthkX0tGFuv2jiJmCG6sivqf6UHedjGzqGVnhOMIIGwDCCBKigAwIBAgIQ
# DE1pckuU+jwqSj0pB4A9WjANBgkqhkiG9w0BAQsFADBjMQswCQYDVQQGEwJVUzEX
# MBUGA1UEChMORGlnaUNlcnQsIEluYy4xOzA5BgNVBAMTMkRpZ2lDZXJ0IFRydXN0
# ZWQgRzQgUlNBNDA5NiBTSEEyNTYgVGltZVN0YW1waW5nIENBMB4XDTIyMDkyMTAw
# MDAwMFoXDTMzMTEyMTIzNTk1OVowRjELMAkGA1UEBhMCVVMxETAPBgNVBAoTCERp
# Z2lDZXJ0MSQwIgYDVQQDExtEaWdpQ2VydCBUaW1lc3RhbXAgMjAyMiAtIDIwggIi
# MA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDP7KUmOsap8mu7jcENmtuh6BSF
# dDMaJqzQHFUeHjZtvJJVDGH0nQl3PRWWCC9rZKT9BoMW15GSOBwxApb7crGXOlWv
# M+xhiummKNuQY1y9iVPgOi2Mh0KuJqTku3h4uXoW4VbGwLpkU7sqFudQSLuIaQyI
# xvG+4C99O7HKU41Agx7ny3JJKB5MgB6FVueF7fJhvKo6B332q27lZt3iXPUv7Y3U
# TZWEaOOAy2p50dIQkUYp6z4m8rSMzUy5Zsi7qlA4DeWMlF0ZWr/1e0BubxaompyV
# R4aFeT4MXmaMGgokvpyq0py2909ueMQoP6McD1AGN7oI2TWmtR7aeFgdOej4TJEQ
# ln5N4d3CraV++C0bH+wrRhijGfY59/XBT3EuiQMRoku7mL/6T+R7Nu8GRORV/zbq
# 5Xwx5/PCUsTmFntafqUlc9vAapkhLWPlWfVNL5AfJ7fSqxTlOGaHUQhr+1NDOdBk
# +lbP4PQK5hRtZHi7mP2Uw3Mh8y/CLiDXgazT8QfU4b3ZXUtuMZQpi+ZBpGWUwFjl
# 5S4pkKa3YWT62SBsGFFguqaBDwklU/G/O+mrBw5qBzliGcnWhX8T2Y15z2LF7OF7
# ucxnEweawXjtxojIsG4yeccLWYONxu71LHx7jstkifGxxLjnU15fVdJ9GSlZA076
# XepFcxyEftfO4tQ6dwIDAQABo4IBizCCAYcwDgYDVR0PAQH/BAQDAgeAMAwGA1Ud
# EwEB/wQCMAAwFgYDVR0lAQH/BAwwCgYIKwYBBQUHAwgwIAYDVR0gBBkwFzAIBgZn
# gQwBBAIwCwYJYIZIAYb9bAcBMB8GA1UdIwQYMBaAFLoW2W1NhS9zKXaaL3WMaiCP
# nshvMB0GA1UdDgQWBBRiit7QYfyPMRTtlwvNPSqUFN9SnDBaBgNVHR8EUzBRME+g
# TaBLhklodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRS
# U0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0EuY3JsMIGQBggrBgEFBQcBAQSBgzCB
# gDAkBggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMFgGCCsGAQUF
# BzAChkxodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVk
# RzRSU0E0MDk2U0hBMjU2VGltZVN0YW1waW5nQ0EuY3J0MA0GCSqGSIb3DQEBCwUA
# A4ICAQBVqioa80bzeFc3MPx140/WhSPx/PmVOZsl5vdyipjDd9Rk/BX7NsJJUSx4
# iGNVCUY5APxp1MqbKfujP8DJAJsTHbCYidx48s18hc1Tna9i4mFmoxQqRYdKmEIr
# UPwbtZ4IMAn65C3XCYl5+QnmiM59G7hqopvBU2AJ6KO4ndetHxy47JhB8PYOgPvk
# /9+dEKfrALpfSo8aOlK06r8JSRU1NlmaD1TSsht/fl4JrXZUinRtytIFZyt26/+Y
# siaVOBmIRBTlClmia+ciPkQh0j8cwJvtfEiy2JIMkU88ZpSvXQJT657inuTTH4YB
# ZJwAwuladHUNPeF5iL8cAZfJGSOA1zZaX5YWsWMMxkZAO85dNdRZPkOaGK7DycvD
# +5sTX2q1x+DzBcNZ3ydiK95ByVO5/zQQZ/YmMph7/lxClIGUgp2sCovGSxVK05iQ
# RWAzgOAj3vgDpPZFR+XOuANCR+hBNnF3rf2i6Jd0Ti7aHh2MWsgemtXC8MYiqE+b
# vdgcmlHEL5r2X6cnl7qWLoVXwGDneFZ/au/ClZpLEQLIgpzJGgV8unG1TnqZbPTo
# ntRamMifv427GFxD9dAq6OJi7ngE273R+1sKqHB+8JeEeOMIA11HLGOoJTiXAdI/
# Otrl5fbmm9x+LMz/F0xNAKLY1gEOuIvu5uByVYksJxlh9ncBjDCCB7UwggWdoAMC
# AQICEAcinfAkAmWmAghlZhLlTsUwDQYJKoZIhvcNAQELBQAwaTELMAkGA1UEBhMC
# VVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMUEwPwYDVQQDEzhEaWdpQ2VydCBU
# cnVzdGVkIEc0IENvZGUgU2lnbmluZyBSU0E0MDk2IFNIQTM4NCAyMDIxIENBMTAe
# Fw0yMjEwMDMwMDAwMDBaFw0yMzAzMTcyMzU5NTlaMIG5MQswCQYDVQQGEwJBVTEa
# MBgGA1UECBMRV2VzdGVybiBBdXN0cmFsaWExETAPBgNVBAcTCEtvamFyZW5hMScw
# JQYDVQQKEx5BdXN0cmFsaWFuIFNpZ25hbHMgRGlyZWN0b3JhdGUxKTAnBgNVBAsT
# IEF1c3RyYWxpYW4gQ3liZXIgU2VjdXJpdHkgQ2VudHJlMScwJQYDVQQDEx5BdXN0
# cmFsaWFuIFNpZ25hbHMgRGlyZWN0b3JhdGUwggIiMA0GCSqGSIb3DQEBAQUAA4IC
# DwAwggIKAoICAQCmlqO4LNn+srEfOuFQvPfikoRuwUjsiZ5nn4tYcjJHDWzHjtPs
# 77qyX69c9lzKI/5gQXAAbb+Ps5Q1ukd0LOHtbTo909jKoAN/0JFtTWnQiZuypmEk
# oAVKFCEAtn1o7ymCoZbajqTrlAXDRX3B04CaO6PLZKgsWgzgXfQvsjU/gsR7fKF4
# lKfICKTz5xaZdjxEch9TCqK6pdiR/F80JP7IYQRlCMGFNNmXMJ+s4cNVy/xrlIWE
# o+aj5Fbg607YnWhlcF12YX53znDh5w2oMb/an31uTl7IBF5fe6Hf+mwv/ejKFnTD
# ncbJkA1yUyG1aY9IAP5pg29TH+1hiH1Zs4Ai1qQcU57+fL4nALfw5p1twPPQQNb1
# Ge4fptfZ5yXhdPcmdx5TXWa+8mzm4mRkZX4opVVQgopZmsbzfO9VbpMG53JlsonT
# AtzcBbx7cy48ZmM8j9QE5ovvmRhRKcqYqTGrGuXrZiebldzo7RAjhSH4cOBxh7qB
# 23wGX4dhroME/beznIJArFyIn9lxwM1/8mHjE+p8MkXXm4WkeR8f2SdYbbAfaRj+
# ec+tADLrggdA5s35mCSsgV+rc12RcnrN3RhhAfZp/IkhHs/0jNyVG3TSeRqWfquY
# 8xwArn4UU6oH9N7TlwuUA7dytbhIHqfdnz8X5DSYWfM6v4KEPmXSGZ0Y2QIDAQAB
# o4ICBjCCAgIwHwYDVR0jBBgwFoAUaDfg67Y7+F8Rhvv+YXsIiGX0TkIwHQYDVR0O
# BBYEFACrXQ4MH1M2YQoT1K5ekRjuhwDCMA4GA1UdDwEB/wQEAwIHgDATBgNVHSUE
# DDAKBggrBgEFBQcDAzCBtQYDVR0fBIGtMIGqMFOgUaBPhk1odHRwOi8vY3JsMy5k
# aWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmluZ1JTQTQwOTZT
# SEEzODQyMDIxQ0ExLmNybDBToFGgT4ZNaHR0cDovL2NybDQuZGlnaWNlcnQuY29t
# L0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hBMzg0MjAyMUNB
# MS5jcmwwPgYDVR0gBDcwNTAzBgZngQwBBAEwKTAnBggrBgEFBQcCARYbaHR0cDov
# L3d3dy5kaWdpY2VydC5jb20vQ1BTMIGUBggrBgEFBQcBAQSBhzCBhDAkBggrBgEF
# BQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMFwGCCsGAQUFBzAChlBodHRw
# Oi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRDb2RlU2ln
# bmluZ1JTQTQwOTZTSEEzODQyMDIxQ0ExLmNydDAMBgNVHRMBAf8EAjAAMA0GCSqG
# SIb3DQEBCwUAA4ICAQDFCUQKXHj1185Qfsu8hnICbW0rjDQR2HVvZmO0TiUJOKQx
# N5OD9zFN0mW+ZNQkOKFtabiabRViozMN6VciWKMHCnhnUruzVWiu3QaxlOSB1f8s
# zNQMgS/3dnQOYqzdCDPn7TxIdJBy4YI2Lby7vUy/8jVFVbpY/Qb2AKI29offJ6sY
# yuz7WSnkOw8DFw6E9j4ODObvG3dlXISxW2HjaS2DnVx7hic27eLjzWyutrD7+USE
# av8OtWiVl9tdwi8Up/DwzABQzhmZGn8uN3ILNWFINs2MTKD4N/A8kJEIWF8535nB
# 6RqKsvtbOb7uL/yaw3cuXdQ+SCGS6ObddqbpKs5DCbhDizjFymKF4043PPBPW7S/
# n9WJgClI1eOMvYcOIaqbRVEslX2G2nlT/XcQRp2tEbw96I6h2BCVEtWFECx/Azyw
# 2rTNPc8ZnopVA4UGnohIrH5hXceXLC+ub6oJdC2GjbVyI32mkgj6NrSanRvxXOad
# WsSee/gTh1DFuRsxkg+OOYQecToiOY1JcMGmr7SvTFw97GhnB6fKttYP0sPS6NrW
# bbNSrMTxK+jabI0jaQfmnQKY6mOU9SWYNkXxLmgKVJSGcz3Ec5qnqzw2rw8DiYho
# XZdKl+t+PBqzrsqYbSNpL68r9r29dOhXId8FqGIoW+L5d8UcSp/MyTRymPiQaDGC
# BlMwggZPAgEBMH0waTELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJ
# bmMuMUEwPwYDVQQDEzhEaWdpQ2VydCBUcnVzdGVkIEc0IENvZGUgU2lnbmluZyBS
# U0E0MDk2IFNIQTM4NCAyMDIxIENBMQIQByKd8CQCZaYCCGVmEuVOxTANBglghkgB
# ZQMEAgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJ
# AzEMBgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8G
# CSqGSIb3DQEJBDEiBCCSm0sHkr1ZgOGo2gU6cl8z66SaUBH6A60Pv2VqsJMokzAN
# BgkqhkiG9w0BAQEFAASCAgBSetHftPdggpadsb77hde4Y4S3D69fEeaBK5Fo0jCS
# cnbrfFyR0uzeZfTJ0AEMUD4cWrvoK+ieNivHjjg/8WTLwuAwuFRMbz4Su2CtbUGc
# PEYZf1aBjG8aBj8iU4lmfSJkd+VMhKFaA+C+r+f2brqxVAXZSvpDVra8Xwpl6Fej
# KceMieRSvdxZLTPw4UqVgzqEP0wEdU2kCrdjvVfKGqIJvHYeY7oZaa/UCA/8Od+z
# tRTXOdnnWFyGVOyrP5TAedyFuxnVP/ErJdU+BXd1UO1z8DsIRjC2P1vTziwmSWup
# iADTXAypGKWhyzX3fqIpbegl3CbByZntO8X+am7R4nWdzX2gfPA9V5flDsWrUgJL
# n6WrMyQ1xDuAOcE059lDmTSPzC2iBEmQwi1odrWa/EPCnBSFca84G2hC+tC1LbaK
# 8pnIaFv6tfV60cWwiVS2LeoaXlrMXfI6GYbxO7kpFpreSio1XheRQqjUp9Axf0YZ
# CEsk+YY92BiROqWahUfl0EVV67FN3PIlG/xF9xF6rVt5Utw4HHpzj9fw2D9NW2nj
# VOXhqVTADpWAhdPwrimX96wkrsLE0OwWrfST6i5Sz4Rn7keRJAiseMZMtkIdsoQu
# jta9XWAWAfRfqluDijUQzGOMFr1VBgSz9hktuEqIE1EvfqMe352/gkUv3CjtUKf6
# 1qGCAyAwggMcBgkqhkiG9w0BCQYxggMNMIIDCQIBATB3MGMxCzAJBgNVBAYTAlVT
# MRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UEAxMyRGlnaUNlcnQgVHJ1
# c3RlZCBHNCBSU0E0MDk2IFNIQTI1NiBUaW1lU3RhbXBpbmcgQ0ECEAxNaXJLlPo8
# Kko9KQeAPVowDQYJYIZIAWUDBAIBBQCgaTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcN
# AQcBMBwGCSqGSIb3DQEJBTEPFw0yMjExMjMwMzEwNTBaMC8GCSqGSIb3DQEJBDEi
# BCC0e/oREGDfWG+/JTwryJJhYxfupsT65mLDz4XS75JC2TANBgkqhkiG9w0BAQEF
# AASCAgCDQCJQkNg0/iVhp0oagg7Gv2BoNX4ZP+yY8SMhhpqlE+4BRqB/gs66ocm1
# YEOEyqeJqhP5Qe15t5HDpUoI0baRNXDqE7AGp2497FmT8v2PpinsXB799ZtnwgZA
# dN1KMEhSsQI5WA68GjgLGln8o+Kl4z6YWgaP44oreFqSwAFMr3nL3kFnfyJEIBMy
# d3syTGK/Gb6f7HvFxly5iK35rfHql7Xzez7CQ39RvqHXxt6jwEmuEof9afn2sko7
# 68lzzCsoqGBtUCaoGq6hXesyVjRN7kVBuATRP/bTJIRi5Xx4qzH3sNgYhuLRrQ9Y
# UoZR5WKm/ryVHFSbPCDV87dn3XNvIPlTH3X3+2i1TL3e50V9UvJOInn2wR12xYM2
# eoj0ACIzyu87U0M9ZbDMNvj0jXBzQ1/wlmhNjaXLzec+jWDjSC2AoPdAW8MipoK2
# 0QPYuVV9kTeiFocraID9NJ75RkI5DyhA1pdlvFoD/wW1viheGRS6kk32JydSX6qI
# qUvZ6OEc1grzxOY1yfsqebdTe1OcAeHVzued5hKrP1sArmMyFVJoIKDdJtu3rneZ
# 5TaCoOYHqMPfqKZbz/A+4bxvIvFFC67DttxcU/TsJYOhzBa3MB0V0jH+rr1w2NtV
# 40OUQfY0Z7vA02DqVHsxVvklu3uk51mjzrbvfQHwfzUQ/I2OVQ==
# SIG # End signature block
